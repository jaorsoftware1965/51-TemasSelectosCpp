 // 7.- Desarrollar un programa que solicite al usuario un número entre 1 y 5,
 //     y dependiendo del valor ingresado por el usuario, el programa responda
 //     imprimiendo el número en formato de texto, es decir, si el usuario 
 //     ingresa el número 2, el programa deberá imprimir la palabra "dos". 
 //     Emplear la herramienta de control case. 

 // Incluimos la libreria
 #include "stdio.h"

 // Programa principal
 int main()
 {
     // Variable para el ciclo for
     int numero;

     // Mensaje
     printf("Capture un numero entre 1-5:");
     scanf("%d",&numero);
     
     // Verifica que numero es:
     switch (numero)
     {
     case 1:
         printf("Uno");
         break;
     case 2:
         printf("Dos");
         break;
     case 3:
         printf("Tres");
         break;
     case 4:
         printf("Cuatro");
         break;
     case 5:
         printf("Cinco");
         break;
     
     default:
         printf("El Numero que capturaste, no esta dentro del rango indicado");
         break;
     }

     
     // Finaliza
     return 0;
 }