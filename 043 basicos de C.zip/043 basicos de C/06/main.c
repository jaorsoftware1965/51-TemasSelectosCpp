 // 6.- Desarrollar un programa que solicite al usuario un número, y esa 
 // petición debe repetirse mientras el usuario introduzca cualquier número 
 // que no sea cero. Esto deberás implementarlo con un while, y cuando el 
 // número ingresado sea 0, entonces el programa deberá terminar. 

 // Incluimos la libreria
 #include "stdio.h"

 // Programa principal
 int main()
 {
     // Variable para el ciclo for
     int numero=-1;

     // Mensaje
     printf("Entrando al Ciclo ... \n");
     
     // Ciclo while
     while (numero!=0)
     {
         // Solicita el Numero
         printf("Capture un numero; 0 para finalizar\n");
         scanf("%d",&numero);
     }

     
     // Finaliza
     return 0;
 }