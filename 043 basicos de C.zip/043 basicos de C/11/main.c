 // 11.- Desarrolla una función que reciba como parámetro 2 argumentos, 
 //      dentro de la función se sume el valor de esos 2 números, se 
 //      devuelva el resultado, y posterior a la salida de la función, 
 //      el valor devuelto se multiplique por un tercer número. 
 //      Los 3 números que se requieren deberán ser solicitados al usuario.  

 // Incluimos la libreria
 #include "stdio.h"

 // Función que suma 2 números
 int fnSuma(int numero1, int numero2)
 {
     // Retorna la suma de los 2
     return numero1 + numero2;
 }

 // Programa principal
 int main()
 {   
     // Variables para los 3 números
     int numero1, numero2, numero3;  
     
     // Solicita el primer numero a sumar
     printf("Capture el numero 1 a sumar:");
     scanf("%d",&numero1);

     // Solicita el primer numero a sumar
     printf("Capture el numero 2 a sumar:");
     scanf("%d",&numero2);

     // Solicita el primer numero a sumar
     printf("Capture el numero 3 a multiplicar:");
     scanf("%d",&numero3);
     
     // Llama a la función
     printf("El Resultado es:%d",fnSuma(numero1,numero2)*numero3);
          
     // Finaliza
     return 0;
 }