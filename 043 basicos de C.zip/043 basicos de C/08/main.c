 // 8.- Desarrollar un programa que permita al usuario calcular diferentes 
 // operaciones de cálculo de áreas de figuras dependiendo de lo ingresado 
 // por el usuario, por lo que el programa deberá solicitar al usuario un 
 // número entre 1 y 4.  
 // Si el usuario ingresa el número 1, el programa deberá entonces solicitar
 // al usuario un número que representa el lado de un cuadrado, y una vez 
 // ingresado el número, el programa deberá devolver el área del cuadrado. 
 // En la opción dos se deberá calcular el área de un círculo por lo que se 
 // deberá solicitar el radio. 
 // En el caso de la opción 3, se deberán pedir dos medidas para calcular el 
 // área de un rectángulo, 
 // Y en el caso de la opción 4 se pedirán las medidas para calcular el área 
 // de un triángulo.  

 // Incluimos la libreria
 #include "stdio.h"

 // Programa principal
 int main()
 {
     // Se pudieron haber usado solo 2 variables para todo
     // pero para que quedara mas claro, se usaron variables
     // para cada figura

     // Variable para la figura
     int figura;

     // Variable para el Cuadrado
     int lado;

     // Variable para el Círculo
     int radio;

     // Variables para el Rectángulo
     int lado1,lado2;

     // Variables para el Triángulo
     int base,altura;

     // Mensaje
     printf("Indique el area de que figura desea calcular:\n");
     printf("1) Cuadrado\n");
     printf("2) Circulo\n");
     printf("3) Rectangulo:\n");
     printf("4) Triangulo:\n");

     // Lee cual figura es:
     scanf("%d",&figura);
     
     // Verifica que figura es:
     switch (figura)
     {
     case 1:
         // Solicita el dato
         printf("Capture el valor del Lado del Cuadrado:");         
         scanf("%d",&lado);

         // Calcula e imprime
         printf("El area del cuadrado es:%d",lado * lado);         
         break;

     case 2:
         // Solicita el dato
         printf("Capture el valor del radio del Circulo:");         
         scanf("%d",&radio);

         // Calcula e imprime
         printf("El area del circulo es:%f",radio * 3.1416);         
         break;
     case 3:
         // Solicita el dato
         printf("Capture el lado 1 del Rectangulo:");         
         scanf("%d",&lado1);

         printf("Capture el lado 2 del Rectangulo:");         
         scanf("%d",&lado2);

         // Calcula e imprime
         printf("El area del rectangulo es:%d",lado1 * lado2);         
         break;
     case 4:
         // Solicita la Base
         printf("Capture la Base del Triangulo:");         
         scanf("%d",&base);

         printf("Capture la Altura del Triangulo:");         
         scanf("%d",&altura);

         // Calcula e imprime
         printf("El area del triangulo es:%f",base * altura / 2);         
         break;
     
     default:
         printf("La figura que capturaste, no esta dentro del rango indicado");
         break;
     }

     
     // Finaliza
     return 0;
 }