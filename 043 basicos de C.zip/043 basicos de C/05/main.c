 // 5.- Desarrollar un programa que imprima los números del 1 al 5 empleando 
 // una estructura for

 // Incluimos la libreria
 #include "stdio.h"

 // Programa principal
 int main()
 {
     // Variable para el ciclo for
     int numero;

     // Mensaje
     printf("Imprimiendo los numeros del 1 al 5 con for \n");

     // Ciclo para imprimir los números
     for (numero=1; numero<=5; numero++)
         printf("%d\n",numero);


     
     // Finaliza
     return 0;
 }