 // 10.- Desarrolla una función que reciba como parámetro 2 argumentos e 
 // imprima la multiplicación de esos dos números. 

 // Incluimos la libreria
 #include "stdio.h"

 // Función que imprime multiplicación de 2 números
 void fnImprimeMultiplicacion(int numero1, int numero2)
 {
     // Imprime los 2 numeros recibidos
     printf("La suma de %d y %d es:%d",numero1,numero2, numero1+numero2);
 }

 // Programa principal
 int main()
 {     
     // Llama a la función
     fnImprimeMultiplicacion(4,5);
          
     // Finaliza
     return 0;
 }