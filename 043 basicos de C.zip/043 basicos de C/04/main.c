 // 4.- Un programa que lea dos números. Si el primero número es mayor que el 
 //     segundo, que sume los dos números ingresados. En caso contrario, que 
 //     los multiplique y obvio que imprima el resultado de cualquiera de las 
 //     dos operaciones.  

 // Incluimos la libreria
 #include "stdio.h"

 // Programa principal
 int main()
 {
     // declaramos 2 numeros
     int     numero1, numero2;        // Se puede en una sola línea

     // Solicitamos el numero 1
     printf("Captura el numero 1:");
     scanf("%d", &numero1); 

     // Solicitamos el numero 2
     printf("Captura el numero 2:");
     scanf("%d", &numero2); 


     // Verificamos si el primero es mayor
     if (numero1 > numero2)
     {
         // Se realiza una suma
         printf("La Suma de los 2 numeros es:%d",numero1+numero2);
     }
     else
     {
         // Se realiza una multiplicación
         printf("La Multiplicacion de los 2 numeros es:%d",numero1*numero2);
     }
     
     // Finaliza
     return 0;
 }