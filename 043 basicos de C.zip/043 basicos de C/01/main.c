 // 1.- Desarrolla un programa donde declares una variable del tipo char, 
 //     entero y entero largo, y solicita al usuario que introduzca los 
 //     valores, para después el mismo programa imprima en pantalla los 
 //     valores que introdujo el usuario. 

 // Incluimos la libreria
 #include "stdio.h"

 // Programa principal
 int main()
 {
     // declaramos las 3 variables
     char     caracter;            // VAriable de Tipo Char
     int      entero;              // VAriable de Tipo Entero
     long int enteroLargo;         // Variable de Tipo Entero Largo

     // Solicitamos el dato
     printf("Captura un caracter:");

     // leemos un caracter con scanf
     scanf("%c", &caracter); 

     // Solicitamos el dato
     printf("Captura un entero:");

     // leemos un caracter con scanf
     scanf("%d", &entero); 

     // Solicitamos el dato
     printf("Captura un entero largo:");

     // leemos un caracter con scanf
     scanf("%ld", &enteroLargo); 

     // Mensaje
     printf("Los datos capturados son los siguientes:\n");
     printf("Caracter:%c  \n", caracter);
     printf("Caracter:%d  \n", entero);
     printf("Caracter:%ld \n", enteroLargo);

     // Finaliza
     return 0;
 }