 // 9.- Desarrolla un programa que permita crear un arreglo bidimensional de 5
 //     x 5 elementos, y posteriormente hay que poblar cada elemento del 
 //     arreglo con los números del 1 al 25.

 // Incluimos la libreria
 #include "stdio.h"

 // Programa principal
 int main()
 {     
     // Declaramos la matriz (arreglo de 2 dimensiones)
     int matriz[5][5];

     // Variable para las columnas y renglones de la matriz
     int columna, renglon;

     // Variable que llevará el conteo del valor del 1 al 25
     int conteo=1;

     // Ciclos para llenar la matriz
     for (renglon=0; renglon<5; renglon++)
     {
         for (columna=0; columna<5; columna++)
         {
             // Asigna el valor de conteo
             matriz[renglon][columna]=conteo;

             // Incrementa el valor de conteo
             conteo++;
         }
     }

     // Mensaje para desplegar la matriz
     printf("La Matriz generada es:\n");

     // Despliega la matriz
     // Ciclos para llenar la matriz
     for (renglon=0; renglon<5; renglon++)
     {
         for (columna=0; columna<5; columna++)
         {
             // Asigna el valor de conteo
             printf("[%02d]",matriz[renglon][columna]);
         }
         // Cambia de linea
         printf("\n");
     }
          
     // Finaliza
     return 0;
 }