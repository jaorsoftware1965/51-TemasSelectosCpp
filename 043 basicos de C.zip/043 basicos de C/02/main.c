 // 2.- Desarrolla un programa que lea dos números enteros, y que imprima en 
 // pantalla la suma, la resta y la multiplicación de esos dos números.  

 // Incluimos la libreria
 #include "stdio.h"

 // Programa principal
 int main()
 {
     // declaramos los 2 numeros
     int     numero1;        
     int     numero2;         

     // Solicitamos el dato
     printf("Captura el primer numero a sumar:");

     // leemos el numero1 con scanf
     scanf("%d", &numero1); 

     // Solicitamos el dato
     printf("Captura el segundo numero a sumar:");

     // leemos el numero2 con scanf
     scanf("%d", &numero2); 

     // Imprimimos la suma
     printf("La suma de los 2 numeros es: %d",numero1+numero2);
     printf("La suma de los 2 numeros es: %d",numero1-numero2);
     printf("La suma de los 2 numeros es: %d",numero1*numero2);

     // Finaliza
     return 0;
 }