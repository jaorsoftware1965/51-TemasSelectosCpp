 // 3.-Desarrolla un programa que lea un valor entero, luego imprime la 
 //    dirección en memoria en dónde se encuentra almacenado ese valor. 
 //    Posteriormente cambia el valor de la variable, pero sin hacer la 
 //    asignación directamente sobre la misma variable (utiliza un puntero 
 //    para cambiar el valor). 

 // Incluimos la libreria
 #include "stdio.h"

 // Programa principal
 int main()
 {
     // declaramos una variable entera
     int     numero;        

     // declaramos un apuntador a enter
     int*    pNumero;         

     // Solicitamos el dato
     printf("Captura el numero:");

     // leemos el numero con scanf
     scanf("%d", &numero); 

     // Asignamos la dirección al apuntador
     pNumero = &numero;

     // Imprimimos la dirección de la variable de 2 formas
     printf("Direccion de la variable:%p %p \n",&numero,pNumero);

     // Modificamos el valor de la variable desde el apuntador
     *pNumero = *pNumero + 10;

     // Imprimos la variable para verificar que haya sido incrementado en 10
     printf("El valor incrementado en 10 es:%d",numero);
     
     // Finaliza
     return 0;
 }