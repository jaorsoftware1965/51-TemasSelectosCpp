// Tareas en C
// Invertir una Lista usando una función

// Incluimos la librería
#include "stdio.h"

// Estructura del Nodo
struct node
{
    int valor;
    struct node *next;
};

// Función para imprimir la lista
void printLinkedList(struct node *head)
{
    // Ciclo para recorrer la lista hasta que siguiente sea null
    while (head!=NULL)
    {  
        // Imprime el valor
        printf("%d\t",head->valor);

        // Se mueve al siguiente elemento
        head = head->next;        
    }
    printf("\n");

}


// Función para retroceder
void reverse(struct node* node1, struct node* node2)
{
     // Simplemente lo hace que apunte al anterior
     node1->next = node2;     
}

// Función Principal
int main()
{ 
    // Define los nodos
    struct node n1,n2,n3,n4,n5;
    
    // Les asigna valores
    n1.valor = 5;
    n2.valor = 15;
    n3.valor = 25;
    n4.valor = 35;
    n5.valor = 45;

    // Los enlaza
    n1.next = &n2;
    n2.next = &n3;
    n3.next = &n4;
    n4.next = &n5;
    n5.next = NULL;

    // El Nodo cabeza
    struct node* head;
    head = &n1;

    // Imprimimos la lista
    printf("Los valores de la lista son:");

    // Despliega la lista
    printLinkedList(&n3);

    // llama a la funciòn para invertir la lista
    reverse(&n5,&n4);
    reverse(&n4,&n3);
    reverse(&n3,&n2);
    reverse(&n2,&n1);
    n1.next = NULL;

    // // Cambia el Head
    head = &n5;

   
    // // Mensaje
    printf("Los valores de la lista son:");

    // // Despliega la lista
    printLinkedList(head);
 }


