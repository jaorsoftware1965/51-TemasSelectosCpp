// ---------------------------------------------------------------
// Apuntadores a Funciones
// Se aprende a declarar variables que son apuntadores a funciones
// ---------------------------------------------------------------

// Inlcuimos la lirberia
#include "stdio.h"

// Funci�n Suma
int suma (int a, int b)
{
	return a+b;
}

// Funcion Resta
int resta (int a, int b)
{
	return a-b;
}

// Funci�n Multiplica
int multiplica(int a, int b)
{
	return a*b;
}


// declaramos un puntero a funciones con dos par�metros
// enteros que devuelven un entero
int (*funcion) (int,int);

// Funci�n principal
int main()
{
	// Variables para operandos
	int op1 = 6, op2 = 3;
	
	// Variable para resultado
	int x;
	
	// Hacemos que la funci�n apunte a suma
	funcion = suma;	   
	
	// Llamamos a la funci�n e Imprimimos resultado
	x = funcion(op1,op2);    			
	printf("Suma de %d + %d = %d \n",op1, op2, x);
	
	// Haemos que apunte a resta
	funcion = resta;   
	
	// Ejecutamos la funci�n
	x = funcion(op1,op2);  	
	printf("Resta de %d - %d = %d \n",op1, op2, x);
	
	// Vemos que no es posible asignar funci�n Multiplica
	funcion = multiplica;
	
	// Ejecutamos la funci�n
	x = funcion(op1,op2);  	
	printf("Multiplicacion de %d * %d = %d \n",op1, op2, x);
	
	
	
	
}
