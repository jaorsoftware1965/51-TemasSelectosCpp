// Temas Selectos de C++
// Sockets en C++
// servidor.cpp
// g++ servidor.cpp -l ws2_32 -o servidor

#include <iostream>
#include <string>
#include <windows.h>

using namespace std;

int main(int argc, char *argv[])
{
  // Variables necesarias
  WSADATA wsaData;
  SOCKET conn_socket,comm_socket;
  SOCKET comunicacion;
  struct sockaddr_in server;
  struct sockaddr_in client;
  struct hostent *hp;
  int resp,stsize;
  string aux;
  char RecvBuff[512];
  
  // Inicializamos la DLL de sockets
  resp = WSAStartup(MAKEWORD(1,0),&wsaData);

  // VAlidación
  if (resp)
  {
    cout << "Error al inicializar socket\n" << endl;
    return resp;
  }
  
  // Obtenemos la IP que usará nuestro servidor
  // en este caso localhost indica nuestra propia máquina...
  hp = (struct hostent *)gethostbyname("localhost");

  // Verificamos
  if (!hp)
  {
    cout << "No se ha encontrado servidor...\n" << endl;
    WSACleanup();
    return WSAGetLastError();
  }

  // Creamos el socket...
  conn_socket = socket(AF_INET,SOCK_STREAM, 0);

  // Validamos el Socket
  if (conn_socket == INVALID_SOCKET) 
  {
    cout << "Error al crear socket\n" << endl;
    WSACleanup();
    return WSAGetLastError();
  }
  
  // Configurando
  memset(&server, 0, sizeof(server)) ;
  memcpy(&server.sin_addr, hp->h_addr, hp->h_length);
  server.sin_family = hp->h_addrtype;
  server.sin_port = htons(6000);

  // Asociamos ip y puerto al socket
  resp = bind(conn_socket, (struct sockaddr *)&server, sizeof(server));

  // Validación
  if(resp == SOCKET_ERROR)
  {
    cout << "Error al asociar puerto e ip al socket\n" << endl;
    closesocket(conn_socket);
    WSACleanup();
    return WSAGetLastError();
  }

  if(listen(conn_socket, 1) == SOCKET_ERROR){
    cout << "Error al habilitar conexiones entrantes" << endl;
    closesocket(conn_socket);
    WSACleanup();
    return WSAGetLastError();
  }
              
  // Aceptamos conexiones entrantes
  cout << "Esperando conexiones entrantes... " << endl;
  stsize=sizeof(struct sockaddr);
  comm_socket = accept(conn_socket,(struct sockaddr *)&client,&stsize);

  // Verifica que si no es válida la conexión
  if(comm_socket == INVALID_SOCKET)
  {
    cout << "Error al aceptar conexión entrante\n" << endl;
    closesocket(conn_socket);
    WSACleanup();
    return WSAGetLastError();
  }

  // Mensaje de Conexión
  cout << "Conexion entrante desde:" << inet_ntoa(client.sin_addr) << endl;
              
  // Como no vamos a aceptar más conexiones cerramos el socket escucha
  closesocket(conn_socket);

  // Leyendo Mensajes del Cliente
  cout << "Recibiendo Mensajes ..." << endl;

  // Ciclo para recepción de Mensajes
  while(true)
  {
    // Lanza recepción de Mensajes
    recv (comm_socket, RecvBuff, sizeof(RecvBuff), 0);
    cout << "Recibido:" << RecvBuff << endl;
    aux = RecvBuff;
    
    // Valida fin de transmisión
    if (aux.compare("EOT")==0)
       break;
  }
  
  // Mensaje de Finalización
  cout << "Transmision Finalizada ..." << endl;
  
  // Cerramos el socket de la comunicacion
  closesocket(comm_socket);
  
  // Cerramos liberia winsock
  WSACleanup();

  // Finalizamos
  return (EXIT_SUCCESS);
} 