// Temas Selectos de C++
// Sockets en C++
// cliente.cpp
// g++ cliente.cpp -l ws2_32 -o cliente

#include <iostream>
#include <string>
#include <windows.h>

using namespace std;

// función principal
int main(int argc, char *argv[])
{
  // Variables necesarias  
  WSADATA wsaData;
  SOCKET  conn_socket;
  struct  sockaddr_in server;
  struct  hostent *hp;
  int     resp;
  string  aux;
  char SendBuff[512];

  
  // Inicializamos la DLL de sockets
  resp = WSAStartup(MAKEWORD(1,0),&wsaData);

  // Validamos
  if(resp)
  {
     cout << "Error al inicializar socket" << endl;
     return resp;
  }

  // Obtenemos la IP del servidor en este caso localhost
  hp=(struct hostent *)gethostbyname("localhost");

  // Verifica si puedo obtener el servidor
  if(!hp)
  {
    cout << "No se ha encontrado servidor" << endl;
    WSACleanup();
    return WSAGetLastError();
  }

  // Creamos el socket...
  conn_socket = socket(AF_INET,SOCK_STREAM, 0);

  // Validación
  if (conn_socket == INVALID_SOCKET) 
  {
    cout << "Error al crear socket" << endl;
    WSACleanup();
    return WSAGetLastError();
  }
   
  // Configura los datos de conexión 
  memset(&server, 0, sizeof(server)) ;
  memcpy(&server.sin_addr, hp->h_addr, hp->h_length);
  server.sin_family = hp->h_addrtype;
  server.sin_port = htons(6000);

  // Nos conectamos con el servidor...
  if(connect(conn_socket,(struct sockaddr *)&server,sizeof(server))==SOCKET_ERROR)
  {
    cout << "Fallo al conectarse con el servidor" << endl;
    closesocket(conn_socket);
    WSACleanup();
    return WSAGetLastError();
  }

  // Mensaje de conexión
  cout << "Conexion establecida con :" << inet_ntoa(server.sin_addr) << endl;
  cout << "Capture Mensaje para el Servidor (EOT Finalizar):" << endl;
  
  // Ciclo para enviar mensaje
  while (true)
  {
    // Leemos del Teclado    
    cin >> SendBuff;

    // Se envía lo capturado
    send (conn_socket,SendBuff,sizeof(SendBuff),0);

    // Pasamos a variable aux
    aux = SendBuff;

    // Verificamos fin de transmisión
    if (aux.compare("EOT")==0)
       break;
  }
  // Mensaje de Finalización
  cout << "Transmision finalizada ..." << endl;
 
  // Cerramos el socket y liberamos la DLL de sockets
  closesocket(conn_socket);

  // Se cierra la librería
  WSACleanup();

  // Se Finaliza
  return EXIT_SUCCESS;
} 