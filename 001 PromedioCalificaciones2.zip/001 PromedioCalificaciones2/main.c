// ------------------------------------------------------------------------------------------------
// promedioCalificaciones
// Objetivo : Leer 3 calificaciones de prácticas y 3 calificaciones de teoría
// obtener el promedio de cada una y despues el promedio de ambas considerando
// que para la teoría es una ponderación de 30% y para la práctica el 70%
// ------------------------------------------------------------------------------------------------

// Se incluyen las librerías
#include <stdio.h> 

// Función Principal
int main()
{ 	
	// Variables para las calificaciones y el promedio
	float teoria1, teoria2, teoria3, promedioTeoria; 
	float practica1, practica2, practica3, promedioPractica; 
	float promedioPonderado;

	// Solicita Captura de las Calificaciones de teoría
	printf("Captura la Calificacion de teoria 1: "); 
	scanf("%f", &teoria1); 
	printf("Captura la Calificacion de teoria 2: "); 
	scanf("%f", &teoria2); 
	printf("Captura la Calificacion de teoria 3: "); 
	scanf("%f", &teoria3); 

	// Calcula el Promedio
	promedioTeoria = (teoria1+teoria2+teoria3)/3;

	// Solicita y Captura las Calificaciones
	printf("Captura la Calificacion de practica 1: "); 
	scanf("%f", &practica1); 
	printf("Captura la Calificacion de practica 2: "); 
	scanf("%f", &practica2); 
	printf("Captura la Calificacion de practica 3: "); 
	scanf("%f", &practica3); 
	
	// Calcula el Promedio
	promedioPractica = (practica1+practica2+practica3)/3;

	// Promedio ponderado
	promedioPonderado = (promedioTeoria * .30) + (promedioPractica * .70);
	
	// Despliega El nombre, las calificaciones y el promedio
	printf ("Promedio de teoria   : %5.2f\n"  , promedioTeoria); 
	printf ("Promedio de practica : %5.2f\n"  , promedioPractica); 
	printf ("Promedio ponderado   : %5.2f\n\n", promedioPonderado); 

}