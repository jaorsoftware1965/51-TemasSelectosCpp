#include <iostream>
#include <string>
#include <iomanip>
using namespace std;


#define RATE_STATE_SALES_TAX1 6.5 // declare constant

int main()
{
    // Maestra. Por que puso esta constante, si no la voy a usar
    // y si ya tiene un calculo, que es el total de....
    const double county_sales_tax   = 501.38; // declare memory constat

    // Los 2 nombres de los impuestos como constantes
    const double impuesto_county_tasa = .02;
    const double impuesto_estado_tasa = .04;

    // Variable del Mes y Año
    string month;
    string year;
    string aux;

    // Este es el total que se solicita
    double total_collected; 
    // Esta es el total de ventas que se calcula
    double sales;

    // este es el total de impuesto estatal que se calcula usando la tasa
    double state_sales_tax;

    // este es el total de impuesto county que se calcula usando la tasa
    double mycounty_sales_tax;

    // Este es el total de los impuestos, la suma de los 2 anteriores
    double total_sales_tax;

    cout << "Get month press enter then input the year: " << endl;
    getline(cin, month);
    getline(cin, year);
    cout << "Get total collected: ";
    getline(cin, aux);
    total_collected = stof(aux);

    // Deja 2 lineas en blanco
    cout << endl << endl;
    
    // Calculamos el total de las ventas
    sales = total_collected / (1+ (impuesto_county_tasa+impuesto_estado_tasa));
    
    // Calculamos el impuesto estatal
    state_sales_tax    = sales * impuesto_estado_tasa;    

    // Calculamos el impuesto del county
    mycounty_sales_tax = sales * impuesto_county_tasa;

    // Calculamos el total de los impuestos
    total_sales_tax  = mycounty_sales_tax + state_sales_tax;
    

    // Tienes que ejecutar esta instruccion primero para poder fijar 
    std::cout << setprecision(2) << std::fixed;

    cout << "Month           : " << month << " " << year << endl;
    cout << "Total collected : " << total_collected << '\n';
    cout << "Sales           : " << sales << endl;
    cout << "County Sales Tax: " << right << setw(8) << county_sales_tax << endl;
    cout << "State Sales Tax : " << right << setw(8) << state_sales_tax << endl;
    cout << "Total Sales Tax : " << right << setw(8) << total_sales_tax << endl; 
    return 0;
}

/*Month: August2020
Total Collected: 26572.89
Sales: 25068.76
County Sales Tax: 501.38
State Sales Tax: 1002.75
Total Sales Tax: 1504.13*/

