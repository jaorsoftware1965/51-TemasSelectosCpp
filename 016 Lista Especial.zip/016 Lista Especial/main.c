// Tareas en C
// Crear una estructura para una lista especial

// Incluimos la librería
#include "stdio.h"


// Estructura del Nodo
struct node
{
    float  valor;
    struct node *prev;
    struct node *izq;
    struct node *der;
};

// Función Principal
int main()
{ 
    // Define los nodos
    struct node n1,n2,n3,n4;
    

    // Se asigna valores
    n1.valor = 10.5;    
    n2.valor = 29.8;
    n3.valor = 56.4;
    n4.valor = 14.1;

    // Los enlaza
    n1.izq  = &n2;
    n1.der  = &n3;
    n1.prev = NULL;

    n2.izq  = NULL;
    n2.der  = &n4;
    n2.prev = &n1;

    n3.izq  = &n4;
    n3.der  = NULL;
    n3.prev = NULL;

    n4.izq  = &n2;
    n4.der  = NULL;
    n4.prev = &n3;

    
    // Imprimimos. Las lineas comentadas son donde hay apuntadores a NULL
    // y por lo tanto no hay valor que desplegar
    printf("Los datos del n1 \n:");
    printf("Valor :%f\n",n1.valor);
    printf("izq:%p\n",n1.izq);
    printf("izq valor:%f\n",n1.izq->valor);
    printf("der:%p\n",n1.der);
    printf("der valor:%f\n",n1.der->valor);
    printf("prev:%p\n",n1.prev);    
    //printf("prev valor:%f\n",n1.prev->valor);
    printf("\n");

    printf("Los datos del n2 \n:");
    printf("Valor :%f\n",n2.valor);
    printf("izq:%p\n",n2.izq);
    //printf("izq valor:%f\n",n2.izq->valor);
    printf("der:%p\n",n2.der);
    printf("der valor:%f\n",n2.der->valor);
    printf("prev:%p\n",n2.prev);
    printf("prev valor:%f\n",n2.prev->valor);
    printf("\n");

    printf("Los datos del n3 \n:");
    printf("Valor :%f\n",n3.valor);
    printf("izq:%p\n",n3.izq);
    printf("izq valor:%f\n",n3.izq->valor);
    printf("der:%p\n",n3.der);
    //printf("der valor:%f\n",n3.der->valor);
    printf("prev:%p\n",n3.prev);
    //printf("prev valor:%f\n",n3.prev->valor);    
    printf("\n");

    printf("Los datos del n4 \n:");
    printf("Valor :%f\n",n4.valor);
    printf("izq:%p\n",n4.izq);
    printf("izq valor:%f\n",n4.izq->valor);
    printf("der:%p\n",n4.der);
    //printf("der valor:%f\n",n4.der->valor);
    printf("prev:%p\n",n4.prev);
    printf("prev valor:%f\n",n4.prev->valor);
    
 }


