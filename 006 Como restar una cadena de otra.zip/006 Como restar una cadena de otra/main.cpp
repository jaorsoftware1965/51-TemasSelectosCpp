// ---------------------------------------------------------------
// Objetivo: Restar una cadena de otra
// ---------------------------------------------------------------

// 1a ) Opcion
// En un canal de youtube
// En un c
// ----------------------
// anal de youtube

// 2a ) Opcion
// En un canal de youtube
//                   tube
// ----------------------
// En un canal de you

// 3a ) Opcion
// En un canal de youtube
// En un lugar
// ----------------------
// canal de youtube

// 4a ) Opcion
// En un canal de youtube
//                   rube
// ----------------------
// En un canal de yout

// 5a ) Opcion
// En un canal de youtube
// canal
// ----------------------
// en un  de youtube


// Incluimos la librería
#include <iostream>

// Definición de espacios de nombre
using namespace std;

// Función para restar cadena
string restarCadena(char lado, string cadena1, string cadena2)
{
	// Variable de Resultado
	string resultado="";
	int posicion;

    // Primero verifica que la cadena2 sea mayor que la 1
	if (cadena1.size() > cadena2.size())
	{
		// Verificamos que lado será
		switch(lado)
		{
			case 'I':
				// Busca la posición
				posicion = cadena1.find(cadena2);
                
				// Verifica que sea 0
				if (posicion==0)
				{
					// Si está al principio; reemplaza
					cadena1.replace(0,cadena2.size(),"");
				}
				else
				{
					// Verifica que pueda obtenerse subcadena
					if (cadena2.size()>1)
					{
						// Reducimos la cadena						
						cadena2 = cadena2.substr(0,cadena2.size()-1);
	
						// Se llama recursivamente
						cadena1 = restarCadena(lado,cadena1,cadena2);
					}
				}
				
				break;
			case 'D':
			    // Busca la posición
				posicion = cadena1.rfind(cadena2);

				// Verifica que sea esté al final
				if (posicion==cadena1.size()-cadena2.size())
				{
					// Si está al final; reemplaza
					cadena1.replace(posicion,cadena2.size(),"");
				}
				else
				{
					// Verifica que pueda obtenerse subcadena
					if (cadena2.size()>1)
					{
						// Reducimos la cadena
						cadena2 = cadena2.substr(1);

						// Se llama recursivamente
						cadena1 = restarCadena(lado,cadena1,cadena2);
					}
				}
				break;

			case 'C':
			    // Busca la posición
				posicion = cadena1.find(cadena2);

				// Verifica que sea mayor que 0
				if (posicion>=0)
				{
					// Si está al principio; reemplaza
					cadena1.replace(posicion,cadena2.size(),"");
				}
				break;	

		}	
	}
	
	// El resultado es la misma cadena1
	resultado = cadena1;

	// Retorna el resultado
	return resultado;	
}

// Función Principal de C
int main(int argc, char *argv[])
{
	// Defino las cadenas
	string cadena1="En un canal de Youtube";
	string cadena2;
	
	// Primera posibilidad
	cadena2="En un c";

	// Ejecutamos
	cout << "1)" << restarCadena('I',cadena1,cadena2) << endl;

	// Segunda posibilidad
	cadena2 ="tube";

    // Ejecutamos
	cout << "2)" << restarCadena('D',cadena1,cadena2) << endl;

	// Tercera posibilidad
	cadena2 ="En un lugar";

	// Ejecutamos
	cout << "3)" << restarCadena('I',cadena1,cadena2) << endl;

    // Cuarta posibilidad
	cadena2 ="rube";

	// Ejecutamos
	cout << "4)" << restarCadena('D',cadena1,cadena2) << endl;

    // Quinta posibilidad
	cadena2 ="canal";

	// Ejecutamos
	cout << "5)" << restarCadena('C',cadena1,cadena2) << endl;

    // Finaliza
	return 0;
}
