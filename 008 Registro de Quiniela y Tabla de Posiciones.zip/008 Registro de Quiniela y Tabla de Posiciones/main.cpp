// ---------------------------------------------------------------------
// Tareas y Temas Selectos de C, C++
// Programa que simula captura de una quiniela y muestra tabla de Puntos
// ---------------------------------------------------------------------

// Incluimos las librerías necesarias
#include <iostream>     // cout cin
#include <iomanip>      // std::setw
#include <time.h>       /* time */
#include <stdlib.h>     // rand
#include <conio.h>

// El nombre de Espacio
using namespace std;

// Definiendo la estructura de la información de Equipos
struct Equipo
{   
   string nombre;   
   int    puntos;
   int    ganados;
   int    perdidos;
   int    empatados;
   int    gFavor;
   int    gContra;
}equipos[16], equiposOrdenados[16];

struct Jornada
{
   int numero;
   int equipo1;
   int equipo2;
}jornadas[120]; // 8 partidos x 15 jornadas = 120

// Variable para controlar la Jornada en que se está
int jornadaActual=0;

// Función para crear los equipos con nombres ficticios
int  fnIntNumeroAleatorio();
void fnInicializaJornadas();
void fnCreaLosEquipos();
void fnCreaLasJornadas();
void fnCapturarEquipos();
void fnDesplegarEquipos();
void fnDesplegarJornadas();
void fnCapturarJornada();
void fnOrdenaEquipos();
bool fnExisteEquipoEnJornada(int jornada, int equipo);
bool fnExistePartidoEnJornadaPrevia(int Jornada, int Equipo1, int Equipo2);

// Función Principal
int main(int argc, char *argv[]) //auto
{
   // Limpia la Pantalla
   system ("cls");

   // Inicializa el Random
   cout << "Inicando semilla random ..." << endl;
   srand (time(NULL));

   // Llama a Función que crea los equipos
   cout << "Creando los Equipos ..." << endl;
   fnCreaLosEquipos();
   printf("%s",equipos[0].nombre);

   // Inicializa las Jornadas
   cout << "Inicializando jornadas ..." << endl;
   fnInicializaJornadas();

   // Crea las Jornadas
   cout << "Creando Jornadas ..." << endl;
   fnCreaLasJornadas();

   cout << "Listo para iniciar." << endl;
   cout << "Presione cualquier tecla paa continuar ..." << endl;
   getch();

   // Limpia la Pantalla 
   system ("cls");

   // Variable para la opción
   int opcion = 1;

   // Ciclo del Programa Principal
   while (opcion != 0)
   {
      cout << "Programa Principal" << endl;
      cout << "Jornada Actual es: " << jornadaActual << endl;
      cout << "1.- Capturar los Equipos" << endl;
      cout << "2.- Desplegar los Equipos" << endl;
      cout << "3.- Desplegar las Jornadas" << endl;
      cout << "4.- Capturar  la siguiente jornada" << endl;
      cout << "0.- Salir" << endl;
      
      // Captura la opción   
      cin >> opcion; 

      // Verifica si hay que salir
      if (opcion==0)
         break;

      // Verifica que hacer con la opción
      switch (opcion)
      {
         case 1:// Llama a función para capturar los equipos
                fnCapturarEquipos();
                break;

         case 2:// Llama a función para desplegar la tabla
                fnOrdenaEquipos();
                fnDesplegarEquipos();
                break;


         case 3:// Llama a función para desplegar las Jornadas
                fnDesplegarJornadas();
                break;                            

         case 4:// Llama a función para desplegar la tabla
                fnCapturarJornada();
                break;                     
      }
      cout << "Presione cualquier tecla para continuar ..." << endl;
      getch();
      system("cls");

   }

   // Programa Terminado
   cout << "Programa Terminado ...";

	// Finaliza con 0
	return 0;
}


// Función para crear los equipos con nombres ficticios
void fnCreaLosEquipos()
{
   // indice
   int indice;

   // Nombre del Equipo
   string nombre;

   // Tabla inicia en 1
   int tabla=1;
   int numero=1;

   // Ciclo para generar  los 8 equipos de la primera tabla
   for (indice = 0; indice < 16; indice++)
   {
      // Verifica si el indice ya es 8
      if (indice == 8)
      {
         tabla=2;
         numero=1;
      }

      // Inicializa el nombre del Equipo
      nombre="Equipo-"+to_string(tabla) + to_string(numero);
      equipos[indice].nombre    = nombre;
      equipos[indice].puntos    = 0;
      equipos[indice].ganados   = 0;
      equipos[indice].perdidos  = 0;
      equipos[indice].empatados = 0;
      equipos[indice].gFavor    = 0;
      equipos[indice].gContra   = 0;
      numero++;
   }
}

void fnCapturarEquipos()
{
   
   // Variable para el Equipo
   string nombreEquipo;

   // Mensaje de Captura
   cout << "Capturando los 16 equipos ..." << endl;

   // Ciclo
   for (int contador=0; contador < 16; contador++)
   {
      // Mensaje      
      cout << "Capture nombre del Equipo " << contador+1 <<  endl;
      cout << "Capture sin espacios y . para salir" << endl;
      cin >> nombreEquipo;      
      // Verifica salida
      if (nombreEquipo.compare(".")==0)
         // Sale
         break;
      else
         // Asigna el Equipo
         equipos[contador].nombre = nombreEquipo;
   }
   // Mensaje de Salida de la Captura
   cout << "Has salido de la captura de Equipos ..." << endl;
}

// Función para obtener un numero aleatorio
int  fnIntNumeroAleatorio()
{
   // Variable de Resultado
   int resultado=0; 
   
   // Genera el Aleatorio
   resultado = rand() % 16;

   // Retorna
   return resultado;
}

// Función para buscar un partido en la jornada actual
bool fnExisteEquipoEnJornada(int jornada, int equipo)
{
   // Variable para resultado
   bool encontro = false;

   // Ciclo
   for (int indice = (jornada-1)*8; indice < 120; indice++)
   {
       // Verifica que no sea -1
       if (jornadas[indice].numero != -1)
       {
          // verifica la jornada primero
          if (jornadas[indice].numero = jornada)
         
             // Verifica si es alguno de los Equipos
             if (jornadas[indice].equipo1 == equipo || jornadas[indice].equipo2 == equipo)
            
                // Indica que lo encontró
                encontro = true;                                
       }
       else
          break;
   }

   // Retorna el Resultado
   return encontro;
}

// Inicializa Jornadas
void fnInicializaJornadas()
{
   for (int indice=0; indice < 120; indice++)
   {
       jornadas[indice].numero  = -1;
       jornadas[indice].equipo1 = -1;
       jornadas[indice].equipo2 = -1;
   }
}
// Crea las Jornadas
void fnCreaLasJornadas()
{   
   // Variable para registro en Jornada
   int registroJornada = 0;

   // Variables para los 2 equipos
   int equipo1, equipo2;
     
   // Ciclo para las jornadas
   for (int numeroJornada=1; numeroJornada<16; numeroJornada++)
   {
      // Mensaje de jornada
      cout << "Creando Jornada " << numeroJornada << endl;
      
      // Ciclo para generar los 8 partidos
      int partido=1;
      
      // Ciclo para el equipo 1
      for (equipo1=0; equipo1<15; equipo1++)
      {               
         // Verifica que el equipo 1 no está en jornada
         if (!fnExisteEquipoEnJornada(numeroJornada,equipo1))
         {
            // Mensaje del Partido
            cout  << " Partido " << partido << endl;

            // Ciclo para el Equipo 2
            for (equipo2=equipo1+1; equipo2<16; equipo2++)
            {                               
                if (!fnExisteEquipoEnJornada(numeroJornada,equipo2))
                {
                   // Verifica que el partido no exista en previa
                   if (!fnExistePartidoEnJornadaPrevia(numeroJornada-1,
                                                       equipo1,
                                                       equipo2))
                   {
                      // Registra el Partido
                      jornadas[registroJornada].numero = numeroJornada;
                      jornadas[registroJornada].equipo1 = equipo1;
                      jornadas[registroJornada].equipo2 = equipo2;

                      // Incrementa partido
                      partido++;
                     
                      // Incrementa el Registro de Jornada
                      registroJornada++; 

                      // Sale
                      break;
                   }
                }   
            }
         }

      }      
   }
}

// Despliega la tabla indicada
void fnDesplegarEquipos()
{
   // Variable para indice
   int indice;
   
   // Despliega los encabezados
   cout << "Tabla 1" << endl;
   cout << "Nombre          ";
   cout << "Pts ";
   cout << "Gan ";
   cout << "Per ";
   cout << "Emp ";
   cout << "Fav ";
   cout << "Con " << endl;
   
   // Ciclo
   for (indice = 0 ; indice < 8; indice++)
   {
      // Desplegando la tabla 1
      cout << setw(15) << left   << equiposOrdenados[indice].nombre    << " ";
      cout << setw(3)  << right  << equiposOrdenados[indice].puntos    << " ";
      cout << setw(3)  << right  << equiposOrdenados[indice].ganados   << " ";
      cout << setw(3)  << right  << equiposOrdenados[indice].perdidos  << " ";
      cout << setw(3)  << right  << equiposOrdenados[indice].empatados << " ";         
      cout << setw(3)  << right  << equiposOrdenados[indice].gFavor    << " ";
      cout << setw(3)  << right  << equiposOrdenados[indice].gContra   << endl;         
   }
   
   // Cambia de Linea
   cout << endl;

   // La Tabla 2
   cout << "Tabla 2" << endl;
   cout << "Nombre          ";
   cout << "Pts ";
   cout << "Gan ";
   cout << "Per ";
   cout << "Emp ";
   cout << "Fav ";
   cout << "Con " << endl;
   
   // Ciclo
   for (indice = 8 ; indice < 16; indice++)
   {      
      // Desplegando la tabla 2
      cout << setw(15) << left   << equiposOrdenados[indice].nombre    << " ";
      cout << setw(3)  << right  << equiposOrdenados[indice].puntos    << " ";
      cout << setw(3)  << right  << equiposOrdenados[indice].ganados   << " ";
      cout << setw(3)  << right  << equiposOrdenados[indice].perdidos  << " ";
      cout << setw(3)  << right  << equiposOrdenados[indice].empatados << " ";         
      cout << setw(3)  << right  << equiposOrdenados[indice].gFavor    << " ";
      cout << setw(3)  << right  << equiposOrdenados[indice].gContra   << endl;               
   }
   // Deja una linea
   cout << endl;
}

// Desplegar las Jornadas
void fnDesplegarJornadas()
{
   // Variable para indice
   int jornada = 0;
   
   // Ciclo
   for (int indice = 0 ; indice < 120; indice++)
   {
       if (indice % 8 == 0)       
       {
          // Incrementa y Despliega
          jornada++;
          cout << "Jornada " << jornada << endl;
       }
       // Desplegando la tabla 1
       cout << setw(15) << left << equipos[jornadas[indice].equipo1].nombre << " vs ";
       cout << setw(15) << left << equipos[jornadas[indice].equipo2].nombre << " " << endl;         
   }
   cout << endl;
}

// Capturar la Jornada
void fnCapturarJornada()
{
   // Variables
   int golesEquipo1, golesEquipo2;

   // Verifica si todavía hay jornadas
   if (jornadaActual<15)
   {
      // Incrementa la Jornada
      jornadaActual++;

      // Mensaje de Jornada
      cout << "Jornada:" << jornadaActual << endl;

      int partido = 0;

      // Ciclo
      while (partido < 8)
      {
          // Equipo 1
          int indice = (jornadaActual-1)*8 + partido;
          cout << "Indice:" << indice << endl;
          cout << "Partido:" << partido + 1 << endl;
          int equipo1 = jornadas[indice].equipo1;
          int equipo2 = jornadas[indice].equipo2;
          cout << "Equipo 1: " << equipo1 << endl;
          cout << "Equipo 2: " << equipo2 << endl;

          // Despliega los equipos
          cout << equipos[equipo1].nombre << " vs ";
          cout << equipos[equipo2].nombre << endl;

          // Captura el Marcador
          cout << equipos[equipo1].nombre << ":";
          cin  >> golesEquipo1;
          cout << equipos[equipo2].nombre << ":";
          cin  >> golesEquipo2;              

          // Deja una linea de espacio
          cout << endl;

          // Actualiza la información de los Equipos
          if (golesEquipo1 > golesEquipo2)    
          {      
             // Incrementa los puntos y ganados en el primer equipo quien ganó
             equipos[equipo1].puntos = equipos[equipo1].puntos + 3;          
             equipos[equipo1].ganados++;         

             // Incrementa perdidos
             equipos[equipo2].perdidos++;         
          }
          else
             if (golesEquipo2 > golesEquipo1)
             {
                // Incrementa los puntos y ganados en el segundo equipo quien ganó
                equipos[equipo2].puntos = equipos[equipo2].puntos + 3;          
                equipos[equipo2].ganados++;
                // Incrementa perdidos
                equipos[equipo1].perdidos++;         
             }
             else
             {
                // Incrementa 1 punto en los 2 equipos por empate
                equipos[equipo1].puntos++;
                equipos[equipo2].puntos++;
                // Incrementa empates
                equipos[equipo1].empatados++;                         
                equipos[equipo2].empatados++;         
             }                                

         // Incrementa los goles en los 2 equipos 
         equipos[equipo1].gFavor  = equipos[equipo1].gFavor + golesEquipo1;                         
         equipos[equipo1].gContra = equipos[equipo1].gContra + golesEquipo2;                         
         equipos[equipo2].gFavor  = equipos[equipo2].gFavor + golesEquipo2;                         
         equipos[equipo2].gContra = equipos[equipo2].gContra + golesEquipo1;                         

         // Incrementa el Partido
         partido++;
      }    
   }
   else
   {
      // Mensaje
      cout << "Ya se han jugado las 15 jornadas";
   }
}

// Función para ordenar los Equipos
void fnOrdenaEquipos()
{
   // Mensaje
   cout << "Copiando los Equipos  ..." << endl;

   // Ciclo para copiar los Equipos
   for (int indice=0; indice < 16; indice++)
   {
      // Pasa los equipos tal cual
      equiposOrdenados[indice] = equipos[indice];
   }

   
   // Variable temporal para equipo
   Equipo equipoTemporal;

   // Mensaje
   cout << "Ordenando los Equipos de Tabla 1 ..." << endl;

   // Ciclo para ordenar la tabla 1 (Método Burbuja)
   for (int indice=0; indice < 7; indice++)  
       for (int indice2= indice+1; indice2 <=7; indice2++)
           // Verifica los puntos
           if (equiposOrdenados[indice].puntos < equiposOrdenados[indice2].puntos)
           {
              // Intercambia
              equipoTemporal = equiposOrdenados[indice2];
              equiposOrdenados[indice2] = equiposOrdenados[indice];
              equiposOrdenados[indice] = equipoTemporal;
           }
   

   // Mensaje
   cout << "Ordenando los Equipos de Tabla 2 ..." << endl;

   // Ciclo para ordenar la tabla 1 (Método Burbuja)
   for (int indice=8; indice < 15; indice++)  
       for (int indice2= indice+1; indice2 <=15; indice2++)
           // Verifica los puntos
           if (equiposOrdenados[indice].puntos < equiposOrdenados[indice2].puntos)
           {
              // Intercambia
              equipoTemporal = equiposOrdenados[indice2];
              equiposOrdenados[indice2] = equiposOrdenados[indice];
              equiposOrdenados[indice] = equipoTemporal;
           }

   // Mensaje
   cout << "Se ha terminado de Ordenar ..." << endl;
      
}

// Función para verificar si el partido ya existe en jornada previa
bool fnExistePartidoEnJornadaPrevia(int Jornada, int Equipo1, int Equipo2)
{
   // Variable de Resultado
   bool resultado=false;

   // Ciclo
   for (int registroJornada=0; registroJornada< Jornada*8-1; registroJornada++)
   {
      // Verifico
      if (jornadas[registroJornada].equipo1 == Equipo1 &&
          jornadas[registroJornada].equipo2 == Equipo2)
      {
         // Cambia el resultado
         resultado = true;

         // Sale del Ciclo
         break;
      }
      else
         if (jornadas[registroJornada].equipo2 == Equipo1 &&
             jornadas[registroJornada].equipo1 == Equipo2)
         {
            // Cambia el resultado
            resultado = true;

            // Sale del Ciclo
            break;
         }
   }

   // Devuelve el resultado
   return resultado;
}


// Crea las Jornadas
void fnCreaLasJornadasError()
{
   // Variable para la Jornada
   int numeroJornada = 1;

   // Variable para registro en Jornada
   int registroJornada = 0;
   
   
   // Ciclo
   while (registroJornada < 120)
   {
      // Variable para el equipo
      int equipoAleatorio1, equipoAleatorio2;

      // Partidos
      int partidos = 1;      
      
      // Ciclo para los partidos
      while (partidos <= 8)
      {
         // Registra la jornada
         jornadas[registroJornada].numero = numeroJornada;

         // Mensaje
         cout << "Creando Jornada " << numeroJornada << " Partido " << partidos << endl;

         // Ciclo para obtener el equipo 1
         while (true)
         {
            // Obtiene el Equipo Aleatorio
            equipoAleatorio1 = fnIntNumeroAleatorio();

            // Verifica que no exista
            if (! fnExisteEquipoEnJornada(numeroJornada,equipoAleatorio1))
            {
               // lo registra
               jornadas[registroJornada].equipo1 = equipoAleatorio1;

               // Sale del Ciclo
               break;               
            }
         }

         
         // Ciclo para obtener el equipo 2
         while (true)
         {
            // Obtiene el Equipo Aleatorio
            equipoAleatorio2 = fnIntNumeroAleatorio();

            // Verifica que no exista
            if (! fnExisteEquipoEnJornada(numeroJornada,equipoAleatorio2))
            {
               // Verifica que no esté en jornada previa
               if (!fnExistePartidoEnJornadaPrevia(numeroJornada-1,
                                                   equipoAleatorio1,
                                                   equipoAleatorio2))
               {
                  // lo registra
                  jornadas[registroJornada].equipo2 = equipoAleatorio2;

                  // Sale del Ciclo
                  break;               
               }   
               else
               {                  
                  printf("Choque ...\n");
                  cout << "Equipo 1:" << equipos[equipoAleatorio1].nombre << endl;
                  cout << "Equipo 2:" << equipos[equipoAleatorio2].nombre << endl;
                  getch();
                  fnDesplegarJornadas();                  
               }
            }
         }
         // Incrementa el numero de partidos
         partidos++;
         
         // Incrementa el Registro de Jornada
         registroJornada++;
      }
     
      // Incrementa la jornada
      numeroJornada++;      
   }
}
