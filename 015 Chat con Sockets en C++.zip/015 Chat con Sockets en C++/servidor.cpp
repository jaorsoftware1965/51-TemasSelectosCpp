// Temas Selectos de C++
// Chat con Sockets en C++
// servidor.cpp
// g++ servidor.cpp -l ws2_32 -o servidor

// Librerías
#include <iostream>
#include <string>
#include <windows.h>

// Nombre de Espacio
using namespace std;

// Variables globales para los Sockets
WSADATA wsaData;
SOCKET conn_socket,comm_socket;
SOCKET comunicacion;
struct sockaddr_in server;
struct sockaddr_in client;
struct hostent *hp;
int resp,stsize;
bool transmisionActiva=true;

// Función para iniciar el Servidor
bool fnIniciandoServidor()
{
   // Variable de Resultado
   bool resultado=true;

   // Inicializamos la DLL de sockets
   resp = WSAStartup(MAKEWORD(1,0),&wsaData);

   // Mensaje
   cout << "Iniciando libreria ..." << endl;

   // Validación
   if (resp)
   {
      cout << "Error al inicializar socket\n" << endl;
      resultado = false;
   }
   else
   {
      // Mensaje
      cout << "Accediendo a localhost ..." << endl;
  
      // Obtenemos la IP que usará nuestro servidor
      hp = (struct hostent *)gethostbyname("localhost");

      // Verificamos
      if (!hp)
      {
         cout << "No se ha encontrado servidor...\n" << endl;
         WSACleanup();
         resultado = false;
      }
      else
      {
          // Mensaje
          cout << "Creando el Socket ..." << endl;

          // Creamos el socket...
          conn_socket = socket(AF_INET,SOCK_STREAM, 0);

          // Validamos el Socket
          if (conn_socket == INVALID_SOCKET) 
          {
              cout << "Error al crear socket\n" << endl;
              WSACleanup();
              resultado = false;
          }
          else
          {
              // Mensaje
              cout << "Abriendo el Puerto ..." << endl;

              // Configurando
              memset(&server, 0, sizeof(server)) ;
              memcpy(&server.sin_addr, hp->h_addr, hp->h_length);
              server.sin_family = hp->h_addrtype;
              server.sin_port = htons(6000);

              // Asociamos ip y puerto al socket
              resp = bind(conn_socket, (struct sockaddr *)&server, sizeof(server));

              // Validación
              if (resp == SOCKET_ERROR)
              {
                  cout << "Error al asociar puerto e ip al socket\n" << endl;
                  closesocket(conn_socket);
                  WSACleanup();
                  resultado = false;
              }
              else
              {
                  // Mensaje
                  cout << "Validando Conexiones entrantes ..." << endl;

                  if (listen(conn_socket, 1) == SOCKET_ERROR)
                  {
                      cout << "Error al habilitar conexiones entrantes" << endl;
                      closesocket(conn_socket);
                      WSACleanup();
                      resultado = false;
                  }
                  else
                  {
                      // Aceptamos conexiones entrantes
                      cout << "Esperando conexiones entrantes... " << endl;

                      stsize=sizeof(struct sockaddr);
                      comm_socket = accept(conn_socket,(struct sockaddr *)&client,&stsize);

                      // Verifica que si no es válida la conexión
                      if (comm_socket == INVALID_SOCKET)
                      {
                          cout << "Error al aceptar conexión entrante\n" << endl;
                          closesocket(conn_socket);
                          WSACleanup();
                          resultado = false;
                      }
                      else
                      {
                          // Mensaje de Conexión
                          cout << "Conexion entrante desde:" << inet_ntoa(client.sin_addr) << endl;
                                  
                          // Como no vamos a aceptar más conexiones cerramos el socket escucha
                          closesocket(conn_socket);
                      }                      
                  }                                                
              }              
          }        
      }      
   }   

   // Retorna
   return resultado;
}  

// Función Hilo para leer Mensajes
void* fnServidorLeyendo(void* arg)
{
    // Variable para recibir los Mensajes
    char RecvBuff[512];

    // Leyendo Mensajes del Cliente
    //cout << endl << "Recibiendo Mensajes ..." << endl;
    //cout << "Servidor>";

    // Ciclo para recepción de Mensajes
    while(true && transmisionActiva)
    {      
      // Lanza recepción de Mensajes
      recv (comm_socket, RecvBuff, sizeof(RecvBuff), 0);

      // Verifica que la transmisión activa
      if (transmisionActiva)
      {
         cout << endl << "Recibido:" << RecvBuff << endl;
         cout << "Servidor>";
        
         // Valida fin de transmisión
         if (strcmp(RecvBuff,"EOT")==0)
         {
            // Mensaje del Cliente
            cout << endl << "El Cliente ha finalizado la Transmision ..." << endl << endl;  
            break;
         }
      }               
    }    

    // Finaliza 
    exit(0);
}


// Programa Principal
int main(int argc, char *argv[])
{
    // Variable de Resultado
    int resultado = EXIT_SUCCESS;

    // Variable para envío de mensajes:
    char SendBuff[512];

    // Declaro un objeto hilo 
    pthread_t hilo;
  
    // Lanza el Hilo para Recibir los Mensajes
    if (fnIniciandoServidor())
    {
       // Creo el hilo y valido error
       if (pthread_create(&hilo, NULL, fnServidorLeyendo, NULL))    
       {   
            // Mensaje y valor de Retorno
            cout << "Error al Crear el Hilo" << endl;
            resultado = EXIT_FAILURE;
       }
       else
       {
            // Ciclo para enviar mensajes
            while (true)
            {
                // Mensaje
                cout << "Servidor>";
                cin  >> SendBuff;

                //Enviamos y recibimos datos...
                send (comm_socket, SendBuff, sizeof(SendBuff), 0);                

                // Verifica si es finalizar
                if (strcmp(SendBuff,"EOT")==0)
                   // Sale del Ciclo
                   break;                
            }
       }   
       // Mensaje de Finalización
       transmisionActiva=false;       
       cout << endl << "Haz Finalizado la Transmision ..." << endl;       
  
       // Cerramos el socket de la comunicacion
       closesocket(comm_socket);
  
       // Cerramos liberia winsock
       WSACleanup();
       
    }
    else
       resultado = EXIT_FAILURE;

    // Finaliza
    return resultado;          
} 





















// // Programa Principal
// int main(int argc, char *argv[])
// {
//   // Variables necesarias
//   WSADATA wsaData;
//   SOCKET conn_socket,comm_socket;
//   SOCKET comunicacion;
//   struct sockaddr_in server;
//   struct sockaddr_in client;
//   struct hostent *hp;
//   int resp,stsize;
//   string aux;
//   char RecvBuff[512];
  
//   // Inicializamos la DLL de sockets
//   resp = WSAStartup(MAKEWORD(1,0),&wsaData);

//   // VAlidación
//   if (resp)
//   {
//     cout << "Error al inicializar socket\n" << endl;
//     return resp;
//   }
  
//   // Obtenemos la IP que usará nuestro servidor
//   // en este caso localhost indica nuestra propia máquina...
//   hp = (struct hostent *)gethostbyname("localhost");

//   // Verificamos
//   if (!hp)
//   {
//     cout << "No se ha encontrado servidor...\n" << endl;
//     WSACleanup();
//     return WSAGetLastError();
//   }

//   // Creamos el socket...
//   conn_socket = socket(AF_INET,SOCK_STREAM, 0);

//   // Validamos el Socket
//   if (conn_socket == INVALID_SOCKET) 
//   {
//     cout << "Error al crear socket\n" << endl;
//     WSACleanup();
//     return WSAGetLastError();
//   }
  
//   // Configurando
//   memset(&server, 0, sizeof(server)) ;
//   memcpy(&server.sin_addr, hp->h_addr, hp->h_length);
//   server.sin_family = hp->h_addrtype;
//   server.sin_port = htons(6000);

//   // Asociamos ip y puerto al socket
//   resp = bind(conn_socket, (struct sockaddr *)&server, sizeof(server));

//   // Validación
//   if(resp == SOCKET_ERROR)
//   {
//     cout << "Error al asociar puerto e ip al socket\n" << endl;
//     closesocket(conn_socket);
//     WSACleanup();
//     return WSAGetLastError();
//   }

//   if(listen(conn_socket, 1) == SOCKET_ERROR){
//     cout << "Error al habilitar conexiones entrantes" << endl;
//     closesocket(conn_socket);
//     WSACleanup();
//     return WSAGetLastError();
//   }
              
//   // Aceptamos conexiones entrantes
//   cout << "Esperando conexiones entrantes... " << endl;
//   stsize=sizeof(struct sockaddr);
//   comm_socket = accept(conn_socket,(struct sockaddr *)&client,&stsize);

//   // Verifica que si no es válida la conexión
//   if(comm_socket == INVALID_SOCKET)
//   {
//     cout << "Error al aceptar conexión entrante\n" << endl;
//     closesocket(conn_socket);
//     WSACleanup();
//     return WSAGetLastError();
//   }

//   // Mensaje de Conexión
//   cout << "Conexion entrante desde:" << inet_ntoa(client.sin_addr) << endl;
              
//   // Como no vamos a aceptar más conexiones cerramos el socket escucha
//   closesocket(conn_socket);

//   // Leyendo Mensajes del Cliente
//   cout << "Recibiendo Mensajes ..." << endl;

//   // Ciclo para recepción de Mensajes
//   while(true)
//   {
//     // Lanza recepción de Mensajes
//     recv (comm_socket, RecvBuff, sizeof(RecvBuff), 0);
//     cout << "Recibido:" << RecvBuff << endl;
//     aux = RecvBuff;
    
//     // Valida fin de transmisión
//     if (aux.compare("EOT")==0)
//        break;
//   }
  
//   // Mensaje de Finalización
//   cout << "Transmision Finalizada ..." << endl;
  
//   // Cerramos el socket de la comunicacion
//   closesocket(comm_socket);
  
//   // Cerramos liberia winsock
//   WSACleanup();

//   // Finalizamos
//   return (EXIT_SUCCESS);
// } 