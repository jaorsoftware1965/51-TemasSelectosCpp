// Temas Selectos de C++
// Sockets en C++
// cliente.cpp
// g++ cliente.cpp -l ws2_32 -o cliente

// Librerías
#include <iostream>
#include <string>
#include <windows.h>

// Espacio de Nombres
using namespace std;

// Variables del Servidor  
WSADATA wsaData;
SOCKET  conn_socket;
struct  sockaddr_in server;
struct  hostent *hp;
int     resp;
bool transmisionActiva=true;


// Función para iniciar el Cliente
bool fnIniciandoCliente()
{
    // Variable de Resultado
    bool resultado = true;

    // Inicializamos la DLL de sockets
    resp = WSAStartup(MAKEWORD(1,0),&wsaData);

    // Validamos
    if (resp)
    {
       cout << "Error al inicializar socket" << endl;
       resultado = false;
    }
    else
    {
      // Obtenemos la IP del servidor en este caso localhost
      hp = (struct hostent *)gethostbyname("localhost");

      // Verifica si puedo obtener el servidor
      if (!hp)
      {
         cout << "No se ha encontrado servidor" << endl;
         WSACleanup();
         resultado = false;
      }
      else
      {
         // Creamos el socket...
         conn_socket = socket(AF_INET,SOCK_STREAM, 0);

         // Validación
         if (conn_socket == INVALID_SOCKET) 
         {
            cout << "Error al crear socket" << endl;
            WSACleanup();
            resultado = false;
         }
         else
         {
            // Configura los datos de conexión 
            memset(&server, 0, sizeof(server)) ;
            memcpy(&server.sin_addr, hp->h_addr, hp->h_length);
            server.sin_family = hp->h_addrtype;
            server.sin_port = htons(6000);

            // Nos conectamos con el servidor...
            if (connect(conn_socket,(struct sockaddr *)&server,sizeof(server))==SOCKET_ERROR)
            {
              cout << "Fallo al conectarse con el servidor" << endl;
              closesocket(conn_socket);
              WSACleanup();
              resultado = false;
            }
            else 
              // Mensaje de conexión
              cout << "Conexion establecida con :" << inet_ntoa(server.sin_addr) << endl;
        }              
      }
    }

    // Devuelve el Resultado
    return resultado;
}

// Función Hilo para leer Mensajes
void* fnClienteLeyendo(void* arg)
{
    // Variable para recibir los Mensajes
    char RecvBuff[512];

    // Leyendo Mensajes del Servidor
    //cout << endl << "Recibiendo Mensajes ..." << endl;
    //cout << "Cliente>";

    // Ciclo para recepción de Mensajes
    while(true && transmisionActiva)
    {
       
       // Lanza recepción de Mensajes
       recv (conn_socket, RecvBuff, sizeof(RecvBuff), 0);

       // Verificando que la transmisión esté activa
       if (transmisionActiva)
       {
          cout << endl << "Recibido:" << RecvBuff << endl;
          cout << "Cliente>";
    
          // Valida fin de transmisión
          if (strcmp(RecvBuff,"EOT")==0)
          {
             // Mensaje del Cliente
             cout << endl << "El Servidor ha finalizado la Transmision ..." << endl << endl;
             break;
          }         
       }      
    }    
  
    // Finaliza 
    exit(0);
}

// función principal
int main(int argc, char *argv[])
{
    // Variable para enviar mensajes
    char SendBuff[512];
    

    // Declaro un objeto hilo 
    pthread_t hilo;

    // Variable de Resultado
    int resultado = EXIT_SUCCESS;
 
    // Función que inicia el Cliente
    if (fnIniciandoCliente())
    {
       if (pthread_create(&hilo, NULL, fnClienteLeyendo, NULL))    
       {   
           // Mensaje y valor de Retorno
           cout << "Error al Crear el Hilo" << endl;
           resultado =  EXIT_FAILURE;
       }
       else
       {
          // Ciclo para enviar mensaje
          while (true)
          {
              // Mensaje
              cout << "Cliente>";
              cin  >> SendBuff;

              // Se envía lo capturado
              send (conn_socket,SendBuff,sizeof(SendBuff),0);

              // Verificamos fin de transmisión
              if (strcmp(SendBuff,"EOT")==0)
                 break;
          }

          // Mensaje de Finalización
          transmisionActiva=false;
          cout << "Haz finalizado la Transmision ..." << endl;
                  
          // Cerramos el socket y liberamos la DLL de sockets
          closesocket(conn_socket);

          // Se cierra la librería
          WSACleanup();
           
       }          
    }
    else
       resultado = EXIT_FAILURE;
  
  // Se Finaliza
  return EXIT_SUCCESS;
} 