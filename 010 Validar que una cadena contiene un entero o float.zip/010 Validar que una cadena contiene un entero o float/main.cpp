// ----------------------------------------------------------
// Función que valida que una cadena contiene un valor float
// ----------------------------------------------------------

#include <iostream>
#include <string>

using namespace std;

// función para validar si una cadena corresponde a un entero
bool fnEsEntero(string cadena)
{
    // Variable de Resultado
    bool resultado = true;

    // Cadena Auxiliar
    string cadenaAux;
    
    // Variable entera
    int valorEntero;

    // Bandera que indica que ya encontró un numero
    bool yaEncontroNumero=false;

    // Ciclo que depura la cadena
    for (int indice=0; indice < cadena.size(); indice++)
    {
        // Filtra el +
        if (cadena.at(indice)!='+')
        {            
            if (cadena.at(indice)=='0')
            {
                if (yaEncontroNumero)           
                    cadenaAux = cadenaAux + cadena.at(indice);
            }
            else
            {
                if (cadena.at(indice)!='-')   
                {
                    yaEncontroNumero=true;
                }
                // Agrega la cadena a auxiliar
                cadenaAux = cadenaAux + cadena.at(indice);
            }
        }        
    }
    
    // Verifica si quedó vacía por 0's
    if (cadenaAux.length()==0)
       cadenaAux = "0";

    // Convertimos a entero
    valorEntero = atoi(cadena.c_str());

    // Comprobamos si es igual al convertir a entero
    if (cadenaAux.compare(to_string(valorEntero))!=0)
       // Cambiamos resultado
       resultado = false;

    // retornamos el resultado
    return resultado;
}

// función para validar si una cadena corresponde a un flotante
bool fnEsFlotante(string cadena)
{
    // Variable de Resultado
    bool resultado = true;

    // Cadena Auxiliar Entera y Decimal
    string parteEntera;
    string parteDecimal;

    // Variable para posición del punto
    int posPunto;

    // Obtiene la posición del Punto
    posPunto = cadena.find_first_of(".");

    if (posPunto>0)
    {
        parteEntera  = cadena.substr(0,posPunto);
        parteDecimal = cadena.substr(posPunto+1);
    }
    else
       if (posPunto==0)
       {
          // No tiene parte Entera
          parteEntera = "0";
          parteDecimal = cadena.substr(1);
       }   
       else
       {
           // Solo hay parte Entera
           parteEntera = cadena;
           parteDecimal = "0";
       }
    
    //cout << "Entera :" << parteEntera << "Decimal :" << parteDecimal << "->";
    // Valida que las partes sean numeros
    if (fnEsEntero(parteEntera) && fnEsEntero(parteDecimal))
    {
        cadena = parteEntera +"."+parteDecimal;
        try
        {
           // Trata de Convertir
           stoi(cadena);
        }
        catch(const std::exception& e)
        {
           //std::cerr << "Error" << e.what() << '\n';
           resultado = false;
        }       
    }
    else
       resultado = false;
    
    
    // retornamos el resultado
    return resultado;
}

int main()
{    
    // Convertimos con stof y no se lanza excepción    
    try
    {
        cout << "stof     23 : " << stof("23")  << endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << "Error en 23" << '\n';
    }
    
    try
    {
        cout << "stof    +23 : " << stof("+23")  << endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << "Error en +23" << '\n';
    }

    try
    {
        cout << "stof  +0023 : " << stof("+0023")  << endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << "Error en +0023" << '\n';
    }
        
    
    try
    {
        cout << "stof   0a23 : " << stof("0a23")  << endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << "Error en 0a23" << '\n';
    }

    try
    {
        cout << "stof  23.56 : " << stof("23.56")  << endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << "Error en 23.56" << '\n';
    }

    try
    {
        cout << "stof  23..56 : " << stof("23..56")  << endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << "Error en 23..56" << '\n';
    }

    try
    {
        cout << "stof  23.5.6 : " << stof("23.5.6")  << endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << "Error en 23.5.6" << '\n';
    }

    try
    {
        cout << "stof  -23 : " << stof("-23")  << endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << "Error en -23" << '\n';
    }
    
    try
    {
        cout << "stof  --23 : " << stof("--23")  << endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << "Error en --23" << '\n';
    }

    try
    {
        cout << "stof  ++23 : " << stof("++23")  << endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << "Error en ++23" << '\n';
    }

    try
    {
        cout << "stof  +9+23 : " << stof("+9+23")  << endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << "Error en +9+23" << '\n';
    }
    
    try
    {
        cout << "stof  23a : " << stof("23a")  << endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << "Error en 23a" << '\n';
    }
    
    try
    {
        cout << "stof  23.9a : " << stof("23.9a")  << endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << "Error en 23.9a" << '\n';
    }

    try
    {
        cout << "stof  0 : " << stof("0")  << endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << "Error en 0" << '\n';
    }

    try
    {
        cout << "stof  3.1416 : " << stof("3.1416")  << endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << "Error en 3.1416" << '\n';
    }

    try
    {
        cout << "stof  0.00 : " << stof("0.00")  << endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << "Error en 0.00" << '\n';
    }
    cout << endl;
    
    
    // cout << "Es flotante     23 : " << fnEsFlotante("23")  << endl;
    // cout << "Es flotante    +23 : " << fnEsFlotante("+23")  << endl;
    // cout << "Es flotante  +0023 : " << fnEsFlotante("+0023")  << endl;
    // cout << "Es flotante   0a23 : " << fnEsFlotante("0a23")  << endl;
    // cout << "Es flotante 23..56 : " << fnEsFlotante("23..56")  << endl;
    // cout << "Es flotante  23.56 : " << fnEsFlotante("23.56")  << endl;
    // cout << "Es flotante 23.5.6 : " << fnEsFlotante("23.5.6")  << endl;
    // cout << "Es flotante    -23 : " << fnEsFlotante("-23")  << endl;
    // cout << "Es flotante   --23 : " << fnEsFlotante("--23")  << endl;
    // cout << "Es flotante   ++23 : " << fnEsFlotante("++23")  << endl;
    // cout << "Es flotante  +9+23 : " << fnEsFlotante("+9+23")  << endl;
    // cout << "Es flotante    23a : " << fnEsFlotante("23a")  << endl;
    // cout << "Es flotante  23.9a : " << fnEsFlotante("23.9a")  << endl;
    // cout << "Es flotante      0 : " << fnEsFlotante("0")  << endl;
    // cout << "Es flotante 3.1416 : " << fnEsFlotante("3.1416")  << endl;
    // cout << "Es flotante   0.00 : " << fnEsFlotante("0.00")  << endl;
    cout << "Es flotante   d5.00 : " << fnEsFlotante("d5.00")  << endl;
    cout << "Es Entero         d : " << fnEsEntero("d")  << endl;
    
    

    // Finalizamos
    return 0;
}