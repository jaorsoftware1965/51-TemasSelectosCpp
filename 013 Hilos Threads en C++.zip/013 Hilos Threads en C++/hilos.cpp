/*
Temas Selectos en C++
Hilos Threads en C++
g++ hilos.cpp -o hilos
g++ hilos.cpp -o hilos -Wall -Wextra
*/

// Incluímos las librerías
#include <iostream>
#include <pthread.h>

// Definición de espacios de nombre
using namespace std;

// Función que ejecutará el hilo
void* fnDespliegaX(void* arg)
{
    // Asigna el valor de x
    int tabla = *((int*)arg);

    // Despliga el valor de x
    cout << "La Tabla del" << tabla <<  endl;

    // ciclo
    for (int indice=1; indice <= 1000; indice ++)
    {   
        // Despliega
        cout << tabla << " X " << indice << " = " << tabla * indice << endl;
    }

    // Finaliza 
    return NULL;
}

// función principal
int main(int argc, char* argv[])
{
    // Variable de Resultado
    int resultado = 0;

    // Declaro un objeto hilo 
    pthread_t hilo;

    // Valor inicial de X
    int x=100;    

    // Creo el hilo y valido error
    if (pthread_create(&hilo, NULL, fnDespliegaX, &x))    
    {   
        // Mensaje y valor de Retorno
        cout << "Error al Crear el Hilo" << endl;
        resultado = -1;
    }
    else
    {
        // Hace que el programa no finalice hasta que el hilo lo haga
        pthread_join(hilo,NULL);
        //cout << "Captura algo para finalizar";
        //getchar();
    }    
    
    // Finaliza
    return 0;
}
