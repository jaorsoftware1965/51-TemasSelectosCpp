// --
// Capturar la pantana en C++
// g++ main.cpp -lgdi32 -lcomdlg32
// ------------------------------
#include <windows.h>
#include <wingdi.h>
#include <iostream>


using namespace std;

void cap();
int main()
{
    

    cap();
    return 0;
}

void cap()
{
    LPCSTR  fileName="screenXXX.bmp";
    BITMAPINFO bmi;
    BITMAPFILEHEADER bfh;
    

    int     nWidth;
    int     nHeight;

    HWND    hWnd;
    HDC     hdc ;
    HDC     memDC;
    HBITMAP hbm ;
    HBITMAP hbmOld;
    BYTE *pbBits;


    HANDLE hfile;
    DWORD dwWritten;

    nWidth  = GetSystemMetrics(SM_CXSCREEN);
    nHeight = GetSystemMetrics(SM_CYSCREEN);

    hWnd    = GetDesktopWindow();
    hdc     = GetDC(hWnd);
    memDC   = CreateCompatibleDC(hdc);
    hbm     = CreateCompatibleBitmap(hdc, nWidth, nHeight);
    hbmOld  = (HBITMAP)SelectObject(memDC, hbm);

    BitBlt(memDC, 0, 0, nWidth, nHeight, hdc, 0, 0, SRCCOPY);
                                


    ZeroMemory(&bmi, sizeof(bmi));

    bmi.bmiHeader.biSize         = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth        = nWidth;
    bmi.bmiHeader.biHeight       = nHeight;
    bmi.bmiHeader.biBitCount     = 24;
    bmi.bmiHeader.biPlanes       = 1;
    bmi.bmiHeader.biCompression  = BI_RGB;
    bmi.bmiHeader.biSizeImage    = 32 * nWidth * nHeight / 8;


    pbBits =  (BYTE *) malloc(bmi.bmiHeader.biSizeImage); ;



    GetDIBits( memDC, 
                hbm,
                0,
                bmi.bmiHeader.biHeight,
                pbBits,
                &bmi,
                DIB_RGB_COLORS );





    bfh.bfType      = ('M' << 8) + 'B';
    bfh.bfSize      = sizeof(BITMAPFILEHEADER)  +
                    bmi.bmiHeader.biSizeImage +
                    sizeof(BITMAPINFOHEADER); 
    bfh.bfReserved1 = 0;
    bfh.bfReserved2 = 0;
    bfh.bfOffBits   = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);



    //(char *)pbBits // string de datos imagen sin cabezeras





    // por si lo quieres guadar en el fichero. 
    hfile = CreateFile(fileName,
                            GENERIC_WRITE,
                            0,
                            0,
                            OPEN_ALWAYS,
                            0,
                            0 ); 


    
    WriteFile(hfile,&bfh,           sizeof(bfh),               &dwWritten, NULL); 
    WriteFile(hfile,&bmi.bmiHeader, sizeof(BITMAPINFOHEADER),  &dwWritten, NULL); 
    WriteFile(hfile,pbBits,         bmi.bmiHeader.biSizeImage, &dwWritten, NULL); 


    CloseHandle(hfile);


    SelectObject(memDC, hbmOld);
    DeleteDC(memDC);
    ReleaseDC(hWnd,hdc); 
    DeleteObject(hbm);

    free(pbBits);
}