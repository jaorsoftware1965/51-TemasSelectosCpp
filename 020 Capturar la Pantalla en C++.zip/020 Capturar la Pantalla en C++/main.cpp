// -----------------------------------------------------------------
// Capturar la pantalla en C++
// g++ main.cpp -lgdi32 -o main
// -----------------------------------------------------------------
#include <windows.h>
#include <wingdi.h>
#include <iostream>

// Espacio de Nombres
using namespace std;

// Función para capturar la pantalla
void fnCapturarPantalla(string nombreArchivo);

// Función principal
int main()
{
    // Variable para solicitar la captura de la imagen
    string archivoImagen;

    // Variable para el comando
    string comando;

    // Solicita el nombre del archivo
    cout << "Indique el nombre del archivo (sin espacios; sin extension):" << endl;
    cin >> archivoImagen;

    // Agrega la extensión
    archivoImagen = archivoImagen + ".bmp";

    // Captura la pantalla
    fnCapturarPantalla(archivoImagen);

    // Crea el comando
    comando ="mspaint "+archivoImagen;

    // Ejecuta el mspaint con el archivo creado
    system(comando.c_str());

    // Finaliza
    return 0;
}

// Fución para capturar la pantalla
void fnCapturarPantalla(string nombreArchivo)
{
    // Variable para el Nombre del Archivo
    LPCSTR  fileName;

    // Toma el Nombre del Archivo del Parámetro
    fileName = (LPCSTR)nombreArchivo.c_str();
    
    // Variables para el manejo de la Imagen
    BITMAPINFO bmi;
    BITMAPFILEHEADER bfh;
    
    // Ancho y alto de la Pantalla
    int     anchoPantalla;
    int     altoPantalla;

    // Manejadores de Windows
    HWND    hWnd;
    HDC     hdc ;
    HDC     memDC;
    HBITMAP hbm ;
    HBITMAP hbmOld;
    BYTE*   pbBits;

    // Manejador del Archivo
    HANDLE hfile;

    // Bytes para grabar el archivo
    DWORD dwWritten;

    // Obtiene el ancho y alto de la pantalla
    anchoPantalla  = GetSystemMetrics(SM_CXSCREEN);
    altoPantalla = GetSystemMetrics(SM_CYSCREEN);

    // Obtiene el manejador del escritorio de Windows
    hWnd    = GetDesktopWindow();

    // Obtiene el manejador del Dispositivo
    hdc     = GetDC(hWnd);
    memDC   = CreateCompatibleDC(hdc);
    
    // Manejador del mapa de bits
    hbm     = CreateCompatibleBitmap(hdc, anchoPantalla, altoPantalla);
    hbmOld  = (HBITMAP)SelectObject(memDC, hbm);

    // Hace la copia desde la pantalla
    BitBlt(memDC, 0, 0, anchoPantalla, altoPantalla, hdc, 0, 0, SRCCOPY);
                                
    // Llena un bloque de memoria con 0's                            
    ZeroMemory(&bmi, sizeof(bmi));

    // Prepara el bmi para obtener la información de la imagen
    bmi.bmiHeader.biSize         = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth        = anchoPantalla;
    bmi.bmiHeader.biHeight       = altoPantalla;
    bmi.bmiHeader.biBitCount     = 24;
    bmi.bmiHeader.biPlanes       = 1;
    bmi.bmiHeader.biCompression  = BI_RGB;
    bmi.bmiHeader.biSizeImage    = 32 * anchoPantalla * altoPantalla / 8;

    // Prepara memoria para obtener la imagen
    pbBits =  (BYTE *) malloc(bmi.bmiHeader.biSizeImage); ;

    // Obtiene la información de los bit's y los copia en el buffer
    GetDIBits(memDC, hbm, 0, bmi.bmiHeader.biHeight, pbBits, &bmi, DIB_RGB_COLORS );

    // Configura que será un BMP
    bfh.bfType      = ('M' << 8) + 'B';
    bfh.bfSize      = sizeof(BITMAPFILEHEADER) + bmi.bmiHeader.biSizeImage +
                      sizeof(BITMAPINFOHEADER); 
    bfh.bfReserved1 = 0;
    bfh.bfReserved2 = 0;
    bfh.bfOffBits   = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);

    // por si lo quieres guadar en el fichero. 
    hfile = CreateFileA(fileName, GENERIC_WRITE, 0, 0, OPEN_ALWAYS, 0, 0);     
    WriteFile(hfile,&bfh,           sizeof(bfh),               &dwWritten, NULL); 
    WriteFile(hfile,&bmi.bmiHeader, sizeof(BITMAPINFOHEADER),  &dwWritten, NULL); 
    WriteFile(hfile,pbBits,         bmi.bmiHeader.biSizeImage, &dwWritten, NULL); 

    // Cierra el Manejador del Archivo
    CloseHandle(hfile);

    // Elimina los manejadores creados
    SelectObject(memDC, hbmOld);
    DeleteDC(memDC);
    ReleaseDC(hWnd,hdc); 
    DeleteObject(hbm);

    // Libera el apuntador a bits
    free(pbBits);
}