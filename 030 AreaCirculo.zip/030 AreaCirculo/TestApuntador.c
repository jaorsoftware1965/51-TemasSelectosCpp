// ------------------------------
// Test
// ------------------------------

// Librerias
#include "stdio.h" 
#include "string.h"


// El prototipo de la función
void fnTest(void* dato); 

// Función main
int main() 
{ 
    // Verifica que tipo de dato es
	int x=90;
	char cadena[20]="Hola Mundo";
	
	// Llama a la Función
	fnTest(cadena);
	
	printf("%s",cadena);
 	
	return;
}


// Función para calcular el área	
void fnTest(void* dato)
{
	//printf("%s",dato);
	strcpy(dato,"JAORsoftwre2");
	// Coloca un valor entero
    
   
    // Retorna
    return;
}