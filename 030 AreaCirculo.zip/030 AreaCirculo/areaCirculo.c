// ------------------------------
// Ejercicios de C
// areaCirculo.c
// ------------------------------

// Librerias
#include "stdio.h" 

// Definimos el valor de PI
#define PI 3.14159 

// El prototipo de la función
float fnCirculoArea(float radio); 

// Función main
int main() 
{ 
    // Variables necesarias
    float radio, area; 
	
	// Mensaje de Solicitud de Datos
	printf("Capture el radio:"); 
	
	// Lee el dato
	scanf("%f", &radio); 
	
	// Verifica si es menor que 0
	if (radio <= 0) 
	{
		// Area es 0 entonces
		area = 0; 
	}
	else 
	{
		// Calcula
		area = fnCirculoArea(radio); 
	}
	
	// Despliega el valor
	printf ("Area--> = %f " , area); 

}


// Función para calcular el área	
float fnCirculoArea(float r)
{
	// Variable para el cálculo
    //float a; 
   
    // Aplica la formula
    //a = PI * r * r; 
	
	// Retorna el valor
    return(PI * r * r); 
}