// -----------------------------------------------------------------
// Tema Selecto en C
// Hacer una función con N parámetros estilo printf
// -----------------------------------------------------------------
	
/* vfprintf example */
#include <stdio.h>
#include <stdarg.h>

void WriteFormatted (FILE * stream, const char * format, ...)
{
  va_list args;
  va_start (args, format);
  vfprintf (stream, format, args);
  
  va_end (args);
}

int main ()
{
   FILE * pFile;

   pFile = fopen ("myfile.txt","w");

   WriteFormatted (pFile,"Call with %d variable argument.\n",1);
   WriteFormatted (pFile,"Call with %d variable %s.\n",2,"arguments");
   WriteFormatted (pFile,"Call with %d variable %s %d.\n",3,"argumento",45);

   fclose (pFile);

   return 0;
}