// ----------------------------------------------------------------------------
// Tareas en C
// Hacer un programa para simular una Estructura de Cola con arreglos
// En una cola o fila, el primer elemento en entrar es el primero en salir
// FIFO First In First Out
// Preguntar al usuario el tamaño máximo de la estructura
// Mostrar el Estado de la Estructura al Insertar o Eliminar
// Mostrar el Valor de Frente y Final Despues de realizar inserciones o eliminaciones
// Mostrar Casos de Cola Llena y Cola vacía, Desbordamiento y Subdesbordamiento
// -----------------------------------------------------------------------------

// Incluimos la librería
#include "stdio.h"

// Constantes y Variables para Máximo de la Pila
#define MAX_ELEMENTOS_COLA 10     // Máximo de la Cola
#define POS_FRENTE          0     // La posición del Frente siempre es 0
int     posFinal = -1;            // Posición Final de la Cola
int     elementosCola;            // Variable para los Elementos de la Cola
int     cola[MAX_ELEMENTOS_COLA]; // Define la Cola

// Funcion para pausar el Programa
void fnPausa()
{
    // Cancela cualquier dato en el buffer
    fflush(stdin);

    // Mensaje
    printf("Presiona Enter para continuar ...\n");
    getchar();
}

// Funcion para insertar un elemento
void fnColaInsertar(int elemento)
{
    // Verifica que la posicion final no desborde
    if (posFinal < elementosCola - 1)
    {
        // Incrementa la posición final
        posFinal++;

        // Coloca el dato en esta posición
        cola[posFinal] = elemento;

        // Mensaje
        printf("El elemento ha sido insertado en la posicion:%d \n",posFinal);
    }
    else
    {
        printf("Desbordamiento. Ya no hay espacio en la cola \n");
    }    

    // Pausa el Programa
    fnPausa();
}

// Desplegar la Cola
void fnColaDesplegar()
{
    // Verifica que haya datos en la Cola
    if (posFinal>=0)
    {
        // Mensaje
        printf("Los Elementos de la Cola son:\n");

        // Ciclo para desplegar los elementos
        for (int indice = 0; indice <= posFinal; indice++)
        {
            // Despliega el la posición y el elemento
            printf("Posicion:%d Elemento:%d \n",indice, cola[indice]);
        }

    }
    else
    {
       printf("La Cola esta vacia. No hay elementos para Desplegar \n");
    }    

    // Pausa el Programa
    fnPausa();
}

// Función para obtener el Elemento del Frente de la Cola
void fnColaFrente()
{
    // Verifica que la Cola no esté vacía
    if (posFinal >= 0)
    {
       // Despliega el Elemento
       printf("El Frente de la Cola es:%d\n",cola[POS_FRENTE]);
    }
    else
    {
        // Mensaje
        printf("La Cola esta vacia. No hay elemento en el Frente \n");
    }    
    
    // Pausa el programa
    fnPausa();
}

// Función para obtener el Elemnto Final de la Cola
void fnColaFinal()
{
    // Verifica que la Cola no esté vacía
    if (posFinal>=0)
    {
       // Despliega el Elemento
       printf("El Final de la Cola es:%d \n",cola[posFinal]);

    }
    else
    {
        // Mensaje
        printf("La Cola esta vacia. No hay elemento en el Final \n");
    }

    // Pausa el Programa
    fnPausa();
}

// Función para eliminar un elemento y obtener cual es
int fnColaEliminar()
{
    // Verifica que la cola no esté vacía
    if (posFinal < 0)
    {
        // Mensaje
        printf("SubDesbordamiento. La Cola esta vacia. No se puede eliminar \n");
    }
    else
    {
        // Obtiene el elemento a eliminar
        printf("El elemento eliminado es:%d\n", cola[POS_FRENTE]);

        
        // Verifica que haya mas de un elemento para hacer recorrido
        if (posFinal >0)
        {
           // Recorre los elementos
           for (int indice=0; indice<posFinal; indice++)
           {
               // Pasa el elemento hacia atras
               cola[indice] = cola[indice+1];
           }
        }
        
        // Decrementa el valor de posición Final
        posFinal--;            
    }

    // Pausar
    fnPausa();
}


// Función Principal
int main()
{ 
    // Variable para la opción del Menu
    int opcion;
    
    // Variable para el Elemento a Insertar
    int elementoInsertar; 
    
    // Solicita al Numero de Elementos de la Cola
    printf("Indica el Numero de elementos de la cola (MAX=10):");

    // Lee el dato
    scanf("%d",&elementosCola);

    // Verifica que no sea mayor
    if (elementosCola > MAX_ELEMENTOS_COLA)
    {
        // Mensaje
        printf("Error: El numero de elementos no puede ser mayor de 10");
        return 0;
    }

    // Verifica que no sea menor igual 0
    if (elementosCola > MAX_ELEMENTOS_COLA)
    {
        // Mensaje
        printf("Error: El numero de elementos no puede ser 0 o menor");
        return 0;
    }

    // Ciclo para desplegar el Menu
    do
    {
        // Despliega el Menu
        printf("------------------ \n");
        printf("Menu Cola           \n");
        printf("------------------ \n");
        printf("1.- Insertar       \n");
        printf("2.- Eliminar       \n");
        printf("3.- Frente         \n");
        printf("4.- Final          \n");
        printf("5.- Desplegar      \n");
        printf("0.- Finalizar      \n");
        scanf("%d",&opcion);

        // Verifica opcion
        switch (opcion)
        {
        case 1:            
            // Solicita el Elemento a Insertar
            printf("Capture el elemento a Insertar:");
            scanf("%d,",&elementoInsertar);

            // Llama a la función para Insertar
            fnColaInsertar(elementoInsertar);
            break;
        case 2:            
            // Llama a función para eliminar
            fnColaEliminar();
            break;

        case 3:           
            // Llama a función para el Frente
            fnColaFrente(); 
            break;

        case 4:            
            // LLama a función para el Final
            fnColaFinal();
            break;

        case 5:       
            // Despliega
            fnColaDesplegar();     
            break;

        case 0:            
            // Mensaje
            printf("El Programa finalizara ... \n");
            break;    

        default:            
            // Mensaje
            printf("Opcion desconocida \n");

            // Pausa el Programa
            fnPausa();
            break;
        }

        
    } while (opcion!=0);

    // Finaliza
    return 0;
           
}