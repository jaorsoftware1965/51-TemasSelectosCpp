/*
Temas Selectos en C++
Validar que una cadena contiene una fecha válida
*/

// Incluímos las librerías
#include <iostream>
#include <ctime>
#include <string>

// Definición de espacios de nombre
using namespace std;

// función para validar si una cadena corresponde a un entero
bool fnEsEntero(string cadena)
{
    // Variable de Resultado
    bool resultado = true;

    // Cadena Auxiliar
    string cadenaAux;
    
    // Variable entera
    int valorEntero;

    // Bandera que indica que ya encontró un numero
    bool yaEncontroNumero=false;

    // Ciclo que depura la cadena
    for (int indice=0; indice < cadena.size(); indice++)
    {
        // Filtra el +
        if (cadena.at(indice)!='+')
        {            
            if (cadena.at(indice)=='0')
            {
                if (yaEncontroNumero)           
                    cadenaAux = cadenaAux + cadena.at(indice);
            }
            else
            {
                if (cadena.at(indice)!='-')   
                {
                    yaEncontroNumero=true;
                }
                // Agrega la cadena a auxiliar
                cadenaAux = cadenaAux + cadena.at(indice);
            }
        }        
    }
    
    // Verifica si quedó vacía por 0's
    if (cadenaAux.length()==0)
       cadenaAux = "0";

    // Convertimos a entero
    valorEntero = atoi(cadena.c_str());

    // Comprobamos si es igual al convertir a entero
    if (cadenaAux.compare(to_string(valorEntero))!=0)
       // Cambiamos resultado
       resultado = false;

    // retornamos el resultado
    return resultado;
}

// Función que valida que una cadena contenga una fecha válida
// Formatos posibles
// 0 - dd/mm/yyyy
// 1 - mm/dd/yyyy
// 2 - yyyy/mm/dd
// Separadores válidos: /,-,.
// La longitud de la cadena obligatoriamente es 10
bool fnEsFecha(string cadena, int formato)
{
    // Variable de Resultado inicializado a true
    bool resultado=true;

    // Variables para las cadenas
    string dia, mes, anio, sep1, sep2;

    // Variables para la fecha con enteros
    int intDia, intMes, intAnio;

    // Variable para crear la Fecha
    struct tm tmFecha;
    
    // Para el Despliegue de la Fecha
    char strFecha[80];

    // Primero se valida la longitud de la cadena
    if (cadena.length() == 10)
    {
        // Ejecuta de acuerdo al formato
        switch(formato)
        {
            case 0: // Obtiene los 3 datos y los separadores
                    dia = cadena.substr(0,2);
                    mes = cadena.substr(3,2);
                    anio = cadena.substr(6);
                    sep1 = cadena[2];
                    sep2 = cadena[5];
                    break;
            
            case 1: // Obtiene los 3 datos y los separadores
                    dia = cadena.substr(3,2);
                    mes = cadena.substr(0,2);
                    anio = cadena.substr(6);
                    sep1 = cadena[2];
                    sep2 = cadena[5];
                    break;

            case 2: // Obtiene los 3 datos y los separadores
                    dia = cadena.substr(8,2);
                    mes = cadena.substr(5,2);
                    anio = cadena.substr(0,4);
                    sep1 = cadena[4];
                    sep2 = cadena[7];
                    break;   
            default:
                    // Cambiamos el valor de Resultado
                    resultado = false;                                            
        }

        // Verificamos que todavía el resultado sea válido
        if (resultado)
        {
            // Validamos que sean numeros el día mes y anio
            if (fnEsEntero(dia) && fnEsEntero(mes) && fnEsEntero(anio))
            {
                // Verificamos que los separadores sean iguales
                if (sep1.compare(sep2)==0)
                {
                    // Verificamos que sean validos
                    if (sep1[0]=='/' || sep1[0]=='-' || sep1[0]=='.')
                    {
                        // Convierte los datos a entero
                        intDia = atoi(dia.c_str());
                        intMes = atoi(mes.c_str()) - 1;
                        intAnio = atoi(anio.c_str()) - 1900;

                        // Colocamos los datos en la variable de Fecha
                        tmFecha.tm_year  = intAnio;
                        tmFecha.tm_mon   = intMes;
                        tmFecha.tm_mday  = intDia;
                        tmFecha.tm_hour  = 0;
                        tmFecha.tm_min   = 0;
                        tmFecha.tm_sec   = 0;
                        tmFecha.tm_isdst = -1;

                        // Se intenta crear la fecha
                        if (mktime(&tmFecha) != -1)
                        {
                            // Verifica que no haya modificado la fecha
                            if (tmFecha.tm_year != intAnio ||
                                tmFecha.tm_mon  != intMes  ||
                                tmFecha.tm_mday != intDia)
                            {
                                // Error
                                resultado = false;                                                             
                            }
                            else
                            {
                                // Despliega
                                strftime(strFecha, sizeof(strFecha), "%c", &tmFecha);
                                cout << "[" << strFecha  << "]";
                            }                                                                
                        }
                        else                        
                           // Error
                           resultado = false;                            
                    }
                    else
                       // Cambia el Resultado
                       resultado = false;

                }
                else
                   // Error en Separadores
                   resultado = false;
            }
            else
               // Error en algunos de los datos
               resultado = false;
        }
    }
    else
       // Error en Longitud
       resultado=false;

    // Retorna
    return resultado;   
}

// Declaramos la función main
int main ()
{
    // Llama a la función
    cout << "Es Fecha 20-10-2009 con formato 0 ->" << fnEsFecha("20-10-2009",0) << endl;
    cout << "Es Fecha 10-09-2012 con formato 1 ->" << fnEsFecha("10-09-2012",1) << endl;
    cout << "Es Fecha 2010-09-12 con formato 2 ->" << fnEsFecha("2010-09-12",2) << endl;
    cout << endl;
    cout << "Es Fecha 2010-09-12 con formato 0 ->" << fnEsFecha("2010-09-12",0) << endl;
    cout << "Es Fecha 14-01-2009 con formato 1 ->" << fnEsFecha("14-01-2009",1) << endl;
    cout << "Es Fecha 10-09-2012 con formato 2 ->" << fnEsFecha("10-09-2012",2) << endl;    
    cout << endl;
    cout << "Es Fecha 14-1-2009 con formato 1 ->" << fnEsFecha("14-1-2009",1) << endl;
    cout << "Es Fecha 10-9-2012 con formato 2 ->" << fnEsFecha("10-9-2012",2) << endl;
    cout << "Es Fecha 2010-9-12 con formato 0 ->" << fnEsFecha("2010-9-12",0) << endl;    

    // Finaliza la Aplicación
    return 0;
}
