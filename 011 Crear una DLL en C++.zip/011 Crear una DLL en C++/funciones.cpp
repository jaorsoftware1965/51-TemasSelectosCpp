/*
Temas Selectos en C++
Crear una DLL en C++ con parámetros y retorno de valor
g++ -shared -o testlib.a -fPIC funciones.cpp
*/

// Incluímos las librerías
#include <iostream>

// Definición de espacios de nombre
using namespace std;

// Prototipo de la Función
extern "C" bool fnHolaMundo(char* persona);

// Función hola mundo
extern "C" bool fnHolaMundo(char* persona)
{
    // Variable auxiliar
    string aux;

    // Coloca la persona en la variable auxiliar
    aux = persona;

    // Verifica la longitud de la persona
    if (aux.length()>0)
    {
        // Mensaje
        cout << "Hola " << aux << "!" << endl;
        return true;
    }
    else
    {
        // Mensaje 
        cout << "No has enviado el nombre de la Persona" << endl;        
        return false;   
    }    
}

