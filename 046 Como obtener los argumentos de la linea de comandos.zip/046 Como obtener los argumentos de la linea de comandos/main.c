// ---------------------------------------------------------------
// Objetivo: Obtener los argumentos de la linea de Comandos
// ---------------------------------------------------------------

// Incluimos la librería
#include <stdio.h>
#include <stdlib.h>

// Función Principal de C
int main(int argc, char *argv[])
{
	// Variable para ciclo
	int resultado;

    // Verifico que argc sea mayor que 1
    if (argc == 2)
	{
		// Lanzo el Programa
		resultado = system(argv[1]);
	}
	else
	{
		printf("Solamente puede haber 2 argumentos.\nEjemplo:main dir\n\n");
		resultado = -1;
	}
	
	if (resultado==0)
	    printf("Ok ...");
	else
		printf("Err ...");
	return resultado;
}
