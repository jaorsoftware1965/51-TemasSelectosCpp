// -------------------------------------------------
// Lista 1
// Hacer un programa que reciba
// a) Uns lista ordenada y que elimine los numeros
//    repetidos
// b) Una lista en desorden y que elimine los numeros
//    repetidos
// -------------------------------------------------

// Se incluyen las librerias
#include <iostream>
#include <cstdlib>

// Define un espacio de nombres
using namespace std;

// Define la estructura del Nodo
struct nodo
{
   int          elemento;  // Los datos seran de tipo entero
   struct nodo *siguiente; // Puntero a siguiente elemento
};

// Puntero que ira siempre al final de la lista
nodo *finListaSinOrden; 
nodo *finListaConOrden;
nodo *finListaDepurada;

// Puntero a la cabeza de cada lista 
nodo *listaConOrden;
nodo *listaSinOrden;
nodo *listaDepurada;

// Vector para verificar si un elemento existe
int existentes[100];  // Máximo 100 elementos  
int indiceExistentes; // Para controlar cuantos hay existentes

// Prototipos de las Funciones a Usar
int  menuPrincipal(); 

// Captura la Lista de acuerdo al Orden indicado
void capturarLista(char orden);

// Despliega la Lista
void mostrarLista(char orden);

// Depura la lista de acuerdo al Orden indicado
void depurarLista(char orden);

// Inserta un Elemento a la lista al Final
void insertarEnLista(char orden,           // Indica cual Lista
                     int  numeroInsertar); // Elemento a Insertar

// Función que verifica si un numero existe
bool existeNumero(int numero);


// Programa Principal
int main(void)
{    
    // Inicializa las Listas
    listaConOrden = NULL;
    listaSinOrden = NULL;
    listaDepurada = NULL;

    // Variable
    int opcionSeleccionada; 

    // Ciclo para capturar la primera lista
    do
    {
        // Despliega el Menu Principal    
        opcionSeleccionada = menuPrincipal();        

        // Verifica que función realizar
        switch(opcionSeleccionada)
        {                
            case 1:
                    // Capturar lista Con Orden
                    capturarLista('C'); // C = Con Orden
                    break;

            case 2:
                    // Depurar lista Con Orden
                    mostrarLista('C'); // C = Con Orden
                    break;
            case 3:
                    // Depurar lista Sin Orden
                    depurarLista('C'); // C = Con Orden
                    break;

            case 4:
                    // Capturar lista Sin Orden
                    capturarLista('S'); // S = Sin Orden
                    break;

            case 5:
                    // Mostrar lista Sin Orden
                    mostrarLista('S'); // S = Sin Orden
                    break;
                    
            case 6:
                    // Depurar lista Sin Orden
                    depurarLista('S'); // S = Sin Orden
                    break;
            case 0: 
                    // Mensaje de Salida
                    cout << "El Programa Finalizara ...";
                    break;        
                    
            default:
                    // Mensaje de Opción No valida 
                    cout << "Opcion No Valida ...";
                    break;


        }

        // Cambia de Linea pausa el programa
        cout << endl << endl;
        system("pause");  

        // Limpia la pantalla
        system("cls");

    }while(opcionSeleccionada != 0);

    // Fin del Programa
    return 0;
}

// Despliega el menu Principal
int menuPrincipal()
{
    // Variable para Leer la Opción    
    int opcion;    

    // Despliega el Menun
    cout << "-------------------------------" << endl;
    cout << "Menu Principal                 " << endl;
    cout << "-------------------------------" << endl;
    cout << "1. Capturar Lista Con Orden    " << endl;
    cout << "2. Mostrar  Lista Con Orden    " << endl;
    cout << "3. Depurar  Lista Con Orden    " << endl << endl;    
    cout << "4. Capturar Lista Sin Orden    " << endl;    
    cout << "5. Mostrar  Lista Sin Orden    " << endl;
    cout << "6. Depurar  Lista Sin Orden    " << endl;
    cout << "0. Salir                       " << endl;
    cout << "Seleccione: ";
    
    // Lee la opción
    cin >> opcion;

    // Retorna
    return opcion;
}


// Función para Insertar en Lista Con Orden
void insertarEnLista(char orden,
                     int  numeroInsertar)
{
   // Define un Nuevo Nodo     
   nodo  *nuevo;

   // Crea el Nodo
   nuevo = new struct nodo;
   
   // Coloca el numero a Insertar
   nuevo->elemento = numeroInsertar;

   // Siguiente apunta a NULL
   nuevo->siguiente = NULL;

   // Verifica en cual lista insertar
   if (orden=='C')
   {
      // Lista Con Orden
      if (listaConOrden == NULL)
      {
         // Es el primer elemento;
         listaConOrden    = nuevo; // Lista apunta al Nuevo
         finListaConOrden = nuevo; // Final tambien al Nuevo
      }
      else
      {
         // El Nuevo Siguiente apunta a la 
         finListaConOrden -> siguiente = nuevo;
         finListaConOrden  = nuevo;         
     }
   }
   else
   {
      // Lista Sin Orden
      if (listaSinOrden == NULL)
      {
         // Es el primer elemento;
         listaSinOrden    = nuevo; // Lista apunta al Nuevo
         finListaSinOrden = nuevo; // Final tambien al Nuevo

         // Lo coloca en la lista de existentes
         existentes[indiceExistentes] = numeroInsertar;
         
         // Incrementa el indice de existentes
         indiceExistentes++;
      }
      else
      {
         // El Nuevo Siguiente apunta a la 
         finListaSinOrden->siguiente = nuevo;
         finListaSinOrden = nuevo;         
     }
   }  
}

// Captura la Lista de acuerdo al Orden indicado
void capturarLista(char orden)
{
   // Variable para capturar datos
   int numero;
   int anterior;

   // Verifica si es ordenada
   if (orden == 'C')
   {
      // Ciclo para leer la lista de Datos
      do
      {
         // Verifica si la lista ya tiene datos para obtener el mayor
         if (listaConOrden!=NULL)
            anterior = finListaConOrden->elemento;
         else
            anterior = -1;   
         // Ciclo para capturar los datos
         cout << "Capture el Dato Ordenado a Insertar (0-Finalizar)" << endl;
         cin >> numero;

         // Verifica que no sea negativo
         if (numero < 0)
         {
            cout << "Capture solo numeros mayores que 0; o 0 para salir" << endl;
            system("Pause");
         }
         else
         {
            // Verifica que no sea la salida
            if (numero !=0)
            {
               // Verifica que sea mayor que el anterior
               if (numero >= anterior)
               {
                  // Lo inserta
                  insertarEnLista('C',numero);

                  // Actualiza el Anterior
                  anterior = numero;
               }
               else
               {
                  cout << "Debes capturar un numero mayor o igual al anterior[" << anterior <<"]" << endl;
                  system("Pause");
               }
            }                              
         }
         // Verifica el Numero
      }while (numero != 0);      
   }
   else
   {
      // Ciclo para leer la lista de Datos
      do
      {
         // Ciclo para capturar los datos
         cout << "Capture el Dato a Insertar (0-Finalizar)" << endl;
         cin >> numero;

         // Verifica que no sea negativo
         if (numero < 0)
         {
            cout << "Capture solo numeros mayores que 0; o 0 para salir" << endl;
            system("Pause");
         }
         else
         {
            // Verifica que no sea la salida
            if (numero !=0)
            {
               // Lo inserta
               insertarEnLista('S',numero);               
            }                              
         }
         // Verifica el Numero
      }while (numero != 0);      
   }

   // Mensaje
   cout << "Has finalizado la captura de la Lista" << endl;
}

// Depura la lista de acuerdo al Orden indicado
void mostrarLista(char orden)
{
   // Apuntador para recorrer la lista
   nodo *lista;

   // Verifica cual lista va a mostrar
   if (orden=='C')
   {
      // Verifica que no esté vacía
      if (listaConOrden==NULL)
      {
         // Mensaje
         cout << "La Lista Con Orden esta vacia ..." << endl;
      }
      else
      {
         // Mensaje
         cout << "Los Elementos de la Lista Con Orden son:" << endl;

         // Obtiene el Apuntador
         lista = listaConOrden;

         while (lista!=NULL)
         {
            // Despliega el Dato
            cout << lista->elemento << endl;

            // Se desplaza al siguiente
            lista = lista->siguiente;
         }
      }      
   }
   else
   {
      // Verifica que no esté vacía
      if (listaSinOrden==NULL)
      {
         // Mensaje
         cout << "La Lista Sin Orden esta vacia ..." << endl;
      }
      else
      {
         // Mensaje
         cout << "Los Elementos de la Lista Sin Orden son:" << endl;

         // Obtiene la lista
         lista = listaSinOrden;

         while (lista!=NULL)
         {
            // Despliega el Dato
            cout << lista->elemento << endl;

            // Se desplaza al siguiente
            lista = lista->siguiente;
         }
      }
   }
}

// Depura la lista de acuerdo al Orden indicado
void depurarLista(char orden)
{
      
   // Variable para contar los eliminados
   int cuentaEliminados = 0;

   // Apuntador para recorrer la lista
   nodo *lista;
   nodo *nodoEliminar;

   // Mensake
   cout << "Depurando ..." << endl;

   // Varifica cual lista
   if (orden=='C')
   {
      // Verifica que haya elementos en la lista
      if (listaConOrden==NULL)
      {
         // Mensaje
         cout << "La lista Con Orden esta vacia ..." << endl;
      }
      else
      {      
         // Obtengo el apuntador a la lista
         lista = listaConOrden;

         // Ciclo
         while (lista!=NULL)
         {
            // Verifica que el siguiente no sea null
            if (lista->siguiente!=NULL)
            {
               // Actualiza el final
               finListaConOrden = lista;

               // Compara que sea igual que el siguiente
               if (lista->elemento == lista->siguiente->elemento)
               {
                  //Obtiene el Nodo a eliminar
                  nodoEliminar = lista->siguiente;

                  // Salta el Elemento siguiente
                  lista->siguiente = lista->siguiente->siguiente;

                  // Elimina el Nodo
                  delete nodoEliminar;

                  // Incrementa el Contador de Eliminados
                  cuentaEliminados++;
               }
               else
               {
                  // Desplaza lista a siguiente
                  lista = lista->siguiente;
               }               
            }
            else
            {
               // Desplaza lista a siguiente
               lista = lista->siguiente;
            }
         }
         
      }
   }
   else
   {
      // Depuración para lista Sin Orden      
      // Verifica que haya elementos en la lista
      if (listaSinOrden==NULL)
      {
         // Mensaje
         cout << "La lista Sin Orden esta vacia ..." << endl;
      }
      else
      {      
         // inicializa el vector de existente con 0
         for (int x=0; x<100; x++)
         {
             // Le coloca 0
             existentes[x] = 0;
         }

         // Coloco el primer elemento de la lista en el vector
         existentes[0] = listaSinOrden->elemento;

         // Inicializo el indice
         indiceExistentes = 0;

         // Obtengo el apuntador a la lista
         lista = listaSinOrden;

         // Ciclo
         while (lista!=NULL)
         {
            // Verifica que el siguiente no sea null
            if (lista->siguiente!=NULL)
            {
               // Actualiza el final
               finListaSinOrden = lista;

               // Verifica que el elemento siguiente ya exista
               if (existeNumero(lista->siguiente->elemento))
               {
                  //Obtiene el Nodo a eliminar
                  nodoEliminar = lista->siguiente;

                  // Salta el Elemento siguiente
                  lista->siguiente = lista->siguiente->siguiente;

                  // Elimina el Nodo
                  delete nodoEliminar;

                  // Incrementa el Contador de Eliminados
                  cuentaEliminados++;
               }
               else
               {
                  // Incrementa el indice de existente
                  indiceExistentes++;
                  
                  // Coloca el elemento en el vector
                  existentes[indiceExistentes] = lista->siguiente->elemento;

                  // Desplaza lista a siguiente
                  lista = lista->siguiente;
               }               
            }
            else
            {
               // Desplaza lista a siguiente
               lista = lista->siguiente;
            }
         }
         
      }    
   }

   // Mensaje
   cout << "La lista ha sido depurada " << endl;
   cout << "Se eliminaron [" << cuentaEliminados << "] elementos" << endl;
}

// Verifica si un número existe
bool existeNumero(int numero)
{
   // variable para resultado
   bool loEncontro=false;

    // Ciclo para verificar
    for (int indice=0; indice<=indiceExistentes; indice++)
    {
       // Compara
       if (numero == existentes[indice])
       {
          // Lo encontro
          loEncontro=true;

          // Sale del Ciclo ya que ya no debe seguir buscando
          break;
       }
    }

    // Retorna
    return loEncontro;
}