// ------------------------------------------------------------------------------
// Objetivo : Separar las Claves y Valores de una Cadena
// Ejemplo:
// Sea la cadena:"Nombre=Juan Perez, Edad=20, Genero=Hombre"
// La Función deberá devolver un vector con:Nombre,Edad y Género
// La Función deberá devolver un vector con:Juan Perez, 20 y Hombre

// Incluimos las librerías necesarias
#include <fstream>
#include <iostream>
#include <vector>

// El nombre de Espacio
using namespace std;

// Función que devuelve cadena con el lado izq o der de un caracter

// Ejemplo: fnObtenerDato("Nombre=Juan Perez",'=','I');
// Lo anterior devuelve: Nombre

// Ejemplo: fnObtenerDato("Nombre=Juan Perez",'=','D');
// Lo anterior devuelve: Juan Perez
string fnObtenerDato(string cadena,char separador,char lado);

// Función que devuelve las claves
vector<string> fnObtenerClavesValores(string cadena, char dato);

// Función principal
int main()
{

    // Prueba de la función para obtener dato
    cout << fnObtenerDato("Nombre=JAOR",'=','I') << endl;
	cout << fnObtenerDato("Nombre=JAOR",'=','D') << endl;	
	cout << fnObtenerDato("Nombre=Juan Perez, Edad=20, Genero=Hombre",',','I') << endl;
	cout << endl;

	// Llama a función que obtiene las claves
    auto lstClaves = fnObtenerClavesValores("Nombre=Juan Perez,Edad=20,Genero=Hombre",'C');

	// Ciclo para desplegarlo
	cout << "Lista de Claves" << endl;
	for (int indice=0; indice < lstClaves.size(); indice++)
	{
		// Imprime las Clave
		cout << lstClaves[indice] << endl;		
	}
	cout << "..." << endl;

	// Llama a función que obtiene los valores
    auto lstValores = fnObtenerClavesValores("Nombre=Juan Perez, Edad=20, Genero=Hombre",'V');

    // Ciclo para desplegarlo
	cout << "Lista de Valores" << endl;
	for (int indice=0; indice < lstValores.size(); indice++)
	{
		// Imprime las Clave
		cout << lstValores[indice] << endl;		
	}
		
	// Finaliza	
	return 0;
}


// Función que devuelve cadena con el lado izq o der de un caracter
string fnObtenerDato(string cadena,char separador,char lado)
{
	// Variable para el Resultado
	string resultado="";

	// Variable para la posición donde encuentra el separador
	int posicionSeparador;

	// Busca el separador
	posicionSeparador = cadena.find(separador);

	// Verifica que lo haya encontrado
    if (posicionSeparador >= 0)
	{
		// Verifica que lado hay que retornar
		if (lado=='I' || lado=='i')
		{
           // Coloca el resultado
		   resultado = cadena.substr(0,posicionSeparador);
		}
		else
		    if (lado=='D' || lado=='d')
			{
		   	   // Coloca el resultado
		  	   resultado = cadena.substr(posicionSeparador+1);
			}		
	}
	
	// Devuelve el resultado
	return resultado;
}

// Función que devuelve las claves
vector<string> fnObtenerClavesValores(string cadena, char dato)
{
	// Vector de Resultados
	vector<string> resultado;

	// Variable para obtener cada dato
	string tmpDato;

	// Posición de separador
	int posicionSeparador;

	// Verifica que dato
	if (dato=='C' || dato=='c')
	{
		// Devolverá valores
        while (true)
		{
			// busca el separador
			posicionSeparador = cadena.find(",");

			// Si es mayor que 0
			if (posicionSeparador>=0)
			{
				// Obtiene el dato
			    tmpDato = fnObtenerDato(cadena,',','I');

				// Agrego al vector el dato izquierdo
				resultado.push_back(fnObtenerDato(tmpDato,'=','I'));

				// Obtengo la parte restanted e la cadena
				cadena = fnObtenerDato(cadena,',','D');
			}
			else
			   // Sale del Ciclo
			   break;			
		}

		// Agrega al resultado la parte izquierda del valor restante
		resultado.push_back(fnObtenerDato(cadena,'=','I'));
	}
	else
		if (dato=='V' || dato=='v')
		{
			// Devolverá valores
			while (true)
			{
				// busca el separador
				posicionSeparador = cadena.find(",");

				// Si es mayor que 0
				if (posicionSeparador>=0)
				{
					// Obtiene el dato
					tmpDato = fnObtenerDato(cadena,',','I');

					// Agrego al vector el dato izquierdo
					resultado.push_back(fnObtenerDato(tmpDato,'=','D'));

					// Obtengo la parte restante e la cadena
					cadena = fnObtenerDato(cadena,',','D');
				}
				else
				// Sale del Ciclo
				break;			
			}

			// Agrega al resultado la parte izquierda del valor restante
			resultado.push_back(fnObtenerDato(cadena,'=','D'));
		}

	// Ciclo para separar datos y buscar valores
    return resultado;
}