// -----------------------------------------------------
// mysql.c
// La Biblia de como conectar a mySql desde C en Windows
// gcc mysql.c -LC libmysql.lib
// -----------------------------------------------------

// Se incluyen los encabezados de mysql
#include "mysql/mysql.h"
#include "stdio.h"

// Función Principal
int main()
{
	// Variable de Mensaje
	char sMensaje[50]="Conexion MySql";
  
  // Despliega el Mensaje
  puts(sMensaje);

  // Variable de Conexión
  MYSQL *conn;

  // Variable para la Consulta
  MYSQL_RES *res;

  // Variable para el ROW
  MYSQL_ROW row;

  // Dirección del Servidor
  char* sServer="localhost";

  // Nombre del Usuario
  char* sUsuario="root";

  // Password del Usuario
  char* sPassword="";

  // Base de Datos
  char* sBaseDatos="";

  // Inicializa a null la conexion
  conn = mysql_init(NULL);

  if (mysql_real_connect(conn, sServer, sUsuario, sPassword, sBaseDatos, 0, NULL, 0) == NULL)
  {
      // Despliega el Error
      puts(mysql_error(conn));

      // Salida con 1
      exit(1);
    }

  // Ejecuta consulta
  if (mysql_query(conn,"SHOW DATABASES"))
  {
      // Despliega el Error
      puts(mysql_error(conn));

      // Salida con 1
      exit(1);
  }

  // Obtiene los resultados
  res = mysql_use_result(conn);

  // Despliega Encabezados
  puts("Bases de Datos");
  puts("--------------");

  // Ciclo para recorrer los resultados
  while ((row = mysql_fetch_row(res))!=NULL)
  {
      // Despliega los datos
      printf("%s \n",row[0]);
  }


  // libera los resultados
  mysql_free_result(res);

  // Sale de la aplicación
  exit(0);
}
