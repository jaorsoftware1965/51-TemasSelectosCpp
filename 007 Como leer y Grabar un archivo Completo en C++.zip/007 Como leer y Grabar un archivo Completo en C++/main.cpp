// ---------------------------------------------
// Tareas y Temas Selectos de C, C++
// Como leer todo un archivo en C++ y averiguar
// su longitud
// ---------------------------------------------

// Incluimos las librerías necesarias
#include <fstream>
#include <iostream>

// El nombre de Espacio
using namespace std;

// Función para Leer un Archivo
string fnArchivoLeer(string nombreArchivo)
{
   // Variable para el Resultado
   string resultado="";

   // Declara una variable y lee el archivo
   ifstream isArchivo (nombreArchivo.c_str(), 
                       ifstream::binary);   

   // Verifico que haya podido leer el archivo
   if (isArchivo)
   {
      // moverse al final del archivo
      isArchivo.seekg (0, isArchivo.end);

      // Obtener la longitud
      int longitudArchivo = isArchivo.tellg();
      cout << "Longitud " << longitudArchivo << endl;

      // Moverse de nuevo al principio
      isArchivo.seekg (0, isArchivo.beg);

      // Crea un buffer para lectura
      char* bufferLectura = new char [longitudArchivo];

      // Lee desde el Archivo
      isArchivo.read(bufferLectura,longitudArchivo);

      // Coloca lo leido en resultado
      resultado = bufferLectura;
   }
   else
      printf("Ocurrió un Error al Leer el Archivo");

   return resultado;
}

// Función Principal
int main(int argc, char *argv[]) //auto
{
   // Variable para el contenido del archivo
   string contenidoArchivo;
   string archivo;

   // Mensajes 
   cout << "Nombre del Archivo a leer:" << endl;
   cin >> archivo;

   // Obtiene el contenido del archivo
   contenidoArchivo = fnArchivoLeer(archivo);

   // Despliega el Contenido
   cout << contenidoArchivo << endl;

   // Despliega la longitud   
   cout << "Longitud del Archivo:" << contenidoArchivo.size();

	// Finaliza con 0
	return 0;
}
