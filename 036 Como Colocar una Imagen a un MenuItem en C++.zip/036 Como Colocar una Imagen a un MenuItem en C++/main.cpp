// -----------------------------------------------------------
// Tareas y Temas Selectos de C, C++
// Colocar un imagen a un Item de un Menu
// -----------------------------------------------------------

// Inclusi�n de la Cabecera de Windows
#include "windows.h"

#define ID_TIMER     1
#define IDM_FILE_NEW 40001
#define IDM_FILE_OPEN 40002
#define IDM_FILE_SAVE 40003
#define IDM_FILE_SAVE_AS 40004
#define IDM_APP_EXIT 40005
#define IDM_EDIT_UNDO 40006
#define IDM_EDIT_CUT 40007
#define IDM_EDIT_COPY 40008
#define IDM_EDIT_PASTE 40009
#define IDM_EDIT_CLEAR 40010
#define IDM_BKGND_WHITE 40011
#define IDM_BKGND_LTGRAY 40012
#define IDM_BKGND_GRAY 40013
#define IDM_BKGND_DKGRAY 40014
#define IDM_BKGND_BLACK 40015
#define IDM_TIMER_START 40016
#define IDM_TIMER_STOP 40017
#define IDM_APP_HELP 40018
#define IDM_APP_ABOUT 40019

// Prototipo Funci�n que procesa los mensajes
LRESULT CALLBACK WndProc (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

// Variable para el Nombre de la Clase
TCHAR szAppName[] = TEXT ("claseMenu") ;


// Funci�n Principal
int WINAPI WinMain (HINSTANCE hInstance,      // instancia de la aplicaci�n
                    HINSTANCE hPrevInstance,  // Instancia previa
                    PSTR      szCmdLine,      // Argumentos de la aplicaci�n
   				    int       iCmdShow)       //
{

	// Variable para el Manejador de la Ventana
	HWND hwnd;

	// Variable para el Manejo de Mensajes
	MSG msg;

	// Variable para la estructura de la Ventana
	WNDCLASS wndclass;

	// Define la Ventana
	wndclass.style = CS_HREDRAW | CS_VREDRAW ;  // Estilo
	wndclass.lpfnWndProc = WndProc ;            // Funci�n que procesa los mensajes
	wndclass.cbClsExtra = 0 ;                   // Cuantos bytes se reservan extra en la estructura de la Clase
	wndclass.cbWndExtra = 0 ;                   // Cuantos bytes se reservan extra a continuaci�n de la instancia
	wndclass.hInstance = hInstance ;			// Instancia a la que pertenece la ventana
	wndclass.hIcon = LoadIcon (NULL, IDI_APPLICATION) ; // Icono de la Ventana
	wndclass.hCursor = LoadCursor (NULL, IDC_ARROW) ;   // Cursor que se usar� en la ventana
	wndclass.hbrBackground = (HBRUSH) GetStockObject (WHITE_BRUSH) ;  // Pincel que utilizar� la ventana
	//wndclass.lpszMenuName = NULL ;        // Puntero a un recurso de Menu
	wndclass.lpszMenuName = szAppName ;        // Puntero a un recurso de Menu
	wndclass.lpszClassName = szAppName ;  // Nombre de la Clase

	// Intenga registrar la clase
	if (!RegisterClass (&wndclass))
	{
		// Si no se puede registrar manda un mensaje
		MessageBox (NULL, TEXT ("Este programa requiere Windows NT!"),
		            szAppName, MB_ICONERROR) ;
		return 0 ;
	}

	// Crea la Ventana
	hwnd = CreateWindow (szAppName,    // nombre de la clase
						 TEXT ("Creando un Menu"), // titulo de la ventana
						 WS_OVERLAPPEDWINDOW, // Estilo de la Ventana
						 CW_USEDEFAULT, // x posici�n
						 CW_USEDEFAULT, // y posici�n
						 CW_USEDEFAULT, // ancho
						 CW_USEDEFAULT, // alto
						 NULL, // Manejador de la VEntana Padre
						 NULL, // Manejador del Menu o Ventana hija
						 hInstance, // Instancia de la Aplicaci�n
						 NULL) ; // Puntero a par�metros de creaci�n

	// Muestra la Ventana
	ShowWindow (hwnd,       // Manejador de la Ventana
	            iCmdShow) ; // Modo de Visualizaci�n

	// Actualiza la Ventana
	UpdateWindow (hwnd) ;

	// Ciclo que procesa los mensajes mientras haya en la cola
	while (GetMessage (&msg, NULL, 0, 0))
	{
		// Mientras haya mensajes los traslada y despacha
		TranslateMessage (&msg) ;
		DispatchMessage (&msg) ;
	}
	// Retorna el wParam del mensaje
	return msg.wParam ;
}

// Funci�n que procesa los mensajes
LRESULT CALLBACK WndProc (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	// Variable para el Manejo de Colores
	static int idColor [5] = { WHITE_BRUSH, LTGRAY_BRUSH, GRAY_BRUSH,DKGRAY_BRUSH, BLACK_BRUSH } ;
	
	// Variable para la Seleccion
	static int iSelection = IDM_BKGND_WHITE ;
	
	// Variable para el Menu
	HMENU hMenu ;
	
	// Procesamiento de Mensajes
	switch (message)
	{		    
		// Verifica que el evento sea destruir
		case WM_CREATE:

         	 // Obtenemos el Manejador del Menu
			 hMenu = GetMenu(hwnd);
			 
    		 // Declara variable para cargar la imagen
 			 HBITMAP imagen;
			
			 // Carga el Bitmap
			 imagen = (HBITMAP)LoadImage(NULL, "imagen_item.bmp", IMAGE_BITMAP, 0, 0, LR_DEFAULTSIZE | LR_LOADFROMFILE);
						 
			 // Agrega la opci�n como Icono Bmp
			 SetMenuItemBitmaps(hMenu, IDM_APP_EXIT, MF_BYCOMMAND ,imagen, imagen);
			 			             
			 return 0 ;			 
	
		// Verifica que el evento sea destruir
		case WM_DESTROY:
    		 PostQuitMessage (0) ;
			 return 0 ;			 
			 
		case WM_COMMAND:
		     
			 // Obtenemos el Manejador del Menu
			 hMenu = GetMenu(hwnd) ;
			 
			 // Verificamos la parte baja del wParam que es en donde viene el ID
			 switch (LOWORD (wParam))
			 {
				case IDM_FILE_NEW:
				case IDM_FILE_OPEN:
				case IDM_FILE_SAVE:
				case IDM_FILE_SAVE_AS:
					 MessageBeep (0) ;
					 return 0 ;
				case IDM_APP_EXIT:
					 SendMessage (hwnd, WM_CLOSE, 0, 0) ;
					 return 0 ;
				case IDM_EDIT_UNDO:
				case IDM_EDIT_CUT:
				case IDM_EDIT_COPY:
				case IDM_EDIT_PASTE:
				case IDM_EDIT_CLEAR:
					 MessageBeep (0) ;
					 return 0 ;
				case IDM_BKGND_WHITE: // Note: Logic below
				case IDM_BKGND_LTGRAY: // assumes that IDM_WHITE
				case IDM_BKGND_GRAY: // through IDM_BLACK are
				case IDM_BKGND_DKGRAY: // consecutive numbers in
				case IDM_BKGND_BLACK: // the order shown here.		
					 CheckMenuItem (hMenu, iSelection, MF_UNCHECKED) ;
					 iSelection = LOWORD (wParam) ;
					 CheckMenuItem (hMenu, iSelection, MF_CHECKED) ;
					 SetClassLong (hwnd, GCL_HBRBACKGROUND, (LONG)
					 GetStockObject(idColor [LOWORD (wParam) - IDM_BKGND_WHITE])) ;
					 InvalidateRect (hwnd, NULL, TRUE) ;
					 return 0 ;
				case IDM_TIMER_START:
					 if (SetTimer (hwnd, ID_TIMER, 1000, NULL))
					 {
						EnableMenuItem (hMenu, IDM_TIMER_START, MF_GRAYED) ;
						EnableMenuItem (hMenu, IDM_TIMER_STOP, MF_ENABLED) ;
					 }
					 return 0 ;
				case IDM_TIMER_STOP:
					 KillTimer (hwnd, ID_TIMER) ;
					 EnableMenuItem (hMenu, IDM_TIMER_START, MF_ENABLED) ;
					 EnableMenuItem (hMenu, IDM_TIMER_STOP, MF_GRAYED) ;
					 return 0 ;
				case IDM_APP_HELP:
					 MessageBox (hwnd, TEXT ("Help not yet implemented!"),
					 szAppName, MB_ICONEXCLAMATION | MB_OK) ;
					 return 0 ;
				case IDM_APP_ABOUT:
					 MessageBox (hwnd, TEXT ("Programa Menu\n"),
					 szAppName, MB_ICONINFORMATION | MB_OK) ;
					 return 0 ;
			 }
			 break ;
		case WM_TIMER:
			MessageBeep (0) ;
			return 0 ;
	}

	// Retorna el Control a la Funci�n
	return DefWindowProc (hwnd, message, wParam, lParam) ;
}
