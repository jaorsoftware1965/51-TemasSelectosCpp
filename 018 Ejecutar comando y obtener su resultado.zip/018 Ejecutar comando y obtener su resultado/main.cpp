// ---------------------------------------------------------------
// Objetivo: Ejecutar comandos del Sistema operativo y obtener
// el resultado desplegado
// ---------------------------------------------------------------

// Librerias Necesarias
#include <iostream>

// Espacio de nombres
using namespace std;

// Función principal
int main ()
{
	// Variable de Resultado
	bool resultado = true;

	// Apuntador a un manejador de Archivo
	FILE* in;

	// El buffer para leer datos
	char buffer[512];

	// Para el Comando
	char comando[512];

	// Capure el comando a ejecutar
	cout << "Capture el Comando:";
	gets(comando);

    // Ejecuta y valida 
	if (!(in = popen(comando,"r")))
	{
		// Variable de Resultado
		resultado = EXIT_FAILURE;
	}
	else
	{
		// Ciclo para Leer desde el archivo los datos
		while (fgets(buffer,sizeof(buffer),in) != NULL)
		{
			// Despliega
			cout << ">" << buffer;
		}
	}

	// Cierra el archivo
	cout << "El valor de retorno:" << pclose(in);
	
	// Finaliza
	return resultado;
}