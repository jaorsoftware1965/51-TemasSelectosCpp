// ---------------------------------------------------------------
// Objetivo: Obtener la ruta del Executable
// ---------------------------------------------------------------

// Incluimos la librería
#include <stdio.h>
#include <stdlib.h>


// Función Principal de C
int main(int argc, char *argv[])
{
	// Definimos variable para la ruta
	 char basePath[255] = "";
    _fullpath(basePath, argv[0], sizeof(basePath));

	// Despliega
	printf("El Ejecutable es:%s \n",argv[0]);
	printf("La Ruta con ejecutable es:%s\n",basePath);	
}
