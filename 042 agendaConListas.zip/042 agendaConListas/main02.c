// -----------------------------------------------------------------------
// main.c
// Desarrollo de una Agenda usando Listas Doblemente Enlazadas
// -----------------------------------------------------------------------

// Se Incluyen librerias de C
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>

// Variables Booleanas
#define TRUE  1
#define FALSE 0

// Variable Global para el Conteo de los Eventos
int gEventosContador = 0;

// Se define la Estructura del Nodo
struct stcNodo
{
    // Definición del Evento
    int  idEvento;      // Identificador del Evento
    char fecha[11];     // Ejemplo 2019-05-09
    char hora[6];       // 23:34
    char lugar[51];     // Plaza Culturas
    char actividad[51]; // Tarea de Programación

    // Los Apuntadores a Siguiente y Anterior
    struct stcNodo *pSiguiente;
    struct stcNodo *pAnterior;
};

// Se define un tipo de acuerdo a la estructura
typedef struct stcNodo nodoEvento;


// Función para verificar si una Lista Enlazada está vacía
int FnIntListaVacia(nodoEvento *pCabeza);

// Función para crear un Nodo
nodoEvento *FnNodoCrea(int  idEvento, char* fecha, char* hora, char* lugar, char* actividad);

// Función para Insertar un Elemento al Frente de la Lista Doblemente Enlazada
void SbListaDobleInsertarFrente(nodoEvento **pCabeza, int idEvento, char* lugar, char* fecha, 
                                char* hora, char* actividad);

// Función para Eliminar un Elemento del Frente de la Lista Doble
nodoEvento FnNodoListaDobleEliminaFrente(nodoEvento **pCabeza);

// Función para Eliminar un Elemento del Final de la Lista Doble
nodoEvento FnNodoListaDobleEliminaFinal(nodoEvento **pCabeza,nodoEvento **pCola);

// Función para Eliminar un Elemento Específico
nodoEvento FnNodoListaDobleElimina(nodoEvento **pCabeza,nodoEvento **pCola,int idEvento);

// Función para Insertar un Elemento al Final de la Lista Doblemente Enlazada
void SbListaDobleInsertarFinal(nodoEvento **pCabeza, nodoEvento **pCola, int idEvento, char* fecha, 
                               char* hora, char* lugar, char* actividad);

// Función para Insertar un Elemento en la Lista Doblemente Enlazada
void SbListaDobleInsertar(nodoEvento **pCabeza, nodoEvento **pCola, int idEvento, char* fecha, 
                          char* hora, char* lugar,  char* actividad, int idReferencia, 
                          int iInsertarDespuesDe);

// Función para desplegar la Lista
void SbListaDobleDespliegaFull(nodoEvento *pCabeza,nodoEvento *pCola,int iOrdenNormal);

// Función para Buscar un Elemento
int FnIntListaBuscaNodo(nodoEvento *pCabeza,int idEvento);

// Función Principal de C
int main()
{
    // Mensaje de la Clase
    printf("Curso de Algoritmos y Estructuras de Datos en C \n");
    printf("Clase 26 - Listas Doblemente Enlazadas III\n\n");

    // // Declaramos apuntadores de Cabeza y Cola
    nodoEvento *pCabeza=NULL;
    nodoEvento *pCola=NULL;

    // Variable Nodo para Eliminar
    nodoEvento xNodo;

    // // Insertamos 3 elementos
    SbListaDobleInsertarFinal(&pCabeza,&pCola,10,"fecha","hora","lugar","Actividad");
    SbListaDobleInsertarFinal(&pCabeza,&pCola,20,"fecha","hora","lugar","Actividad");
    SbListaDobleInsertarFinal(&pCabeza,&pCola,30,"fecha","hora","lugar","Actividad");

    // Desplegamos
    SbListaDobleDespliegaFull(pCabeza,pCola,TRUE);

    // Insertamos Antes en Medio
    SbListaDobleInsertar(&pCabeza,&pCola,15,"fecha","hora","lugar","Actividad",20,FALSE);

    // Insertamos Despues en Medio
    SbListaDobleInsertar(&pCabeza,&pCola,25,"fecha","hora","lugar","Actividad",20,TRUE);

    // Desplegamos
    SbListaDobleDespliegaFull(pCabeza,pCola,TRUE);

    // Insertamos Antes del Frente
    SbListaDobleInsertar(&pCabeza,&pCola,5,"fecha","hora","lugar","Actividad",10,FALSE);

    // Insertamos Despues del Final
    SbListaDobleInsertar(&pCabeza,&pCola,35,"fecha","hora","lugar","Actividad",30,TRUE);

    // Desplegamos
    SbListaDobleDespliegaFull(pCabeza,pCola,TRUE);

    // Intentamos Eliminar un Elemeno que no existe
    xNodo = FnNodoListaDobleElimina(&pCabeza,&pCola,75);

    // Eliminamos de enmedio
    xNodo = FnNodoListaDobleElimina(&pCabeza,&pCola,15);

    // Desplegamos Información del Nodo Eliminado
    printf("Información del Nodo:%d Sigte:%p Anter:%p\n",xNodo.idEvento,xNodo.pSiguiente,xNodo.pAnterior);

    // Desplegamos
    SbListaDobleDespliegaFull(pCabeza,pCola,TRUE);

    // Eliminamos del Frente
    xNodo = FnNodoListaDobleElimina(&pCabeza,&pCola,5);

    // Desplegamos Información del Nodo Eliminado
    printf("Información del Nodo:%d Sigte:%p Anter:%p\n",xNodo.idEvento,xNodo.pSiguiente,xNodo.pAnterior);

    // Eliminamos del Final
    xNodo = FnNodoListaDobleElimina(&pCabeza,&pCola,35);

    // Desplegamos Información del Nodo Eliminado
    printf("Información del Nodo:%d Sigte:%p Anter:%p\n",xNodo.idEvento,xNodo.pSiguiente,xNodo.pAnterior);

    // Desplegamos
    SbListaDobleDespliegaFull(pCabeza,pCola,TRUE);

    // // Eliminamos del Frente
    xNodo = FnNodoListaDobleElimina(&pCabeza,&pCola,20);

    // Eliminamos del Frente
    xNodo = FnNodoListaDobleElimina(&pCabeza,&pCola,25);

    // Eliminamos del Frente
    xNodo = FnNodoListaDobleElimina(&pCabeza,&pCola,30);

    // Eliminamos del Frente
    xNodo = FnNodoListaDobleElimina(&pCabeza,&pCola,10);

    // Desplegamos
    SbListaDobleDespliegaFull(pCabeza,pCola,TRUE);

    // Insertamos 3 elementos
    SbListaDobleInsertarFinal(&pCabeza,&pCola,11,"fecha","hora","lugar","Actividad");
    SbListaDobleInsertarFinal(&pCabeza,&pCola,22,"fecha","hora","lugar","Actividad");
    SbListaDobleInsertarFinal(&pCabeza,&pCola,33,"fecha","hora","lugar","Actividad");

    // Desplegamos
    SbListaDobleDespliegaFull(pCabeza,pCola,TRUE);

    // Finaliza la aplicación retornando 0
    return 0;
}


// Función para verificar si una Lista Enlazada está vacía
int FnIntListaVacia(nodoEvento *pCabeza)
{
   // Verifica si está apuntando a Null
   if (pCabeza==NULL)
   {
      printf("La Lista está vacía \n");
      return TRUE;
   }
   else
   {
      printf("La Lista no está vacía \n");
      return FALSE;
   }
}

// Función para crear un Nodo
nodoEvento *FnNodoCrea(int  idEvento,
                       char* fecha, 
                       char* hora, 
                       char* lugar,
                       char* actividad)
{
   // Defino una variable de tipo Apuntador Nodo
   nodoEvento *xNodo;

   // Reservo la Memoria para el Nodo
   xNodo = (nodoEvento *)malloc(sizeof(nodoEvento));

   // Verifico que haya podido reservar memoria
   if (xNodo == NULL)
      // Despliega el Mensaje de Error
      printf("Error. No se pudo reservar memoria para el Nodo");
   else
   {
      // Asigna la Información al Nodo
      xNodo->idEvento = idEvento;     // El Dato
      strcpy(xNodo->fecha,"");
      strcpy(xNodo->hora,"");  
      strcpy(xNodo->lugar,"");
      strcpy(xNodo->actividad,"");
      xNodo->pSiguiente = NULL; // Apunta a Null
      xNodo->pAnterior = NULL; // Apunta a Null
   }

   //Retorna el resultado
   return xNodo;
}

// Función para Insertar un Elemento al Frente de la Lista Doblemente Enlazada
void SbListaDobleInsertarFrente(nodoEvento **pCabeza, 
                                int        idEvento,
                                char*      lugar,
                                char*      fecha,
                                char*      hora,
                                char*      actividad)
{
    // Crear el Nodo Nuevo con el Valor Correspondiente.
    nodoEvento *pNodoNuevo;

    // Crea un Nuevo Nodo apuntando a Null
    pNodoNuevo=FnNodoCrea(idEvento, fecha, hora, lugar, actividad);

    // Verifica si está vacía ( Mandamos con pCola en lugar de pCabeza)
    if (FnIntListaVacia(*pCabeza))
    {
        // b) Siguiente y anterior apunta a NULL
        pNodoNuevo->pSiguiente = NULL;
        pNodoNuevo->pAnterior = NULL;

        // c) Hacer que Cabeza apunte al Nodo Nuevo.
        *pCabeza=pNodoNuevo;

        // Mensaje
        printf("Inserción Lista Doblemente Enlazada Vacía; Elemento %d en dirección %p \n\n",idEvento,pNodoNuevo);
    }
    else
    {
        // b) Hacer que CABEZA->Anterior apunte al Nuevo Nodo
        (*pCabeza)->pAnterior = pNodoNuevo;

        // c) Hacer que el Nuevo Nodo->Siguiente Apunte al Nodo que apunta Cabeza
        pNodoNuevo->pSiguiente = *pCabeza;

        // d) Hacer que el Nuevo Nodo->Anterior apunte a NULL
        pNodoNuevo->pAnterior = NULL;

        // e) Hacer que CABEZA Apunte al Nvo Nodo
        *pCabeza = pNodoNuevo;

        // Mensaje
        printf("Inserción Inicio Lista Doblemente Enlazada Elemento %d en dirección %p \n\n",idEvento,pNodoNuevo);
    }
}

// Función para Eliminar un Elemento del Frente de la Lista Doble
nodoEvento FnNodoListaDobleEliminaFrente(nodoEvento **pCabeza)
{

    // Definimos un Apuntador a un Nodo
    nodoEvento xNodo;


    // Inicializa
    xNodo.idEvento=-1;
    strcpy(xNodo.fecha,"");
    strcpy(xNodo.hora,"");  
    strcpy(xNodo.lugar,"");
    strcpy(xNodo.actividad,"");
    xNodo.pSiguiente=NULL;
    xNodo.pAnterior=NULL;

    // Verifica si está vacía ( Mandamos con pCola en lugar de pCabeza)
    if (FnIntListaVacia(*pCabeza))
    {
        // Mensaje
        printf("La Lista Doblemente Enlazada está vacía, no es posible eliminar Elementos \n\n");
    }
    else
    {
        // Obtenemos la información del Nodo a Eliminar
        xNodo.idEvento      = (*pCabeza)->idEvento;
        xNodo.idEvento      = (*pCabeza)->idEvento;
        strcpy(xNodo.fecha,(*pCabeza)->fecha);
        strcpy(xNodo.hora,(*pCabeza)->hora);
        strcpy(xNodo.lugar,(*pCabeza)->lugar);
        strcpy(xNodo.actividad,(*pCabeza)->actividad);
        xNodo.pSiguiente = (*pCabeza)->pSiguiente;
        xNodo.pAnterior  = (*pCabeza)->pAnterior;

        // a) Liberar el Nodo a que apunta CABEZA
        free(*pCabeza);

        // b) Cabeza apunta ahora a Cabeza->Siguiente
        *pCabeza = (*pCabeza)->pSiguiente;

        // c) Cabeza->Anterior = NULL
        if (*pCabeza!=NULL)
           (*pCabeza)->pAnterior = NULL;

        // Mensaje
        printf("Eliminación Frente Lista Doblemente Enlazada Elemento:%d Sigte:%p Anter:%p \n\n",xNodo.idEvento,xNodo.pSiguiente,xNodo.pAnterior);

    }

    // Retorna el Nodo
    return xNodo;
}

// Función para Eliminar un Elemento del Final de la Lista Doble
nodoEvento FnNodoListaDobleEliminaFinal(nodoEvento **pCabeza,nodoEvento **pCola)
{

    // Definimos un Apuntador a un Nodo
    nodoEvento xNodo;

    // Inicializa
    xNodo.idEvento=-1;
    strcpy(xNodo.fecha,"");
    strcpy(xNodo.hora,"");  
    strcpy(xNodo.lugar,"");
    strcpy(xNodo.actividad,"");
    xNodo.pSiguiente=NULL;
    xNodo.pAnterior=NULL;

    // Verifica si está vacía ( Mandamos con pCola en lugar de pCabeza)
    if (FnIntListaVacia(*pCabeza))
    {
        // Mensaje
        printf("La Lista Doblemente Enlazada está vacía, no es posible eliminar Elementos \n\n");
    }
    else
    {
        // Obtenemos la información del Nodo a Eliminar
        xNodo.idEvento      = (*pCola)->idEvento;
        strcpy(xNodo.fecha,(*pCabeza)->fecha);
        strcpy(xNodo.hora,(*pCabeza)->hora);
        strcpy(xNodo.lugar,(*pCabeza)->lugar);
        strcpy(xNodo.actividad,(*pCabeza)->actividad);
        xNodo.pSiguiente = (*pCola)->pSiguiente;
        xNodo.pAnterior  = (*pCola)->pAnterior;

        // Verificamos que sea el único elemento
        if (*pCola == *pCabeza)
        {
            // a) Liberar el Nodo a que apunta CABEZA o COLA
            free(*pCabeza);

            // Establecemos en NULL ambos
            *pCabeza = NULL;
            *pCola = NULL;

        }
        else
        {
            // a) Liberar la Memoria de COLA
            free(*pCola);

            // b) Hacer que Cola apunte a Cola->Anterior
            *pCola = (*pCola)->pAnterior;

            // c) Hacer que Cola->Siguiente apunte a NULL
            (*pCola)->pSiguiente = NULL;
        }
        // Mensaje
        printf("Eliminación Final Lista Doblemente Enlazada Elemento:%d Sigte:%p Anter:%p \n\n",xNodo.idEvento,xNodo.pSiguiente,xNodo.pAnterior);
    }
    // Retorna el Nodo
    return xNodo;
}

// Función para Eliminar un Elemento Específico
nodoEvento FnNodoListaDobleElimina(nodoEvento **pCabeza,nodoEvento **pCola,int idEvento)
{

    // Declaramos el Apuntador Auxiliar para buscar el Elemento
    nodoEvento *pAux;

    // Definimos un Apuntador a un Nodo
    nodoEvento xNodo;

    // Inicializa
    xNodo.idEvento=-1;
    strcpy(xNodo.fecha,"");
    strcpy(xNodo.hora,"");  
    strcpy(xNodo.lugar,"");
    strcpy(xNodo.actividad,"");
    xNodo.pSiguiente=NULL;
    xNodo.pAnterior=NULL;

    // Verifica si está vacía ( Mandamos con pCola en lugar de pCabeza)
    if (FnIntListaVacia(*pCabeza))
    {
        // Mensaje
        printf("La Lista Doblemente Enlazada está vacía, no es posible eliminar Elementos \n\n");
    }
    else
    {

        // Asignamos a pAux = CABEZA
        pAux = *pCabeza;

        // Ciclo para buscar el Elemento a Eliminar
        //a)Buscar el Elemento con pAux
        while (pAux!=NULL)
        {
            // Verificamos que encontramos el Nodo
            if (pAux->idEvento==idEvento)
                // Salimos del Ciclo si lo encontramos
                break;
            else
               // Se mueve al Siguiente
               pAux=pAux->pSiguiente;
        }

        // Verifica si encontró el dato
        if (pAux!=NULL)
        {
            // Encontró el dato
            // Obtengo la información del Nodo a ser Eliminado
            xNodo.idEvento      = pAux->idEvento;
            strcpy(xNodo.fecha,(*pCabeza)->fecha);
            strcpy(xNodo.hora,(*pCabeza)->hora);
            strcpy(xNodo.lugar,(*pCabeza)->lugar);
            strcpy(xNodo.actividad,(*pCabeza)->actividad);        
            xNodo.pSiguiente = pAux->pSiguiente;
            xNodo.pAnterior  = pAux->pAnterior;

            // Verifica si es el único elemento
            if (pAux==*pCabeza && pAux==*pCola)
            {
               // Es el único elemento
               free(pAux);

               // Asigna a Null Cola y Cabeza
               *pCabeza=NULL;
               *pCola=NULL;

               // Mensaje
               printf("Eliminación del Único Elemento Lista Doblemente Enlazada:%d Sigte:%p Anter:%p \n\n",xNodo.idEvento,xNodo.pSiguiente,xNodo.pAnterior);
            }
            else
               // Verifica si es el elemento del Frente
               if (pAux==*pCabeza)
                  // Llama a la Rutina correspondiente
                  xNodo=FnNodoListaDobleEliminaFrente(&(*pCabeza));
               else
                  // Verifica si es el elemento del Final
                  if (pAux==*pCola)
                     //Llama a la rutina correspondiente
                     xNodo=FnNodoListaDobleEliminaFinal(&(*pCabeza),&(*pCola));
                  else
                  {
                      // Es un elemento de enmedio
                      // b)Liberar pAux
                      free(pAux);

                      // c)pAux-Anterior-Siguiente=pAux-Siguiente
                      pAux->pAnterior->pSiguiente=pAux->pSiguiente;

                      // d)pAux-Siguiente-Anterior=pAux-Anterior
                      pAux->pSiguiente->pAnterior=pAux->pAnterior;

                      // Mensaje
                      printf("Eliminación de enmedio Lista Doblemente Enlazada:%d Sigte:%p Anter:%p \n\n",xNodo.idEvento,xNodo.pSiguiente,xNodo.pAnterior);

                  }
        }
        else
           // Mensaje
           printf("El Elemento no fue encontrado en la Lista \n\n");
    }
    // Retorna el Nodo
    return xNodo;
}

// Función para Insertar un Elemento al Final de la Lista Doblemente Enlazada
void SbListaDobleInsertarFinal(nodoEvento **pCabeza,
                               nodoEvento **pCola, 
                               int        idEvento,
                               char*      fecha,
                               char*      hora,
                               char*      lugar,
                               char*      actividad)
{

    //a) Crear el Nodo Nuevo con el Valor Correspondiente.
    nodoEvento *pNodoNuevo;

    // Crea un Nuevo Nodo apuntando a Null
    pNodoNuevo=FnNodoCrea(idEvento,fecha,hora,lugar,actividad);

    // Verifica si está vacía ( Mandamos con pCola en lugar de pCabeza)
    if (FnIntListaVacia(*pCabeza))
    {
        // b) Siguiente y anterior apunta a NULL
        pNodoNuevo->pSiguiente = NULL;
        pNodoNuevo->pAnterior = NULL;

        // c) Hacer que Cabeza apunte al Nodo Nuevo.
        *pCabeza=pNodoNuevo;

        // d) Hacer que Cola apunte tambien al Nodo Nuevo.
        *pCola=pNodoNuevo;

        // Mensaje
        printf("Inserción Lista Doblemente Enlazada Vacía; Elemento %d en dirección %p \n\n",idEvento,pNodoNuevo);
    }
    else
    {
        // b) Hacer que el Nodo Nuevo->Siguiente  = nil
        pNodoNuevo->pSiguiente = NULL;

        // c) Hacer que el Nodo Nuevo->Anterior  = COLA
        pNodoNuevo->pAnterior = *pCola;

        // d) Hacer que COLA->Siguiente apunte al Nodo Nuevo
        (*pCola)->pSiguiente = pNodoNuevo;

        // e) Hacer que COLA apunte al Nuevo Nodo
        *pCola = pNodoNuevo;

        // Mensaje
        printf("Inserción Final Lista Doblemente Enlazada Elemento %d en dirección %p \n\n",idEvento,pNodoNuevo);
    }
}


// Función para Insertar un Elemento en la Lista Doblemente Enlazada
void SbListaDobleInsertar(nodoEvento **pCabeza, 
                          nodoEvento **pCola,
                          int        idEvento,
                          char*      fecha,
                          char*      hora,
                          char*      lugar,
                          char*      actividad,
                          int        idReferencia,
                          int        iInsertarDespuesDe)
{
    // Variable para determinar si encontró el elemento
    // Apuntador auxiliar para localizar el Nodo
    nodoEvento *pAux;

    // Verifica si está vacía ( Mandamos con pCola en lugar de pCabeza)
    if (FnIntListaVacia(*pCabeza))
    {
        // Mensaje
        printf("La Lista está vacía; no es posible localizar el Elemento \n\n");
    }
    else
    {
        // Búsqueda a partir de Cabeza
        pAux = *pCabeza;

        // Ciclo para buscar el dato
        //b) Localizar el Elemento utilizando pAux
        while (pAux != NULL)
        {
           // Verifica si es el dato
           if (pAux->idEvento == idReferencia)
               // Sale del Ciclo
               break;
           else
               // Se Mueve al Siguiente
               pAux=pAux->pSiguiente;

        }

        // Si pAux != NULL es que si lo encontró
        if (pAux)
        {
           //a) Crear el Nodo Nuevo con el Valor Correspondiente.
           nodoEvento *pNodoNuevo;

           // Crea un Nuevo Nodo apuntando a Null
           pNodoNuevo=FnNodoCrea(idEvento,fecha,hora,lugar,actividad);

           // Verifica que tipo de Inserción es
           if (iInsertarDespuesDe)
           {
              // Inserción es Despues de
              // Verifica si está en el Último elemento
              if (pAux==*pCola)
                 // Llama a Función que Inserta en el Final
                 SbListaDobleInsertarFinal(&(*pCabeza),&(*pCola),idEvento,fecha,hora,lugar,actividad);
              else
              {
                 // c) NuevoNodo->Siguiente = pAux->Siguiente
                 pNodoNuevo->pSiguiente = pAux->pSiguiente;

                 // d) NuevoNodo->Anterior  = pAux
                 pNodoNuevo->pAnterior = pAux;

                 // e) pAux->Siguiente->Anterior = NodoNuevo
                 pAux->pSiguiente->pAnterior=pNodoNuevo;

                 // f) pAux->Siguiente = NvoNodo
                 pAux->pSiguiente=pNodoNuevo;

                 // Mensaje descriptivo
                 printf("Inserción Despues De; Elemento %d en dirección %p \n\n",idEvento,pNodoNuevo);
              }

           }
           else
           {
              // Inserción Antes de
              // Verifica si está en el Primer elemento
              if (pAux==*pCabeza)
                 // Llama a Función que Inserta en el Frente
                 SbListaDobleInsertarFrente(&(*pCabeza),idEvento,fecha,hora,lugar,actividad);
              else
              {
                 // c) NuevoNodo->Anterior = pAux->Anterior
                 pNodoNuevo->pAnterior=pAux->pAnterior;

                 // d) NuevoNodo->Siguiente  = pAux
                 pNodoNuevo->pSiguiente = pAux;

                 // e) pAux->Anterior->Siguiente = NodoNuevo
                 pAux->pAnterior->pSiguiente=pNodoNuevo;

                 // f) pAux->Anterior = NvoNodo
                 pAux->pAnterior = pNodoNuevo;

                 // Mensaje descriptivo
                 printf("Inserción Antes De; Elemento %d en dirección %p \n\n",idEvento,pNodoNuevo);
              }
           }
        }
    }
}

// Función para desplegar los Elementos en Orden Normal e Inverso
void SbListaDobleDespliegaFull(nodoEvento *pCabeza,nodoEvento *pCola,int iOrdenNormal)
{
    // Para Contar los Elementos
    char iContar=0;

    // Verificamos que esté vacía
    if (FnIntListaVacia(pCabeza))
    {
       // Mensaje de Lista Vacía
       printf("La Lista Doblemente Enlazada se encuentra vacía; no hay valores que desplegar");
    }
    else
    {
        // Desplegando los Elementos de la lista
        printf("Desplegando los Elementos de la Lista ");

        // Verifica el Orden
        if (iOrdenNormal)
        {
            // Despliega el Orden
            printf("en orden normal \n");

            // Ciclo para desplegar los Elementos de la Lista
            while (pCabeza!=NULL)
            {
               // Despliega la información del Nodo
               printf("Elemento:%d Valor:%d en dirección:%p pSigte:%p pAnter:%p \n",++iContar,pCabeza->idEvento,pCabeza,pCabeza->pSiguiente,pCabeza->pAnterior);

               // Mueve cabeza al siguiente elemento
               pCabeza = pCabeza->pSiguiente;
            }
         }
         else
         {
            // Despliega el Orden
            printf("en orden inverso \n");

            // Ciclo para desplegar los Elementos de la Lista
            while (pCola!=NULL)
            {
               // Despliega la información del Nodo
               printf("Elemento:%d Valor:%d en dirección:%p pSigte:%p pAnter:%p \n",++iContar,pCola->idEvento,pCola,pCola->pSiguiente,pCola->pAnterior);

               // Mueve cabeza al siguiente elemento
               pCola = pCola->pAnterior;
            }

         }
    }
    // Deja una Línea
    printf("\n");

}

// Función para Buscar un Elemento
int FnIntListaBuscaNodo(nodoEvento *pCabeza,int idEvento)
{
    // Variable para Contar
    char iContar=0;

    // Variable para el Resultado
    int iResult = FALSE;

    // Desplegando los Elementos de la lista
    printf("Buscando Elemento en la Lista ...\n");

    // Ciclo para desplegar los Elementos de la Lista
    while (pCabeza!=NULL)
    {
      // Incrementa el contador
      iContar++;

      // Verificamos que tenga el Elemento a buscar
      if (pCabeza->idEvento==idEvento)
      {
         // Asigna que lo ha encontrado
         iResult=TRUE;

         // Rompe el Ciclo
         break;

      }
      else
        // Mueve cabeza al siguiente elemento
        pCabeza = pCabeza->pSiguiente;

    }

    // Verifica si lo encontró
    if (iResult)
       printf("El Elemento fue encontrado en la posición: %d \n",iContar);
    else
       printf("El Elemento NO fue encontrado \n",iContar);

    // Deja una Línea
    printf("\n");

}

