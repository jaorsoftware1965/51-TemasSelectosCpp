// ---------------------------------------------------------------------------------------
// main.c
// Desarrollo de una Agenda usando Listas Doblemente Enlazadas
// Instrucciones:
// Mostrar un Menu al usuario que le permita
// 1.- Visualizar las actividades en el dia que eliga ordenadas cronologicamente
//     Si la agenda es anual, deberá pedir mes o día.
// 2.- Visualizar todas las actividades agendadas, dando la posibilidad de ir a siguiente
//     o anterior ordenadas cronologicamente, iniciando desde el primer dia del mes o del
//     año, o solicitar la fecha. Mostrar la fecha, hora, lugar, y actividad del evento
// 3.- Agregar un Evento. Deberá solicitar Fecha, hora, actividad y lugar
// 4.- Eliminar un Evento. Deberá solicitar el identificador del Evento a eliminar
// --------------------------------------------------------------------------------------

// Se Incluyen librerias de C
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>

// Variables Booleanas
#define TRUE  1
#define FALSE 0

// Variable Global para el Conteo de los Eventos
int gEventosContador = 0;

// Se define la Estructura del Nodo
struct stcNodo
{
    // Definición del Evento
    int  idEvento;      // Identificador del Evento
    char fecha[11];     // Ejemplo 2019-05-09
    char hora[6];       // 23:34
    char lugar[51];     // Plaza Culturas
    char actividad[51]; // Tarea de Programación

    // Los Apuntadores a Siguiente y Anterior
    struct stcNodo *pSiguiente;
    struct stcNodo *pAnterior;
};

// Se define un tipo de acuerdo a la estructura
typedef struct stcNodo nodoEvento;


// Función para verificar si una Lista Enlazada está vacía
int FnIntListaVacia(nodoEvento *pCabeza);

// Función para crear un Nodo
nodoEvento *FnNodoCrea(int  idEvento, char* fecha, char* hora, char* lugar, char* actividad);

// Función para Insertar un Elemento al Frente de la Lista Doblemente Enlazada
void SbListaDobleInsertarFrente(nodoEvento **pCabeza, int idEvento,char* fecha, 
                                char* hora, char* lugar, char* actividad);

// Función para Eliminar un Elemento del Frente de la Lista Doble
nodoEvento FnNodoListaDobleEliminaFrente(nodoEvento **pCabeza);

// Función para Eliminar un Elemento del Final de la Lista Doble
nodoEvento FnNodoListaDobleEliminaFinal(nodoEvento **pCabeza,nodoEvento **pCola);

// Función para Eliminar un Elemento Específico
nodoEvento FnNodoListaDobleElimina(nodoEvento **pCabeza,nodoEvento **pCola,int idEvento);

// Función para Insertar un Elemento al Final de la Lista Doblemente Enlazada
void SbListaDobleInsertarFinal(nodoEvento **pCabeza, nodoEvento **pCola, int idEvento, char* fecha, 
                               char* hora, char* lugar, char* actividad);

// Función para Insertar un Elemento en la Lista Doblemente Enlazada
void SbListaDobleInsertar(nodoEvento **pCabeza, nodoEvento **pCola, int idEvento, char* fecha, 
                          char* hora, char* lugar,  char* actividad, int idReferencia, 
                          int iInsertarDespuesDe);

// Función para desplegar la Lista
void SbListaDobleDespliegaFull(nodoEvento *pCabeza,nodoEvento *pCola,int iOrdenNormal);

// Función para Buscar un Elemento
int FnIntListaBuscaNodo(nodoEvento *pCabeza,int idEvento);

// Función para buscar un Nodo con feche mayor
int FnIntListaBuscaNodoFechaMayor(nodoEvento *pCabeza,char* fecha,char* hora);

// Función para obtener un Nodo
nodoEvento* FnListaObtenNodo(nodoEvento *pCabeza,int idEvento);

// Evento para despliegue de Eventos por dia, mes año
void SbEventosPorDiaMesAnio(nodoEvento *pCabeza,
                            char        intervalo, // d=dia, m=mes, a= año
                            char*       diaBusqueda,
                            char*       mesBusqueda,
                            char*       anioBusqueda);

// Función Principal de C
int main()
{
    // Variable para la opcion
    int opcion = 0;

    // Variables para leer datos
    char evento[5];
    char fecha[11];
    char hora[6];
    char lugar[51];
    char actividad[51];
    
    // Variables para separar cada dato de la fecha
    char sDia[3];
    char sMes[3];
    char sAnio[5];

    // Declaramos apuntadores de Cabeza y Cola
    nodoEvento *pCabeza=NULL;
    nodoEvento *pCola=NULL;

    // Variable Nodo para Eliminar
    nodoEvento xNodo;

    // Variable para saber Identificador Mayor en Fecha
    int identificadorFechaMayor;

    // Se Insertan Elementos de Prueba, para probar consultas por evento, dia, mes y año
    // SbListaDobleInsertarFinal(&pCabeza,&pCola,++gEventosContador,"2019-11-14","19:30","OMV Radio, Estado de Mexico","Entrevista 'Ruta Directa'");
    // SbListaDobleInsertarFinal(&pCabeza,&pCola,++gEventosContador,"2019-11-24","16:00","Colonia Los Filtros, Cordoba Ver","Ensayo Concierto Rock");
    // SbListaDobleInsertarFinal(&pCabeza,&pCola,++gEventosContador,"2019-11-24","19:00","Colonia Los Filtros, Cordoba Ver","Concierto Rock");
    // SbListaDobleInsertarFinal(&pCabeza,&pCola,++gEventosContador,"2019-11-24","21:00","Colonia Los Filtros, Cordoba Ver","Cena del Evento");
    // SbListaDobleInsertarFinal(&pCabeza,&pCola,++gEventosContador,"2019-12-24","22:00","Casa","Cena de Navidad");
    // SbListaDobleInsertarFinal(&pCabeza,&pCola,++gEventosContador,"2019-12-31","22:00","Casa","Cena de Fin de Año");
    // SbListaDobleInsertarFinal(&pCabeza,&pCola,++gEventosContador,"2020-01-06","06:00","Casa","Dia de Reyes");
    // SbListaDobleInsertarFinal(&pCabeza,&pCola,++gEventosContador,"2020-02-14","21:00","Casa","Celebracion del dia de la Amistad");

    // Ciclo principal del programa
    do
    {
        // Limpia la Pantalla
        //system("cls");

        // Variable para Eventos
        int iEvento;

        // Define un apuntador a nodoEvento
        nodoEvento* pNodoEvento;

        // Limpia el Buffer
        fflush(stdin);

        // Menú Principal
        printf("------------------------- \n");
        printf("Agenda 2019               \n");
        printf("Menu Principal            \n");
        printf("------------------------- \n");
        printf("1.- Insertar  un Evento   \n");
        printf("2.- Eliminar  un Evento   \n");
        printf("3.- Desplegar los Eventos \n");
        printf("4.- Desplegar un Evento   \n");
        printf("5.- Desplegar por Dia     \n");
        printf("6.- Desplegar por Mes     \n");
        printf("7.- Desplegar por Anio    \n");                
        printf("0.- Salida                \n");
        
        // Lee la opción
        opcion = getchar();

        // Limpia el Buffer
        fflush(stdin);


        switch (opcion)
        {
            case '1':
                // Incrementa el contador de Eventos
                gEventosContador++;

                // Solicita la captura del Evento
                printf("Capture el Evento %d \n",gEventosContador);


                printf("Fecha (AAAA-MM-DD):");
                gets(fecha);

                printf("Hora (HH:MM):");
                gets(hora);

                printf("Lugar (50 caracteres maximo):");
                gets(lugar);

                printf("Actividad (50 caracteres maximo):");
                gets(actividad);

                // Verifica si la lista está vacía
                if (FnIntListaVacia(pCabeza))
                {
                    // Inserta al Final
                    SbListaDobleInsertarFinal(&pCabeza,&pCola,gEventosContador,fecha,hora,lugar,actividad);

                    // El Evento ha sido insertado
                    printf("El Primer Evento ha sido Insertado ...\n");
                    printf("Pulse Enter para continuar  ...\n");

                }
                else
                {
                    // Busca un elemento mayor que el
                    identificadorFechaMayor= FnIntListaBuscaNodoFechaMayor(pCabeza,fecha,hora);
                    printf("Identificador:%d \n",identificadorFechaMayor);
                    if (identificadorFechaMayor>0)                    
                    {
                        // Función para Insertar antes del identificador con Fecha Mayor
                        SbListaDobleInsertar(&pCabeza,&pCola,gEventosContador,fecha,hora,lugar,actividad,identificadorFechaMayor,FALSE);
                    }
                    else
                    {
                        // Inserta al Final
                        SbListaDobleInsertarFinal(&pCabeza,&pCola,gEventosContador,fecha,hora,lugar,actividad);
                    }
                    printf("El Evento ha sido Insertado ...\n");
                    printf("Pulse Enter para continuar  ...\n");
                }             
                getchar();   
                break;

            case '2':
                printf("Capture Evento a Eliminar (Max 9999):");
                gets(evento);

                // Convierte a Numérico
                iEvento = atoi(evento);

                // Busca el evento
                if (FnIntListaBuscaNodo(pCabeza,iEvento))
                {
                    // Llama a Función que Elimina el Nodo
                    FnNodoListaDobleElimina(&pCabeza,&pCola,iEvento);

                    // Mensaje
                    printf("El Evento ha sido eliminado de la Agenda.\b");                    
                }
                else
                {
                    printf("Evento No encontrado");
                }
                // Pausa
                printf("Pulse Enter para continuar  ...\n");
                getchar();
                break;

            
            case '3':
                // Desplegar un Evento Especifico
                SbListaDobleDespliegaFull(pCabeza,pCola,TRUE);
                break;

            case '4':
                // Despliega el contenido de la lista
                printf("Capture Evento a Desplegar (Max 9999):");
                gets(evento);

                // Convierte a Numérico
                iEvento = atoi(evento);

                // Busca el evento
                if (FnIntListaBuscaNodo(pCabeza,iEvento))
                {
                    // Obtiene el Apuntador
                    pNodoEvento = FnListaObtenNodo(pCabeza,iEvento);

                    do
                    {
                        
                        // Despliega los datos del Evento
                        printf("Los Datos del Evento son:\n");
                        printf("Evento    :%d\n",pNodoEvento->idEvento);
                        printf("Fecha     :%s\n",pNodoEvento->fecha);
                        printf("Hora      :%s\n",pNodoEvento->hora);
                        printf("Lugar     :%s\n",pNodoEvento->lugar);
                        printf("Actividad :%s\n",pNodoEvento->actividad);
                        
                        // Verifica apuntadores
                        printf("S-Siguiente A-Anterior X-Salir:");
                        
                        // Lee la opción
                        opcion = getchar();

                        // Limpia el Buffer
                        fflush(stdin);  
            
                        // Verifica opción
                        if (opcion=='s' || opcion=='S')                        
                            if (pNodoEvento->pSiguiente!=NULL)
                            {
                                // Se mueve al siguiente nodo
                                pNodoEvento = pNodoEvento->pSiguiente;
                            }
                            else
                            {
                                printf("Ya no hay eventos posteriores ...\n");
                                printf("Presione cualquier tecla para continuar ...");
                                getchar();
                            }                        
                        else                        
                            if (opcion=='a' || opcion=='A')                            
                                if (pNodoEvento->pAnterior!=NULL)
                                {
                                    // Se mueve al siguiente nodo
                                    pNodoEvento = pNodoEvento->pAnterior;
                                }
                                else
                                {
                                    printf("Ya no hay eventos anteriores ...\n");
                                    printf("Presione cualquier tecla para continuar ...");
                                    getchar();
                                }                                                                                
                        
                        // Limpia el Buffer
                        fflush(stdin);                              

                    } while (opcion!='x' && opcion!='X');                
                }
                else
                {
                    // Mensaje de que no existe
                    printf("El Evento indicado no existe \n");
                }
                // Pausa
                printf("Pulse Enter para continuar  ...\n");
                getchar();
                break;

             case '5':
                // Solicita la fecha completa
                printf("Capture la Fecha: (aaaa-mm-dd):");
                gets(fecha);               

                // Coloca los datos desde la fecha
                sAnio[0]=fecha[0];
                sAnio[1]=fecha[1];
                sAnio[2]=fecha[2];
                sAnio[3]=fecha[3];
                sAnio[4]='\0';

                sMes[0]=fecha[5];
                sMes[1]=fecha[6];
                sMes[2]='\0';

                sDia[0]=fecha[8];
                sDia[1]=fecha[9];
                sDia[2]='\0';

                // Llama a la función de Búsqueda
                SbEventosPorDiaMesAnio(pCabeza,'d',sDia,sMes,sAnio);

                break;

            case '6':

                // Solicita mes y año
                printf("Capture el Mes: (mm):");
                gets(sMes);

                printf("Capture el Año: (aaaa):");
                gets(sAnio);
                
                // Llama a la función de Búsqueda
                SbEventosPorDiaMesAnio(pCabeza,'m',"",sMes,sAnio);

                break;

            case '7':

                // Solicita mes y año
                printf("Capture el Año: (aaaa):");
                gets(sAnio);
                
                // Llama a la función de Búsqueda
                SbEventosPorDiaMesAnio(pCabeza,'a',"","",sAnio);

                break;    

    


        default:
            break;
        }

    } while (opcion!='0');


    // Finaliza la aplicación retornando 0
    return 0;
}


// Función para verificar si una Lista Enlazada está vacía
int FnIntListaVacia(nodoEvento *pCabeza)
{
   // Verifica si está apuntando a Null
   if (pCabeza==NULL)
   {
      //printf("La Lista está vacía \n");
      return TRUE;
   }
   else
   {
      //printf("La Lista no está vacía \n");
      return FALSE;
   }
}

// Función para crear un Nodo
nodoEvento *FnNodoCrea(int  idEvento,
                       char* fecha, 
                       char* hora, 
                       char* lugar,
                       char* actividad)
{
   // Defino una variable de tipo Apuntador Nodo
   nodoEvento *xNodo;

   // Reservo la Memoria para el Nodo
   xNodo = (nodoEvento *)malloc(sizeof(nodoEvento));

   // Verifico que haya podido reservar memoria
   if (xNodo == NULL)
      // Despliega el Mensaje de Error
      printf("Error. No se pudo reservar memoria para el Nodo");
   else
   {
      // Asigna la Información al Nodo
      xNodo->idEvento = idEvento;     // El Dato
      strcpy(xNodo->fecha,fecha);
      strcpy(xNodo->hora,hora);  
      strcpy(xNodo->lugar,lugar);
      strcpy(xNodo->actividad,actividad);
      xNodo->pSiguiente = NULL; // Apunta a Null
      xNodo->pAnterior = NULL; // Apunta a Null
   }

   //Retorna el resultado
   return xNodo;
}

// Función para Insertar un Elemento al Frente de la Lista Doblemente Enlazada
void SbListaDobleInsertarFrente(nodoEvento **pCabeza, 
                                int        idEvento,
                                char*      fecha,
                                char*      hora,
                                char*      lugar,
                                char*      actividad)
{
    // Crear el Nodo Nuevo con el Valor Correspondiente.
    nodoEvento *pNodoNuevo;

    // Crea un Nuevo Nodo apuntando a Null
    pNodoNuevo=FnNodoCrea(idEvento, fecha, hora, lugar, actividad);

    // Verifica si está vacía ( Mandamos con pCola en lugar de pCabeza)
    if (FnIntListaVacia(*pCabeza))
    {
        // Siguiente y anterior apunta a NULL
        pNodoNuevo->pSiguiente = NULL;
        pNodoNuevo->pAnterior = NULL;

        // Hacer que Cabeza apunte al Nodo Nuevo.
        *pCabeza=pNodoNuevo;

    }
    else
    {
        // b) Hacer que CABEZA->Anterior apunte al Nuevo Nodo
        (*pCabeza)->pAnterior = pNodoNuevo;

        // c) Hacer que el Nuevo Nodo->Siguiente Apunte al Nodo que apunta Cabeza
        pNodoNuevo->pSiguiente = *pCabeza;

        // d) Hacer que el Nuevo Nodo->Anterior apunte a NULL
        pNodoNuevo->pAnterior = NULL;

        // e) Hacer que CABEZA Apunte al Nvo Nodo
        *pCabeza = pNodoNuevo;

    }
}

// Función para Eliminar un Elemento del Frente de la Lista Doble
nodoEvento FnNodoListaDobleEliminaFrente(nodoEvento **pCabeza)
{

    // Definimos un Apuntador a un Nodo
    nodoEvento xNodo;


    // Inicializa
    xNodo.idEvento=-1;
    strcpy(xNodo.fecha,"");
    strcpy(xNodo.hora,"");  
    strcpy(xNodo.lugar,"");
    strcpy(xNodo.actividad,"");
    xNodo.pSiguiente=NULL;
    xNodo.pAnterior=NULL;

    // Verifica si está vacía ( Mandamos con pCola en lugar de pCabeza)
    if (FnIntListaVacia(*pCabeza))
    {
        // Mensaje
        printf("La Lista Doblemente Enlazada está vacía, no es posible eliminar Elementos \n\n");
    }
    else
    {
        // Obtenemos la información del Nodo a Eliminar
        xNodo.idEvento      = (*pCabeza)->idEvento;
        xNodo.idEvento      = (*pCabeza)->idEvento;
        strcpy(xNodo.fecha,(*pCabeza)->fecha);
        strcpy(xNodo.hora,(*pCabeza)->hora);
        strcpy(xNodo.lugar,(*pCabeza)->lugar);
        strcpy(xNodo.actividad,(*pCabeza)->actividad);
        xNodo.pSiguiente = (*pCabeza)->pSiguiente;
        xNodo.pAnterior  = (*pCabeza)->pAnterior;

        // a) Liberar el Nodo a que apunta CABEZA
        free(*pCabeza);

        // b) Cabeza apunta ahora a Cabeza->Siguiente
        *pCabeza = (*pCabeza)->pSiguiente;

        // c) Cabeza->Anterior = NULL
        if (*pCabeza!=NULL)
           (*pCabeza)->pAnterior = NULL;

    }

    // Retorna el Nodo
    return xNodo;
}

// Función para Eliminar un Elemento del Final de la Lista Doble
nodoEvento FnNodoListaDobleEliminaFinal(nodoEvento **pCabeza,nodoEvento **pCola)
{

    // Definimos un Apuntador a un Nodo
    nodoEvento xNodo;

    // Inicializa
    xNodo.idEvento=-1;
    strcpy(xNodo.fecha,"");
    strcpy(xNodo.hora,"");  
    strcpy(xNodo.lugar,"");
    strcpy(xNodo.actividad,"");
    xNodo.pSiguiente=NULL;
    xNodo.pAnterior=NULL;

    // Verifica si está vacía ( Mandamos con pCola en lugar de pCabeza)
    if (FnIntListaVacia(*pCabeza))
    {
        // Mensaje
        printf("La Lista Doblemente Enlazada está vacía, no es posible eliminar Elementos \n\n");
    }
    else
    {
        // Obtenemos la información del Nodo a Eliminar
        xNodo.idEvento      = (*pCola)->idEvento;
        strcpy(xNodo.fecha,(*pCabeza)->fecha);
        strcpy(xNodo.hora,(*pCabeza)->hora);
        strcpy(xNodo.lugar,(*pCabeza)->lugar);
        strcpy(xNodo.actividad,(*pCabeza)->actividad);
        xNodo.pSiguiente = (*pCola)->pSiguiente;
        xNodo.pAnterior  = (*pCola)->pAnterior;

        // Verificamos que sea el único elemento
        if (*pCola == *pCabeza)
        {
            // a) Liberar el Nodo a que apunta CABEZA o COLA
            free(*pCabeza);

            // Establecemos en NULL ambos
            *pCabeza = NULL;
            *pCola = NULL;

        }
        else
        {
            // a) Liberar la Memoria de COLA
            free(*pCola);

            // b) Hacer que Cola apunte a Cola->Anterior
            *pCola = (*pCola)->pAnterior;

            // c) Hacer que Cola->Siguiente apunte a NULL
            (*pCola)->pSiguiente = NULL;
        }
        // Mensaje
        printf("Eliminación Final Lista Doblemente Enlazada Elemento:%d Sigte:%p Anter:%p \n\n",xNodo.idEvento,xNodo.pSiguiente,xNodo.pAnterior);
    }
    // Retorna el Nodo
    return xNodo;
}

// Función para Eliminar un Elemento Específico
nodoEvento FnNodoListaDobleElimina(nodoEvento **pCabeza,nodoEvento **pCola,int idEvento)
{

    // Declaramos el Apuntador Auxiliar para buscar el Elemento
    nodoEvento *pAux;

    // Creamos un Nodo
    nodoEvento xNodo;

    // Inicializa
    xNodo.idEvento=-1;
    strcpy(xNodo.fecha,"");
    strcpy(xNodo.hora,"");  
    strcpy(xNodo.lugar,"");
    strcpy(xNodo.actividad,"");
    xNodo.pSiguiente=NULL;
    xNodo.pAnterior=NULL;

    // Verifica si está vacía ( Mandamos con pCola en lugar de pCabeza)
    if (FnIntListaVacia(*pCabeza))
    {
        // Mensaje
        printf("La Lista Doblemente Enlazada está vacía, no es posible eliminar Elementos \n\n");
    }
    else
    {

        // Asignamos a pAux = CABEZA
        pAux = *pCabeza;

        // Ciclo para buscar el Elemento a Eliminar
        //a)Buscar el Elemento con pAux
        while (pAux!=NULL)
        {
            // Verificamos que encontramos el Nodo
            if (pAux->idEvento==idEvento)
                // Salimos del Ciclo si lo encontramos
                break;
            else
               // Se mueve al Siguiente
               pAux=pAux->pSiguiente;
        }

        // Verifica si encontró el dato
        if (pAux!=NULL)
        {
            // Encontró el dato
            // Obtengo la información del Nodo a ser Eliminado
            xNodo.idEvento      = pAux->idEvento;
            strcpy(xNodo.fecha,(*pCabeza)->fecha);
            strcpy(xNodo.hora,(*pCabeza)->hora);
            strcpy(xNodo.lugar,(*pCabeza)->lugar);
            strcpy(xNodo.actividad,(*pCabeza)->actividad);        
            xNodo.pSiguiente = pAux->pSiguiente;
            xNodo.pAnterior  = pAux->pAnterior;

            // Verifica si es el único elemento
            if (pAux==*pCabeza && pAux==*pCola)
            {
               // Es el único elemento
               free(pAux);

               // Asigna a Null Cola y Cabeza
               *pCabeza=NULL;
               *pCola=NULL;

            }
            else
               // Verifica si es el elemento del Frente
               if (pAux==*pCabeza)
                  // Llama a la Rutina correspondiente
                  xNodo=FnNodoListaDobleEliminaFrente(&(*pCabeza));
               else
                  // Verifica si es el elemento del Final
                  if (pAux==*pCola)
                     //Llama a la rutina correspondiente
                     xNodo=FnNodoListaDobleEliminaFinal(&(*pCabeza),&(*pCola));
                  else
                  {
                      // Es un elemento de enmedio
                      // Liberar pAux
                      free(pAux);

                      // pAux-Anterior-Siguiente=pAux-Siguiente
                      pAux->pAnterior->pSiguiente=pAux->pSiguiente;

                      // pAux-Siguiente-Anterior=pAux-Anterior
                      pAux->pSiguiente->pAnterior=pAux->pAnterior;
                  }
        }
        else
           // Mensaje
           printf("El Elemento no fue encontrado en la Lista \n\n");
    }
    // Retorna el Nodo
    return xNodo;
}

// Función para Insertar un Elemento al Final de la Lista Doblemente Enlazada
void SbListaDobleInsertarFinal(nodoEvento **pCabeza,
                               nodoEvento **pCola, 
                               int        idEvento,
                               char*      fecha,
                               char*      hora,
                               char*      lugar,
                               char*      actividad)
{

    //a) Crear el Nodo Nuevo con el Valor Correspondiente.
    nodoEvento *pNodoNuevo;

    // Crea un Nuevo Nodo apuntando a Null
    pNodoNuevo=FnNodoCrea(idEvento,fecha,hora,lugar,actividad);

    // Verifica si está vacía ( Mandamos con pCola en lugar de pCabeza)
    if (FnIntListaVacia(*pCabeza))
    {
        // b) Siguiente y anterior apunta a NULL
        pNodoNuevo->pSiguiente = NULL;
        pNodoNuevo->pAnterior = NULL;

        // c) Hacer que Cabeza apunte al Nodo Nuevo.
        *pCabeza=pNodoNuevo;

        // d) Hacer que Cola apunte tambien al Nodo Nuevo.
        *pCola=pNodoNuevo;
    }
    else
    {
        // Hacer que el Nodo Nuevo->Siguiente  = nil
        pNodoNuevo->pSiguiente = NULL;

        // Hacer que el Nodo Nuevo->Anterior  = COLA
        pNodoNuevo->pAnterior = *pCola;

        // Hacer que COLA->Siguiente apunte al Nodo Nuevo
        (*pCola)->pSiguiente = pNodoNuevo;

        // Hacer que COLA apunte al Nuevo Nodo
        *pCola = pNodoNuevo;
    }
}


// Función para Insertar un Elemento en la Lista Doblemente Enlazada
void SbListaDobleInsertar(nodoEvento **pCabeza, 
                          nodoEvento **pCola,
                          int        idEvento,
                          char*      fecha,
                          char*      hora,
                          char*      lugar,
                          char*      actividad,
                          int        idReferencia,
                          int        iInsertarDespuesDe)
{
    // Variable para determinar si encontró el elemento
    // Apuntador auxiliar para localizar el Nodo
    nodoEvento *pAux;
    
    // Verifica si está vacía ( Mandamos con pCola en lugar de pCabeza)
    if (FnIntListaVacia(*pCabeza))
    {
        // Mensaje
        printf("La Lista está vacía; no es posible localizar el Elemento \n\n");
    }
    else
    {
        // Búsqueda a partir de Cabeza
        pAux = *pCabeza;

        // Ciclo para buscar el dato
        while (pAux != NULL)
        {
           // Verifica si es el dato
           if (pAux->idEvento == idReferencia)
               // Sale del Ciclo
               break;
           else
               // Se Mueve al Siguiente
               pAux=pAux->pSiguiente;
        }

        // Si pAux != NULL es que si lo encontró
        if (pAux)
        {
           // Crear el Nodo Nuevo con el Valor Correspondiente.
           nodoEvento *pNodoNuevo;

           // Crea un Nuevo Nodo apuntando a Null
           pNodoNuevo=FnNodoCrea(idEvento,fecha,hora,lugar,actividad);

           // Verifica que tipo de Inserción es
           if (iInsertarDespuesDe)
           {
              // Inserción es Despues de
              // Verifica si está en el Último elemento
              if (pAux==*pCola)
                 // Llama a Función que Inserta en el Final
                 SbListaDobleInsertarFinal(&(*pCabeza),&(*pCola),idEvento,fecha,hora,lugar,actividad);
              else
              {
                 // c) NuevoNodo->Siguiente = pAux->Siguiente
                 pNodoNuevo->pSiguiente = pAux->pSiguiente;

                 // d) NuevoNodo->Anterior  = pAux
                 pNodoNuevo->pAnterior = pAux;

                 // e) pAux->Siguiente->Anterior = NodoNuevo
                 pAux->pSiguiente->pAnterior=pNodoNuevo;

                 // f) pAux->Siguiente = NvoNodo
                 pAux->pSiguiente=pNodoNuevo;
              }
           }
           else
           {

              // Verifica si está en el Primer elemento
              if (pAux==*pCabeza)
              {
                 // Llama a Función que Inserta en el Frente
                 SbListaDobleInsertarFrente(&(*pCabeza),idEvento,fecha,hora,lugar,actividad);
              }
              else
              {
                 // NuevoNodo->Anterior = pAux->Anterior
                 pNodoNuevo->pAnterior=pAux->pAnterior;

                 // NuevoNodo->Siguiente  = pAux
                 pNodoNuevo->pSiguiente = pAux;

                 // pAux->Anterior->Siguiente = NodoNuevo
                 pAux->pAnterior->pSiguiente=pNodoNuevo;

                 // pAux->Anterior = NvoNodo
                 pAux->pAnterior = pNodoNuevo;

              }
           }
        }
    }
}

// Función para desplegar los Elementos en Orden Normal e Inverso
void SbListaDobleDespliegaFull(nodoEvento *pCabeza,nodoEvento *pCola,int iOrdenNormal)
{
    // Para Contar los Elementos
    char iContar=0;

    // Verificamos que esté vacía
    if (FnIntListaVacia(pCabeza))
    {
       // Mensaje de Lista Vacía
       printf("No hay eventos Registrados ... \n");
    }
    else
    {
        // Desplegando los Elementos de la lista
        printf("Reg\t Id\t Fecha\t\t Hora\t Lugar | Actividad \n");
        printf("-----------------------------------------------------------------------------------------------------\n");
        
        // Verifica el Orden
        if (iOrdenNormal)
        {
            // Ciclo para desplegar los Elementos de la Lista
            while (pCabeza!=NULL)
            {
               // Despliega la información del Nodo
               printf("%d\t %d\t %s\t %s\t %s | %s \n",
                      ++iContar,pCabeza->idEvento,pCabeza->fecha,pCabeza->hora,pCabeza->lugar,pCabeza->actividad);

               // Mueve cabeza al siguiente elemento
               pCabeza = pCabeza->pSiguiente;
            }
         }
         else
         {

            // Ciclo para desplegar los Elementos de la Lista
            while (pCola!=NULL)
            {
               // Despliega la información del Nodo
               printf("%d\t %d\t %s\t %s\t %s\t %s \n",
                      ++iContar,pCabeza->idEvento,pCabeza->fecha,pCabeza->hora,pCabeza->lugar,pCabeza->actividad);

               // Mueve cabeza al siguiente elemento
               pCola = pCola->pAnterior;
            }

         }
    }
    // Deja una Línea
    printf("\n");
    printf("Presione Enter para Continuar ...");
    getchar();

}

// Función para Buscar un Elemento
int FnIntListaBuscaNodo(nodoEvento *pCabeza,int idEvento)
{
    // Variable para Contar
    char iContar=0;

    // Variable para el Resultado
    int iResult = FALSE;


    // Ciclo para desplegar los Elementos de la Lista
    while (pCabeza!=NULL)
    {
      // Incrementa el contador
      iContar++;

      // Verificamos que tenga el Elemento a buscar
      if (pCabeza->idEvento==idEvento)
      {
         // Asigna que lo ha encontrado
         iResult=TRUE;

         // Rompe el Ciclo
         break;

      }
      else
        // Mueve cabeza al siguiente elemento
        pCabeza = pCabeza->pSiguiente;

    }

    // Devuelve el Resultado
    return (iResult);
}

// Función para Buscar un Nodo con Fecha Mayor
int FnIntListaBuscaNodoFechaMayor(nodoEvento *pCabeza, char* fecha, char* hora)
{
    // Variable para el Resultado
    int identificador = -1;    

    // Obtiene el año, mes y dia de la fecha a buscar
    char sAnio[5];
    sAnio[0]=fecha[0];
    sAnio[1]=fecha[1];
    sAnio[2]=fecha[2];
    sAnio[3]=fecha[3];
    sAnio[4]='\0';

    char sMes[3];
    sMes[0]=fecha[5];
    sMes[1]=fecha[6];
    sMes[2]='\0';

    char sDia[3];
    sDia[0]=fecha[8];
    sDia[1]=fecha[9];
    sDia[2]='\0';
    
    char sHora[3];
    sHora[0]=hora[0];
    sHora[1]=hora[1];
    sHora[2]='\0';

    char sMinuto[3];
    sMinuto[0]=hora[3];
    sMinuto[1]=hora[4];
    sMinuto[2]='\0';
    
    // Obtengo la fecha y hora numericamente
    int Anio    = atoi(sAnio);
    int Mes     = atoi(sMes);
    int Dia     = atoi(sDia);
    int Hora    = atoi(sHora);
    int Minuto  = atoi(sMinuto);

    // Ciclo para desplegar los Elementos de la Lista
    while (pCabeza!=NULL)
    {
        // Obtengo la fecha del dato en la lista
        sAnio[0]=pCabeza->fecha[0];
        sAnio[1]=pCabeza->fecha[1];
        sAnio[2]=pCabeza->fecha[2];
        sAnio[3]=pCabeza->fecha[3];
        sAnio[4]=pCabeza->fecha[4];
        sAnio[5]='\0';

        // Mes
        sMes[0]=pCabeza->fecha[5];
        sMes[1]=pCabeza->fecha[6];
        sMes[2]='\0';

        // Dia
        sDia[0]=pCabeza->fecha[8];
        sDia[1]=pCabeza->fecha[9];
        sDia[2]='\0';
        
        // Hora
        sHora[0]=pCabeza->hora[0];
        sHora[1]=pCabeza->hora[1];
        sHora[2]='\0';

        // Minuto
        sMinuto[0]=pCabeza->hora[3];
        sMinuto[1]=pCabeza->hora[4];
        sMinuto[2]='\0';

        // Obtengo la fecha y hora numericamente del Nodo
        int AnioNodo    = atoi(sAnio);
        int MesNodo     = atoi(sMes);
        int DiaNodo     = atoi(sDia);
        int HoraNodo    = atoi(sHora);
        int MinutoNodo  = atoi(sMinuto);

        // Comparamos año
        if (Anio < AnioNodo)
        {
            // Asigna que lo ha encontrado
            identificador = pCabeza->idEvento;

            // Rompe el Ciclo
            break;

        }
        else
            if (Mes < MesNodo)
            {
                // Asigna que lo ha encontrado
                identificador = pCabeza->idEvento;

                // Rompe el Ciclo
                break;

            }
            else
                if (Dia < DiaNodo)
                {
                    // Asigna que lo ha encontrado
                    identificador = pCabeza->idEvento;

                    // Rompe el Ciclo
                    break;

                }
                else
                    if (Hora < HoraNodo)
                    {
                        // Asigna que lo ha encontrado
                        identificador = pCabeza->idEvento;

                        // Rompe el Ciclo
                        break;

                    }
                    else
                        if (Dia < MesNodo)
                        {
                            // Asigna que lo ha encontrado
                            identificador = pCabeza->idEvento;

                            // Rompe el Ciclo
                            break;

                        }                        
            
            // Mueve cabeza al siguiente elemento
            pCabeza = pCabeza->pSiguiente;

    }

    // Retorna el Identificador
    return (identificador);

}

// Función para Obtener un Nodo
nodoEvento* FnListaObtenNodo(nodoEvento *pCabeza,int idEvento)
{    
    // Creamos un Nodo
    nodoEvento* xNodo;

 
    // Ciclo para desplegar los Elementos de la Lista
    while (pCabeza!=NULL)
    {
 
      // Verificamos que tenga el Elemento a buscar
      if (pCabeza->idEvento==idEvento)
      {
         // Asigna que lo ha encontrado
         xNodo = pCabeza;

         // Rompe el Ciclo
         break;

      }
      else
        // Mueve cabeza al siguiente elemento
        pCabeza = pCabeza->pSiguiente;

    }

    // Devuelve el Resultado
    return (xNodo);
}

// Función para desplegar los Eventos por Día o Mes o Año
void SbEventosPorDiaMesAnio(nodoEvento *pCabeza,
                            char        intervalo, // d=dia, m=mes, a= año
                            char*       diaBusqueda,
                            char*       mesBusqueda,
                            char*       anioBusqueda)
{
    // Variables para dia, mes y anio
    int dia,mes,anio;
    char sAnio[5];    
    char sMes[3];    
    char sDia[3];

    // Variable para contar los registros
    int iContador=0;
    

    // Verificamos que esté vacía
    if (FnIntListaVacia(pCabeza))
    {
       // Mensaje de Lista Vacía
       printf("No hay eventos Registrados ... \n");
    }
    else
    {
        // Mensaje de búsqueda de Eventos
        printf("Buscando eventos ...");

        // Desplegando los Elementos de la lista
        printf("Reg\t Id\t Fecha\t\t Hora\t Lugar | Actividad \n");
        printf("-----------------------------------------------------------------------------------------------------\n");
        
        // Swtich por intervalo
        switch (intervalo)
        {
            // Búsqueda por dia
            case 'd':
                // Obtengo el dia,mes y anio
                dia = atoi(diaBusqueda);
                mes = atoi(mesBusqueda);
                anio = atoi(anioBusqueda);

                // Ciclo para buscar
                while (pCabeza!=NULL)
                {
                    // Obtengo la fecha del dato en la lista
                    sAnio[0]=pCabeza->fecha[0];
                    sAnio[1]=pCabeza->fecha[1];
                    sAnio[2]=pCabeza->fecha[2];
                    sAnio[3]=pCabeza->fecha[3];
                    sAnio[4]=pCabeza->fecha[4];
                    sAnio[5]='\0';

                    // Mes
                    sMes[0]=pCabeza->fecha[5];
                    sMes[1]=pCabeza->fecha[6];
                    sMes[2]='\0';

                    // Dia
                    sDia[0]=pCabeza->fecha[8];
                    sDia[1]=pCabeza->fecha[9];
                    sDia[2]='\0';
                    
                    // Obtengo la fecha y hora numericamente del Nodo
                    int anioNodo    = atoi(sAnio);
                    int mesNodo     = atoi(sMes);
                    int diaNodo     = atoi(sDia);
                    
                    // Comparamos que coincida dia, mes y año
                    if (anio == anioNodo && mes == mesNodo && dia == diaNodo)
                    {
                        // Despliega la información del Nodo
                        printf("%d\t %d\t %s\t %s\t %s\t %s \n",
                                ++iContador,pCabeza->idEvento,pCabeza->fecha,pCabeza->hora,pCabeza->lugar,pCabeza->actividad);                        
                    }
                    // Mueve cabeza al siguiente elemento
                    pCabeza = pCabeza->pSiguiente;
                }
                // Salida del Case
                break;

            // Búsqueda por mes
            case 'm':
                // Obtengo el mes y anio
                mes = atoi(mesBusqueda);
                anio = atoi(anioBusqueda);

                // Ciclo para buscar
                while (pCabeza!=NULL)
                {
                    // Obtengo la fecha del dato en la lista
                    sAnio[0]=pCabeza->fecha[0];
                    sAnio[1]=pCabeza->fecha[1];
                    sAnio[2]=pCabeza->fecha[2];
                    sAnio[3]=pCabeza->fecha[3];
                    sAnio[4]=pCabeza->fecha[4];
                    sAnio[5]='\0';

                    // Mes
                    sMes[0]=pCabeza->fecha[5];
                    sMes[1]=pCabeza->fecha[6];
                    sMes[2]='\0';
                    
                    // Obtengo la fecha y hora numericamente del Nodo
                    int anioNodo    = atoi(sAnio);
                    int mesNodo     = atoi(sMes);
                    
                    // Comparamos que coincida mes y año
                    if (anio == anioNodo && mes == mesNodo )
                    {
                        // Despliega la información del Nodo
                        printf("%d\t %d\t %s\t %s\t %s\t %s \n",
                                ++iContador,pCabeza->idEvento,pCabeza->fecha,pCabeza->hora,pCabeza->lugar,pCabeza->actividad);                        
                    }
                    // Mueve cabeza al siguiente elemento
                    pCabeza = pCabeza->pSiguiente;
                }
                // Salida del Case
                break;
                
            // Búsqueda por año
            case 'a':
                // Obtengo el anio
                anio = atoi(anioBusqueda);

                // Ciclo para buscar
                while (pCabeza!=NULL)
                {
                    // Obtengo la fecha del dato en la lista
                    sAnio[0]=pCabeza->fecha[0];
                    sAnio[1]=pCabeza->fecha[1];
                    sAnio[2]=pCabeza->fecha[2];
                    sAnio[3]=pCabeza->fecha[3];
                    sAnio[4]=pCabeza->fecha[4];
                    sAnio[5]='\0';
                    
                    // Obtengo la fecha y hora numericamente del Nodo
                    int anioNodo    = atoi(sAnio);
                    
                    // Comparamos que coincida dia, mes y año
                    if (anio == anioNodo)
                    {
                        // Despliega la información del Nodo
                        printf("%d\t %d\t %s\t %s\t %s\t %s \n",
                                ++iContador,pCabeza->idEvento,pCabeza->fecha,pCabeza->hora,pCabeza->lugar,pCabeza->actividad);                        
                    }
                    // Mueve cabeza al siguiente elemento
                    pCabeza = pCabeza->pSiguiente;
                }
                // Salida del Case
                break;
        
            default:
                printf("El intervalo de búsqueda no es correcto.\n");
                break;
        }        
    }
    // Deja una Línea
    printf("\n");

    // Verifica si hubo registros
    if (iContador==0)
       printf("No se encontraron registros para el intervalo indicado.\n");

    // Mensaje de Espera   
    printf("Presione Enter para Continuar ...");
    getchar();

}
