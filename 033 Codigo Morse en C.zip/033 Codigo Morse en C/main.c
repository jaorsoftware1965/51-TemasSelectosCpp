// Tareas en C
// Convertir un Texto a Código Morse
// Las letras-numeros deben estar separados por 1 espacio y las palabras por /


// Incluimos la librería de Entrada y Salida Estandar de C
#include "stdio.h"
#include "string.h"
#include "stdlib.h"
#include "ctype.h"


// Estructura
struct Morse
{    
    // Declaramos el Vector para el Código
	char letra;	
	char codigo[6];	
};

// Declara el Vector para el Código
struct Morse codigo[37];
  
  
// Función para inicializar el Código
void fnInicializaCodigo();
char *fnGetMorse(char *cadena);


// Función Principal
int main()
{ 
 
    // Inicializa el Código
    fnInicializaCodigo();  
	
	// Lee una cadena
	char texto[80];
	puts("Capture un Texto");
	gets(texto);
	
	
	puts("\nEl Codigo Morse del texto es:");
	printf("%s",fnGetMorse(texto));
	

  // Finaliza la Aplicación
  return 0;
}


// Función para obtener el Código Morse
char *fnGetMorse(char *cadena)
{
	
	// Codigo Morse
	char *morse;	
	morse = (char*)malloc(1024);
	strcpy(morse,"");
	
	// Indice
	int indiceCadena;
	int indiceCodigo;
	
	// Cuenta 
	int cuentaCodigos=0;
	
	// Ciclo para cada uno de los carcateres de la cadena
	for (indiceCadena=0; indiceCadena < strlen(cadena); indiceCadena++)
	{
		// Ciclo para cada uno de los códigos
		for (indiceCodigo=0;indiceCodigo<37;indiceCodigo++)
		{
			// Compara
			if (toupper(cadena[indiceCadena])==codigo[indiceCodigo].letra)
			{
				// Lo encontró
				strcat(morse,codigo[indiceCodigo].codigo);				
				strcat(morse," ");
				
				// Incrementa el contador
				cuentaCodigos++;
			}
		}			
	}
	

	// Verifica que haya encontrado todos
	if (cuentaCodigos == strlen(cadena))
		// Retorna el Código
		return (morse);
	else
	    // Si no lo encuentra retorna Error
	    return ("Error");
	
}

// Inicializa el Código
void fnInicializaCodigo()
{
  // Inicializamos el Código
  codigo[0].letra='A';
  strcpy(codigo[0].codigo,".-");
 
  // Inicializamos el Código
  codigo[1].letra='B';
  strcpy(codigo[1].codigo,"-...");

  // Inicializamos el Código
  codigo[2].letra='C';
  strcpy(codigo[2].codigo,"-.-.");

  // Inicializamos el Código
  codigo[3].letra='D';
  strcpy(codigo[3].codigo,"-..");
  
  // Inicializamos el Código
  codigo[4].letra='E';
  strcpy(codigo[4].codigo,".");
  
  // Inicializamos el Código
  codigo[5].letra='F';
  strcpy(codigo[5].codigo,"..-.");
  
  // Inicializamos el Código
  codigo[6].letra='G';
  strcpy(codigo[6].codigo,"--.");
  
  // Inicializamos el Código
  codigo[7].letra='H';
  strcpy(codigo[7].codigo,"....");
  
  // Inicializamos el Código
  codigo[8].letra='I';
  strcpy(codigo[8].codigo,"..");
  
  // Inicializamos el Código
  codigo[9].letra='J';
  strcpy(codigo[9].codigo,".---");
  
  // Inicializamos el Código
  codigo[10].letra='K';
  strcpy(codigo[10].codigo,"-.-");
  
  // Inicializamos el Código
  codigo[11].letra='L';
  strcpy(codigo[11].codigo,".-..");
  
  // Inicializamos el Código
  codigo[12].letra='M';
  strcpy(codigo[12].codigo,"--");
  
  // Inicializamos el Código
  codigo[13].letra='N';
  strcpy(codigo[13].codigo,"-.");
  
  // Inicializamos el Código
  codigo[14].letra='O';
  strcpy(codigo[14].codigo,"---");
  
  // Inicializamos el Código
  codigo[15].letra='P';
  strcpy(codigo[15].codigo,".--.");
  
  // Inicializamos el Código
  codigo[16].letra='Q';
  strcpy(codigo[16].codigo,"--.-");
  
  // Inicializamos el Código
  codigo[17].letra='R';
  strcpy(codigo[17].codigo,".-.");
  
  // Inicializamos el Código
  codigo[18].letra='S';
  strcpy(codigo[18].codigo,"...");
  
  // Inicializamos el Código
  codigo[19].letra='T';
  strcpy(codigo[19].codigo,"-");
  
  // Inicializamos el Código
  codigo[20].letra='U';
  strcpy(codigo[20].codigo,"..-");
  
  // Inicializamos el Código
  codigo[21].letra='V';
  strcpy(codigo[21].codigo,"...-");
  
  // Inicializamos el Código
  codigo[22].letra='W';
  strcpy(codigo[22].codigo,".--");
  
  // Inicializamos el Código
  codigo[23].letra='X';
  strcpy(codigo[23].codigo,"-..-");
  
  // Inicializamos el Código
  codigo[24].letra='Y';
  strcpy(codigo[24].codigo,"-.--");
  
  // Inicializamos el Código
  codigo[25].letra='Z';
  strcpy(codigo[25].codigo,"--..");
  
  // Inicializamos el Código
  codigo[26].letra='1';
  strcpy(codigo[26].codigo,".----");
  
  // Inicializamos el Código
  codigo[27].letra='2';
  strcpy(codigo[27].codigo,"..---");
  
  // Inicializamos el Código
  codigo[28].letra='3';
  strcpy(codigo[28].codigo,"...--");
  
  // Inicializamos el Código
  codigo[29].letra='4';
  strcpy(codigo[29].codigo,"....-");
  
  // Inicializamos el Código
  codigo[30].letra='5';
  strcpy(codigo[30].codigo,".....");
  
  // Inicializamos el Código
  codigo[31].letra='6';
  strcpy(codigo[31].codigo,"-....");
  
  // Inicializamos el Código
  codigo[32].letra='7';
  strcpy(codigo[32].codigo,"--...");
  
  // Inicializamos el Código
  codigo[33].letra='8';
  strcpy(codigo[33].codigo,"---..");
  
  // Inicializamos el Código
  codigo[34].letra='9';
  strcpy(codigo[34].codigo,"----.");
  
  // Inicializamos el Código
  codigo[35].letra='0';
  strcpy(codigo[35].codigo,"-----");
  
  // Inicializamos el Código
  codigo[36].letra=' ';
  strcpy(codigo[36].codigo,"/");
  
  // Finaliza
  return;
}