// -----------------------------------------------------
// Lista 2
// Escriba un programa que mezcle dos listas simplemente 
// ligadas de números enteros, cuyos valores  están  
// ordenados  crecientemente. 
// El  programa debe  generar  una  tercera  lista, también 
// ordenada, sin repetir elementos y no debe afectar las 
// listas dada como datos
// -----------------------------------------------------

// Se incluyen las librerias
#include <iostream>
#include <cstdlib>

// Define un espacio de nombres
using namespace std;

// Define la estructura del Nodo
struct nodo
{
   int          elemento;  // Los datos seran de tipo entero
   struct nodo *siguiente; // Puntero a siguiente elemento
};

// Puntero que ira siempre al final de la lista
nodo *finListaOrdenada1; 
nodo *finListaOrdenada2;
nodo *finListaResultante;

// Puntero a la cabeza de cada lista 
nodo *listaOrdenada1;
nodo *listaOrdenada2;
nodo *listaResultante;

// Prototipos de las Funciones a Usar
int  menuPrincipal(); 

// Captura la Lista de acuerdo al Orden indicado
void capturarLista(char cualLista);

// Despliega la Lista
void mostrarLista(char cualLista);

// Depura la lista de acuerdo al Orden indicado
void generarListaResultante();

// Inserta un Elemento a la lista al Final
void insertarEnLista(char cualLista,       // Indica cual Lista Insertar
                     int  numeroInsertar); // Elemento a Insertar

// BUsca un Elemento en la Lista Resultante
bool fnExisteElemento();

// Programa Principal
int main(void)
{    
    // Inicializa las Listas
    listaOrdenada1 = NULL;
    listaOrdenada2 = NULL;
    listaResultante = NULL;

    // Variable
    int opcionSeleccionada; 

    // Ciclo para capturar la primera lista
    do
    {
        // Despliega el Menu Principal    
        opcionSeleccionada = menuPrincipal();        

        // Verifica que función realizar
        switch(opcionSeleccionada)
        {                
            case 1:
                    // Capturar Lista Ordenada 1
                    capturarLista('1'); 
                    break;

            case 2:
                    // Mostrar lista Ordenada 1
                    mostrarLista('1'); 
                    break;
            case 3:
                    // Depurar lista Sin Orden
                    capturarLista('2');
                    break;

            case 4:
                    // Capturar lista Sin Orden
                    mostrarLista('2');
                    break;

            case 5:
                    // Genera la Lista Resultane
                    generarListaResultante();
                    break;
                    
            case 0: 
                    // Mensaje de Salida
                    cout << "El Programa Finalizara ...";
                    break;        
                    
            default:
                    // Mensaje de Opción No valida 
                    cout << "Opcion No Valida ...";
                    break;


        }

        // Cambia de Linea pausa el programa
        cout << endl << endl;
        system("pause");  

        // Limpia la pantalla
        system("cls");

    }while(opcionSeleccionada != 0);

    // Fin del Programa
    return 0;
}

// Despliega el menu Principal
int menuPrincipal()
{
    // Variable para Leer la Opción    
    int opcion;    

    // Despliega el Menu
    cout << "-------------------------------" << endl;
    cout << "Menu Principal                 " << endl;
    cout << "-------------------------------" << endl;
    cout << "1. Capturar Lista Ordenada 1    " << endl;
    cout << "2. Mostrar  Lista Ordenada 1    " << endl << endl;
    cout << "3. Capturar Lista Ordenada 2    " << endl;
    cout << "4. Mostrar  Lista Ordenada 2    " << endl << endl;    
    cout << "5. Crear la Lista Resultante    " << endl;    
    cout << "0. Salir                        " << endl;
    cout << "Seleccione: ";
    
    // Lee la opción
    cin >> opcion;

    // Retorna
    return opcion;
}

// Función para Insertar en Lista Con Orden
void insertarEnLista(char cualLista,
                     int numeroInsertar)
{
   // Define un Nuevo Nodo     
   nodo   *nuevo;

   // Crea el Nodo
   nuevo = new struct nodo;
   
   // Coloca el numero a Insertar
   nuevo->elemento = numeroInsertar;

   // Siguiente apunta a NULL
   nuevo->siguiente = NULL;

   // Verifica en cual lista insertar
   if (cualLista=='1')
   {
      // Lista 1
      if (listaOrdenada1 == NULL)
      {
         // Es el primer elemento;
         listaOrdenada1    = nuevo; // Lista apunta al Nuevo
         finListaOrdenada1 = nuevo; // Final tambien al Nuevo
      }
      else
      {
         // El Nuevo Siguiente apunta a la 
         finListaOrdenada1->siguiente = nuevo;
         finListaOrdenada1 = nuevo;         
     }
   }
   else
      if (cualLista=='2')
      {                  
         // Lista 2
         if (listaOrdenada2 == NULL)
         {
            // Es el primer elemento;
            listaOrdenada2    = nuevo; // Lista apunta al Nuevo
            finListaOrdenada2 = nuevo; // Final tambien al Nuevo
         }
         else
         {
            // El Nuevo Siguiente apunta a la 
            finListaOrdenada2->siguiente = nuevo;
            finListaOrdenada2 = nuevo;         
         }
      }
      else
      {
         // Lista Resultante
         if (listaResultante == NULL)
         {
            // Es el primer elemento;
            listaResultante    = nuevo; // Lista apunta al Nuevo
            finListaResultante = nuevo; // Final tambien al Nuevo
         }
         else
         {
            // El Nuevo Siguiente apunta a la 
            finListaResultante->siguiente = nuevo;
            finListaResultante = nuevo;         
         }
      }     
}

// Captura la Lista de acuerdo al Orden indicado
void capturarLista(char cualLista)
{
   // Variable para capturar datos
   int numero;
   int anterior;

   // Verifica si es ordenada
   if (cualLista == '1')
   {
      // Ciclo para leer la lista1 de Datos
      do
      {
         // Verifica si la lista ya tiene datos para obtener el mayor
         if (listaOrdenada1!=NULL)
            anterior = finListaOrdenada1->elemento;
         else
            anterior = -1;   
         // Ciclo para capturar los datos
         cout << "Capture el Dato Ordenado a Insertar (0-Finalizar)" << endl;
         cin >> numero;

         // Verifica que no sea negativo
         if (numero < 0)
         {
            cout << "Capture solo numeros mayores que 0; o 0 para salir" << endl;
            system("Pause");
         }
         else
         {
            // Verifica que no sea la salida
            if (numero !=0)
            {
               // Verifica que sea mayor que el anterior
               if (numero >= anterior)
               {
                  // Lo inserta
                  insertarEnLista('1',numero);

                  // Actualiza el Anerior
                  anterior = numero;
               }
               else
               {
                  cout << "Debes capturar un numero mayor o igual al anterior[" << anterior <<"]" << endl;
                  system("Pause");
               }
            }                              
         }
         // Verifica el Numero
      }while (numero != 0);      
   }
   else
   {
      // Ciclo para leer la lista2 de Datos
      do
      {
         // Verifica si la lista2 ya tiene datos para obtener el mayor
         if (listaOrdenada2!=NULL)
            anterior = finListaOrdenada2->elemento;
         else
            anterior = -1;   
         // Ciclo para capturar los datos
         cout << "Capture el Dato Ordenado a Insertar (0-Finalizar)" << endl;
         cin >> numero;

         // Verifica que no sea negativo
         if (numero < 0)
         {
            cout << "Capture solo numeros mayores que 0; o 0 para salir" << endl;
            system("Pause");
         }
         else
         {
            // Verifica que no sea la salida
            if (numero !=0)
            {
               // Verifica que sea mayor que el anterior
               if (numero >= anterior)
               {
                  // Lo inserta
                  insertarEnLista('2',numero);

                  // Actualiza el Anerior
                  anterior = numero;
               }
               else
               {
                  cout << "Debes capturar un numero mayor o igual al anterior[" << anterior <<"]" << endl;
                  system("Pause");
               }
            }                              
         }
         // Verifica el Numero
      }while (numero != 0);      
   }

   // Mensaje
   cout << "Has finalizado la captura de la Lista" << endl;
}

// Depura la lista de acuerdo al Orden indicado
void mostrarLista(char cualLista)
{
   // Apuntador para recorrer la lista
   nodo *lista;

   // Verifica cual lista va a mostrar
   if (cualLista=='1')
   {
      // Verifica que no esté vacía
      if (listaOrdenada1==NULL)
      {
         // Mensaje
         cout << "La Lista 1 esta vacia ..." << endl;
      }
      else
      {
         // Mensaje
         cout << "Los Elementos de la Lista 1:" << endl;

         // Obtiene el Apuntador
         lista = listaOrdenada1;

         while (lista!=NULL)
         {
            // Despliega el Dato
            cout << lista->elemento << endl;

            // Se desplaza al siguiente
            lista = lista->siguiente;
         }
      }      
   }
   else
      if (cualLista=='2')
      {
         // Verifica que no esté vacía
         if (listaOrdenada2==NULL)
         {
            // Mensaje
            cout << "La Lista 2 esta vacia ..." << endl;
         }
         else
         {
            // Mensaje
            cout << "Los Elementos de la Lista 2 son:" << endl;

            // Obtiene la lista
            lista = listaOrdenada2;

            while (lista!=NULL)
            {
               // Despliega el Dato
               cout << lista->elemento << endl;

               // Se desplaza al siguiente
               lista = lista->siguiente;
            }
         }
      }
      else
      {
         // Verifica que no esté vacía
         if (listaResultante==NULL)
         {
            // Mensaje
            cout << "La Lista Resultante esta vacia ..." << endl;
         }
         else
         {
            // Mensaje
            cout << "Los Elementos de la Lista Resultante son:" << endl;

            // Obtiene la lista
            lista = listaResultante;

            while (lista!=NULL)
            {
               // Despliega el Dato
               cout << lista->elemento << endl;

               // Se desplaza al siguiente
               lista = lista->siguiente;
            }
         }
      }
}

// Busca un Elemento en la Lista Resultante
bool fnExisteElemento(int elemento)
{
   // Variable que controla si existe
   bool existe=false;
   nodo *lista;

   // Verifica que no esté vacía
   if (listaResultante!=NULL)
   {      
      // Obtiene el Apuntador
      lista = listaResultante;

      
      while (lista!=NULL)
      {
         // Verifica si es el elemento
         if (lista->elemento == elemento)
         {
               // Si existe
               existe = true;

               // Sale del ciclo
               break;
         }
            
         // Se desplaza al siguiente
         lista = lista->siguiente;
      }
   }

   // Retorna
   return existe;
}


// Depura la lista de acuerdo al Orden indicado
void generarListaResultante()
{    
   // Apuntador para recorrer la lista 1
   nodo *lista1;
   nodo *lista2;

   // Asigna las listas
   lista1 = listaOrdenada1;
   lista2 = listaOrdenada2;
   //                    |
   // 10 20 20 30 40 50
   //                |
   // 30 40 40 50 60

   // Ciclo para generar la Lista Resultante
   while (true)
   {
      // Verifica que tenga datos la lista 1
      if (lista1!=NULL)
      {		
         // Verifica que tenga datos la lista 2
         if (lista2!=NULL)
         {		   
            // Compara cual de los 2 es el menor
            if (lista1->elemento <= lista2->elemento)
            {
               // Verifico que no exista ya en la lista
               if (!fnExisteElemento(lista1->elemento))
               {
                  // Lo inserta si no existe
                  insertarEnLista('R',lista1->elemento);
			      }

               // Desplaza el apuntador de la lista
               lista1 = lista1->siguiente;
            }
            else
            {
               // Verifico que no exista ya en la lista
               if (!fnExisteElemento(lista2->elemento))
               {
                  // Lo inserta si no existe
                  insertarEnLista('R',lista2->elemento);
			      }

               // Desplaza el apuntador de la lista
               lista2 = lista2->siguiente;
            }            
         }
         else
         {
            // Verifico que no exista ya en la lista el de lista1
            if (!fnExisteElemento(lista1->elemento))
            {
               // Lo inserta si no existe
               insertarEnLista('R',lista1->elemento);
            }

            // Desplaza el apuntador de la lista
            lista1 = lista1->siguiente;
         }
      }
      else
	   {
         // Verifica que lista2 no esté vacia
         if (lista2!=NULL)
         {
            // Verifico que no exista ya en la lista el de lista1
            if (!fnExisteElemento(lista2->elemento))
            {
               // Lo inserta si no existe
               insertarEnLista('R',lista2->elemento);
            }

            // Desplaza el apuntador de la lista
            lista2 = lista2->siguiente;

         }
         else
		   {			 
            // Las 2 estan vacias; finaliza
            break;                
		   }
	  }	  
   }    

   // Llama a la función de Despliegue
   mostrarLista('R');
}
