using System;

namespace App
{
    class holaMundo
    {
        static void Main(string[] args)
        {
            Console.WriteLine(Math.Min(5, 10));  
            Console.WriteLine("Hola mundo2");
            // Type your username and press enter
Console.WriteLine("Enter username:");

// Create a string variable and get user input from the keyboard and store it in the variable
string userName = Console.ReadLine();

// Print the value of the variable (userName), which will display the input value
Console.WriteLine("Username is: " + userName);
        }
    }
}