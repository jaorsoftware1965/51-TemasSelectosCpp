// ---------------------------------
// Temas Selectos en C
// Como usar Uniones en C
// ---------------------------------

// Incluimos las librerías
#include "stdio.h"
#include "string.h"

// Declaramos una unión
union stcDato
{
   int       entero;		//  4 Bytes
   char      caracter;      //  1 Byte
   double    doble;         //  8 Bytes
   char      cadena[5];     //  5 Bytes
};


// Define el tipo de dato de la unión
typedef union stcDato dato;


// Función Principal
int main()
{
	// Asigno datos de diferentes tipos
	printf("Como usar una Union en C \n");
	
	printf("Los espacios que ocupa cada dato\n");
	printf("int  %d\n",sizeof(int));
	printf("char %d\n",sizeof(char));
	printf("double %d\n",sizeof(double));
	printf("\n");
	
	// Declaro una variable de tipo dato
	dato x;
	printf("Lo que ocupa el dato en memoria:%d\n",sizeof(x));
	
	// Asigna un Entero y lo imprime
	x.entero=10;
	printf("El valor entero:%d\n",x.entero);
	
	// Asigna un caracter
	x.caracter='X';
	printf("El valor caracter:%c\n",x.caracter);
	
	// Asigna un Doble y lo imprime
	x.doble=10.234;
	printf("El valor doble:%lf\n",x.doble);
		
	// Asigna una Cadena y lo imprime
	strcpy(x.cadena,"12345");
	printf("El valor cadena:%s\n",x.cadena);
	printf("\n");
	
	printf("Imprimimos todo de nuevo\n");
	printf("El valor entero:%d\n",x.entero);
	printf("El valor caracter:%c\n",x.caracter);
	printf("El valor doble:%lf\n",x.doble);
	printf("El valor cadena:%s\n",x.cadena);
	
	// Asigna un Doble y lo imprime
	x.doble=100.233;
	
	printf("Imprimimos todo de nuevo\n");
	printf("El valor entero:%d\n",x.entero);
	printf("El valor caracter:%c\n",x.caracter);
	printf("El valor doble:%lf\n",x.doble);
	printf("El valor cadena:%s\n",x.cadena);
	
	
	
}