// ---------------------------------------------------------------
// Objetivo: Ejecutar comandos del Sistema operativo con C, C++
// ---------------------------------------------------------------

// Librerias Necesarias
#include <stdio.h>      /* printf */
#include <stdlib.h>     /* system */


// Función principal
int main ()
{
	// Variable para retorno
    int resultado; 
  
    printf ("Verificando disponibilidad del Sistema");
    if (system(NULL)) 
	    puts ("Sistema Disponible");
    else 
	{
	    puts ("Error: Sistema no disponible");
	    exit (EXIT_FAILURE);
	}
    
	// Ejecutando el comando date
    resultado = system ("g++ main.c -o main.exe");
	printf ("El Valor retornado fue: %d.\n",resultado);

    // Ejecutando el comando dir
    resultado = system ("type main.c");
	printf ("El Valor retornado fue: %d.\n",resultado);

    return 0;
}