// -------------------------------------------------------------------------------
// Objetivo: Cuenta Palabras en un texto separadas por espacio
// Ejemplo : En un canal de youtube del cual no puedo olvidarme
// Palabras: 10
// Para este programa primero depuraremos la cadena y luego buscaremos las palabras
// --------------------------------------------------------------------------------

// Librerias
#include "stdio.h"
#include "string.h"

// Funci�n principal
int main()
{
    // Variable para la Cadena
	char cadena[80];
	char depurada[80];
		
	// Indice
	int indice;
	
	// Contador de Palabras
	int contador=0;
		
	// Solicita la captura del Texto
	printf("Capture un Texto:");
	
	// Lee la cadena
	gets(cadena);
	
	// Bandera de que ya hubo letras
	int yaleyoLetras=0; // 0=No, 1=Si
	
	// indice cadena depurada
	int indiceDepurar=0;
	
	// Ciclo para eliminar espacios incorrectos
	for (indice=0; indice < strlen(cadena); indice++)
	{
		// Verifica si es un espacio
		if (cadena[indice]==' ')
		{
			// Verificamos si no es un espacio el anterior
			if (cadena[indice+1]!=' ' && yaleyoLetras==1 && cadena[indice+1]!='\x0')
			{
				// Pasamos el caracter a la cadena a depurar
				depurada[indiceDepurar]=cadena[indice];
				// incrementamos el contador de depurar
				indiceDepurar++;
			}
		}
		else
		{			
	        // Activamos bandera
			yaleyoLetras=1;
			// Pasamos el caracter a la cadena a depurar
			depurada[indiceDepurar]=cadena[indice];
			// incrementamos el contador de depurar
			indiceDepurar++;
		}
		
	}
	
	// Colocamos el fin de cadena 
	depurada[indiceDepurar]='\x0';
	
	// Cadena depurada
	printf("Cadena depurada \n");
	puts(depurada);

	// Una vez que la cadena ya esta depurada, contamos las palabras
	// Ciclo para contar las Letras
	for (indice=0; indice < strlen(depurada); indice++)
	{
		// Verifica si es un espacio en blanco y aumenta el contador
		if (depurada[indice]==' ')
			contador++;
	}
	// Incrementamos la palabra final
	contador++;
	
	// Mensaje
	printf("Palabras:%i\n",contador);
			
	// Finaliza la Aplicaci�n
	return 0;
}