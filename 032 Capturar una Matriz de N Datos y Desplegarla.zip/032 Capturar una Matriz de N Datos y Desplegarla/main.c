// ---------------------------------------------------------------
// Objetivo: Capturar Matriz de  RxC R=Renglones C=Columnas
// El numero maximo es de 5 x 5
// Ejemplo: Matriz de 3x4
// 3 4 5 6
// 5 6 7 8
// 9 0 8 7
// ---------------------------------------------------------------

// Se incluyen las librer�as necesarias
#include <stdio.h>

// Funci�n principal
int main()
{
	// Declaro la Matriz
	int matriz[5][5];
	
    // Variable para los Renglones y Columnas
	int Renglones;
	int Columnas;
		
	// Indice
	int indiceRenglones;
	int indiceColumnas;
		
	// Solicita cuantos renglones
	printf("Capture Cuantos Renglones de la Matriz (Max 5):");
	
	// Lee los Renglones
	scanf("%d",&Renglones);
	
	// Solicita cuantos columnas
	printf("Capture Cuantos Columnas de la Matriz (Max 5):");
	
	// Lee las Columnas
	scanf("%d",&Columnas);
		
	// Valida que no sean mayor que 5
	if (Renglones > 5 || Columnas > 5)
	{
		// Mensaje de Error
		printf(" Error en Renglones o Columnas");
		
		// Finaliza
		return 0;
	}
	
	// Ciclo para lectura de los datos
	for (indiceRenglones = 0; indiceRenglones < Renglones; indiceRenglones++)
	{		
		// Mensaje por Renglon
		printf("Captura el Renglon %d\n",indiceRenglones+1);

		// Ciclo de lectura de Columnas
		for (indiceColumnas=0; indiceColumnas < Columnas; indiceColumnas++)
		{
	   	    // Mensaje por Renglon
		    printf("Columna %d: ",indiceColumnas+1);				
			
			// Lee
		    scanf("%d",&matriz[indiceRenglones][indiceColumnas]);				
		}
		printf("\n");
	}
	
	// Cambia de Linea
	printf("\n");
	
	// Desplegando los datos
	printf("Desplegando la matriz completa\n");
	
	// Ciclo para Imprimir
	for (indiceRenglones=0; indiceRenglones < Renglones; indiceRenglones++)
	{		
		// Ciclo de lectura de Columnas
		for (indiceColumnas=0; indiceColumnas < Columnas; indiceColumnas++)
		{
	   	    // Mensaje por Renglon
		    printf("%02d ",matriz[indiceRenglones][indiceColumnas]);				
		}
		printf("\n");
	}
	
	// Finaliza la Aplicaci�n
	return 0;
}
