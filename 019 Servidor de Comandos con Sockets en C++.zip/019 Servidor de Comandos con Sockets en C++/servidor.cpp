// Temas Selectos de C++
// Servidor de Comandos con Sockets en C++
// servidor.cpp
// g++ servidor.cpp -l ws2_32 -o servidor

// Librerías
#include <iostream>
#include <string>
#include <windows.h>

// Nombre de Espacio
using namespace std;

// Variables globales para los Sockets
WSADATA wsaData;
SOCKET conn_socket,comm_socket;
SOCKET comunicacion;
struct sockaddr_in server;
struct sockaddr_in client;
struct hostent *hp;
int resp,stsize;

// Función para iniciar el Servidor
bool fnIniciandoServidor();

// Función Hilo para leer Mensajes
void* fnServidorLeyendo(void* arg);

// Función para enviar respuestas de los comando
void fnEnviarRespuestaComando(string mensaje);

// Funcìón para ejecutar el comando
void fnEjecutaComando(string comando);

// Programa Principal
int main(int argc, char *argv[])
{
    // Variable de Resultado
    int resultado = EXIT_SUCCESS;

    // Variable para envío de mensajes:
    char SendBuff[512];

    // Declaro un objeto hilo 
    pthread_t hilo;
  
    // Lanza el Hilo para Recibir los Mensajes
    if (fnIniciandoServidor())
    {
       // Creo el hilo y valido error
       if (pthread_create(&hilo, NULL, fnServidorLeyendo, NULL))    
       {   
            // Mensaje y valor de Retorno
            cout << "Error al Crear el Hilo" << endl;
            resultado = EXIT_FAILURE;
       }
       else
       {
            // Ejecuta el Hilo permanentemente
            pthread_join(hilo,NULL);

            // Mensaje de finalización
            cout << endl << "Haz Finalizado la Transmision ..." << endl;       

       }   
       
       // Cerramos el socket de la comunicacion
       closesocket(comm_socket);
  
       // Cerramos liberia winsock
       WSACleanup();              
    }
    else
       resultado = EXIT_FAILURE;

    // Finaliza
    return resultado;          
} 

// Función para iniciar el Servidor
bool fnIniciandoServidor()
{
   // Variable de Resultado
   bool resultado=true;

   // Inicializamos la DLL de sockets
   resp = WSAStartup(MAKEWORD(1,0),&wsaData);

   // Mensaje
   cout << "Iniciando libreria ..." << endl;

   // Validación
   if (resp)
   {
      cout << "Error al inicializar socket\n" << endl;
      resultado = false;
   }
   else
   {
      // Mensaje
      cout << "Accediendo a localhost ..." << endl;
  
      // Obtenemos la IP que usará nuestro servidor
      hp = (struct hostent *)gethostbyname("localhost");

      // Verificamos
      if (!hp)
      {
         cout << "No se ha encontrado servidor...\n" << endl;
         WSACleanup();
         resultado = false;
      }
      else
      {
          // Mensaje
          cout << "Creando el Socket ..." << endl;

          // Creamos el socket...
          conn_socket = socket(AF_INET,SOCK_STREAM, 0);

          // Validamos el Socket
          if (conn_socket == INVALID_SOCKET) 
          {
              cout << "Error al crear socket\n" << endl;
              WSACleanup();
              resultado = false;
          }
          else
          {
              // Mensaje
              cout << "Abriendo el Puerto ..." << endl;

              // Configurando
              memset(&server, 0, sizeof(server)) ;
              memcpy(&server.sin_addr, hp->h_addr, hp->h_length);
              server.sin_family = hp->h_addrtype;
              server.sin_port = htons(6000);

              // Asociamos ip y puerto al socket
              resp = bind(conn_socket, (struct sockaddr *)&server, sizeof(server));

              // Validación
              if (resp == SOCKET_ERROR)
              {
                  cout << "Error al asociar puerto e ip al socket\n" << endl;
                  closesocket(conn_socket);
                  WSACleanup();
                  resultado = false;
              }
              else
              {
                  // Mensaje
                  cout << "Validando Conexiones entrantes ..." << endl;

                  if (listen(conn_socket, 1) == SOCKET_ERROR)
                  {
                      cout << "Error al habilitar conexiones entrantes" << endl;
                      closesocket(conn_socket);
                      WSACleanup();
                      resultado = false;
                  }
                  else
                  {
                      // Aceptamos conexiones entrantes
                      cout << "Esperando conexiones entrantes... " << endl;

                      stsize=sizeof(struct sockaddr);
                      comm_socket = accept(conn_socket,(struct sockaddr *)&client,&stsize);

                      // Verifica que si no es válida la conexión
                      if (comm_socket == INVALID_SOCKET)
                      {
                          cout << "Error al aceptar conexión entrante\n" << endl;
                          closesocket(conn_socket);
                          WSACleanup();
                          resultado = false;
                      }
                      else
                      {
                          // Mensaje de Conexión
                          cout << "Conexion entrante desde:" << inet_ntoa(client.sin_addr) << endl;
                                  
                          // Como no vamos a aceptar más conexiones cerramos el socket escucha
                          closesocket(conn_socket);
                      }                      
                  }                                                
              }              
          }        
      }      
   }   

   // Retorna
   return resultado;
}  

// Función Hilo para leer Mensajes
void* fnServidorLeyendo(void* arg)
{    
    // Variable para recibir los Mensajes
    char RecvBuff[512];

    // Ciclo para recepción de Mensajes
    while(true)
    {      
      // Lanza recepción de Mensajes
      recv (comm_socket, RecvBuff, sizeof(RecvBuff), 0);

      // Valida fin de transmisión
      if (strcmp(RecvBuff,"EOT")==0)
      {
         // Mensaje del Cliente
         cout << endl << "El Cliente ha finalizado la Transmision ..." << endl << endl;  
         break;
      }
      else    
         fnEjecutaComando(RecvBuff);
    }    

    // Finaliza 
    exit(0);
}

// Función para enviar respuestas de los comando
void fnEnviarRespuestaComando(string mensaje)
{
    // Variable para el Comando
    char SendBuff[512];

    // Copia el dato
    strcpy(SendBuff,mensaje.c_str());

    //Enviamos y recibimos datos...
    send (comm_socket, SendBuff, sizeof(SendBuff), 0);
}

// Funcìón para ejecutar el comando
void fnEjecutaComando(string comando)
{
    // Apuntador a un manejador de Archivo
	FILE* in;

	// El buffer para leer datos
	char buffer[512];

    // Mensaje
    cout << "Ejecutando comando ->" << comando << endl;

    // Ejecuta y valida 
	if (!(in = popen(comando.c_str(),"r")))	
    
		// Manda un mensaje de que no se pudo ejecutar
        fnEnviarRespuestaComando("No se pudo ejecutar el Comando");	
    
	else	
    {    
		// Ciclo para Leer desde el archivo los datos
		while (fgets(buffer,sizeof(buffer),in) != NULL)
		{
			// Lanza la respuesta
			fnEnviarRespuestaComando(buffer);
		}        
        // Cierra el popen
        if (pclose(in)!=0)
        {
           strcpy(buffer,"Hay un Error en el Comando\n");
           fnEnviarRespuestaComando(buffer);   
        }
        // Envia el EOC
        fnEnviarRespuestaComando("EOC");
    }
}
