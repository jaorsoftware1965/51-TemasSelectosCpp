// ------------------------------------------------------------------------------------------------
// Juego de la Vida
// Versión 1.0
// Juego Aleatorio
// ------------------------------------------------------------------------------------------------

// CIUDADANOS
// - Estado.     S-Sano, C-Contagiado, I-Inmune, F-Fallecido
// - Salud.      Numero entre 0-99. Valor inicial Random entre 50-99. 
//               0 Es muerto
// - Edad.       Numero entre 1-99. Valor inicial Random
// - Contagio.   Numero entre 1-3 para indicar a cuantos puede contagiar
// - Deterioro.  Numero entre 1-3 que indica cuanto disminuye la salud 
//               en base a la edad

//   Ejemplos
//   XEESSCD
//   F006511     F-Fallecido , Edad-65, Salud-00, Contagio-1, Deterioro-1
//   C547022     C-Contagiado, Edad-54, Salud-70. Contagio-2, Deterioro-2
//   S249032     S-Sano      , Edad-24, Salud-90, Contagio-3, Deterioro-2
//   I517031     I-Inmune    , Edad-51, Salud-70, Contagio-3, Deterioro-1
  
// Consideraciones.
// 1.- El infectado solo puede infectar a su alrededor
//     Si ya no hay sanos a su alrededor ya no infectará
// 	   Tiene 8 posiciones máximas posibles: XXX
// 	                                        XCX
//                                          XXX
// 2.- El Contagiado cambia su salud de acuerdo a edad y deterioro 
//     Salud = (edad/2*deterioro)
										 
// 3.- El Inmune y muerto por obviedad no cambia de salud 
  
// LOGICA  
// 0.- La Ciudad es de 5 x 5 = 25 Ciudadanos
// 1.- Los ciudadanos están todos sanos inicialmente
// 2.- Se inicia con un contagio al azar.
// 3.- Cada ciclo los contagiados, contagian a su alrededor de 
//     acuerdo a su capacidad de contagio
// 4.- Cada ciclo los contagiados disminuyen su salud con la siguiente 
//     formula: salud = salud - (edad/2*deterioro)	
// 5.- El contagiado contagia siguiendo el orden indicado en consideraciones
// 6.- Cada ciclo(dia) se genera una inmunidad aleatoriamente para los 
//     contagiados; Es decir se cura un contagiado
// 6.- El programa termina cuando 
//     - Todos están contagiados y morirán con el paso del tiempo
// 	   - La Ciudad está inmunizada, con inmunes y muertos

// Se incluyen las librerías
#include <stdio.h> 
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <stdlib.h>

// Constantes
#define   maxRenglones  6
#define   maxColumnas   6

// Variables para el control de la pandemia
int sanos, contagios, inmunes, fallecidos;

// Para obtener un numero aleatorio
int aleatorio(int min, int max) 
{
	// Retorna el Numero Aleatorio
    return (min + rand() % (max + 1 - min));
}

// Estructura para el Ciudanano
struct ciudadano
{
	char estado;    // S-Sano C-Contagiado F-Fallecido I-Inmune
	int  edad;      // de 1 a 100
	int  salud;     // 00-99; 00=Fallecido; inicialmente entre 50-99
	int  contagio;  // 1-3 A cuantas personas puede contagiar por ciclo
	int  deterioro; // 1-3 Cuanto se puede deteriorar su salud
} ciudad[maxRenglones][5];     // Define la ciudad de 5 x 5

// Función para desplegar la ciudad
void desplegarCiudad()
{
	// Variables para renglon y columna
	int ren,col;

	// Ciclo
	for (ren=0; ren < maxRenglones; ren++)
	{
	    for (col=0; col < maxColumnas; col++)
		{
			// Despliega el dato
			printf("[%c "  ,ciudad[ren][col].estado);
			printf("%02d " ,ciudad[ren][col].edad);
			printf("%02d " ,ciudad[ren][col].salud);
			printf("%d "   ,ciudad[ren][col].contagio);
			printf("%d] "  ,ciudad[ren][col].deterioro);
		}
		printf("\n");
	}
}

// Función para procesar los contagios
void procesarPreContagios()
{
	// Variables
	int ren,col;

	// Ciclo
	for (ren=0; ren < maxRenglones; ren++)	
	    for (col=0; col < maxColumnas; col++)
		{
            // Verifica que tenga preContagio
			if (ciudad[ren][col].estado=='X')
			   ciudad[ren][col].estado='C';
		}
}

// Función para contagiar al Ciudadano
void preContagio(int ren,int col)
{
	// Coloca el Estado
	ciudad[ren][col].estado='X';
}

// Función para contagiar al Ciudadano
void contagiar(int ren,int col)
{
	// Coloca el Estado
	ciudad[ren][col].estado='C';
}

// Función para inmunizar al Ciudadano
int inmunizar(int ren,int col)
{
	// resultado
	int resultado = 0;

	// Coloca el Estado
	if (ciudad[ren][col].estado=='C')
	{
		// Inmunizar
		ciudad[ren][col].estado='I';

		// Cambia el Resultado
		resultado = -1;
	}

    // Devuelve el resultado
	return resultado;
}

// Función que busca contagiar a su alrededor
int buscaContagiar(int ren,int col, int contagio)
{
	int renContagio;
	int colContagio;
	int cuentaContagios=0;

    // Mensaje
	printf("El elemento [%d %d] buscando contagiar a:%d ... \n", ren, col, contagio);

	// Busca en la posición 1 posible
	renContagio = ren - 1;
	colContagio = col - 1;

	// Verifica si es posible
	if (renContagio >=0 && colContagio >= 0)
	   // Verifica si está sano para contagiar
	   if (ciudad[renContagio][colContagio].estado=='S')
	   {
          // Contagia
	      preContagio(renContagio,colContagio);

		  // Incrementa el Contador de Contagios
		  cuentaContagios++;
	   }

    // Verifica si puede continuar
	if (cuentaContagios == contagio)
	   // Ya no puede contagiar mas
	   return cuentaContagios;

    // Busca en la posición 2 posible
	renContagio = ren - 1;
	colContagio = col;

	// Verifica si es posible
	if (renContagio >=0)
	   // Verifica si está sano para contagiar
	   if (ciudad[renContagio][colContagio].estado=='S')
	   {
          // Contagia
	      preContagio(renContagio,colContagio);

		  // Incrementa el Contador de Contagios
		  cuentaContagios++;
	   }

    // Verifica si puede continuar
	if (cuentaContagios == contagio)
	   // Ya no puede contagiar mas
	   return cuentaContagios;

	// Busca en la posición 3 posible
	renContagio = ren - 1;
	colContagio = col + 1;

	// Verifica si es posible
	if (renContagio >=0 && colContagio < maxColumnas)
	   // Verifica si no está contagiado
	   if (ciudad[renContagio][colContagio].estado=='S')
	   {
          // Contagia
	      preContagio(renContagio,colContagio);

		  // Incrementa el Contador de Contagios
		  cuentaContagios++;
	   }

    // Verifica si puede continuar
	if (cuentaContagios == contagio)
	   // Ya no puede contagiar mas
	   return cuentaContagios;   

    // Busca en la posición 4 posible
	renContagio = ren;
	colContagio = col - 1;

	// Verifica si es posible
	if (colContagio >= 0)
	   // Verifica si no está contagiado
	   if (ciudad[renContagio][colContagio].estado=='S')
	   {
          // Contagia
	      preContagio(renContagio,colContagio);

		  // Incrementa el Contador de Contagios
		  cuentaContagios++;
	   }

    // Verifica si puede continuar
	if (cuentaContagios == contagio)
	   // Ya no puede contagiar mas
	   return cuentaContagios;

    // Busca en la posición 5 posible
	renContagio = ren;
	colContagio = col + 1;

	// Verifica si es posible
	if (colContagio < maxColumnas)
	   // Verifica si no está contagiado
	   if (ciudad[renContagio][colContagio].estado=='S')
	   {
          // Contagia
	      preContagio(renContagio,colContagio);

		  // Incrementa el Contador de Contagios
		  cuentaContagios++;
	   }

    // Verifica si puede continuar
	if (cuentaContagios == contagio)
	   // Ya no puede contagiar mas
	   return cuentaContagios;

    // Busca en la posición 6 posible
	renContagio = ren + 1;
	colContagio = col - 1;

	// Verifica si es posible
	if (renContagio < maxColumnas && colContagio >= 0)
	   // Verifica si no está contagiado
	   if (ciudad[renContagio][colContagio].estado=='S')
	   {
          // Contagia
	      preContagio(renContagio,colContagio);

		  // Incrementa el Contador de Contagios
		  cuentaContagios++;
	   }

    // Verifica si puede continuar
	if (cuentaContagios == contagio)
	   // Ya no puede contagiar mas
	   return cuentaContagios;

    // Busca en la posición 7 posible
	renContagio = ren + 1;
	colContagio = col;

	// Verifica si es posible
	if (renContagio < maxRenglones)
	   // Verifica si no está contagiado
	   if (ciudad[renContagio][colContagio].estado=='S')
	   {
          // Contagia
	      preContagio(renContagio,colContagio);

		  // Incrementa el Contador de Contagios
		  cuentaContagios++;
	   }

    // Verifica si puede continuar
	if (cuentaContagios == contagio)
	   // Ya no puede contagiar mas
	   return cuentaContagios;

	
	// Busca en la posición 8 posible
	renContagio = ren + 1;
	colContagio = col + 1;

	// Verifica si es posible
	if (renContagio < maxRenglones && colContagio < maxColumnas)
	   // Verifica si no está contagiado
	   if (ciudad[renContagio][colContagio].estado=='S')
	   {
          // Contagia
	      preContagio(renContagio,colContagio);

		  // Incrementa el Contador de Contagios
		  cuentaContagios++;
	   }

    // Verifica si puede continuar
	if (cuentaContagios == contagio)
	   // Ya no puede contagiar mas
	   return cuentaContagios;
	
}

// Función para procesar contagios
void procesarCiclo()
{
	// Variables para renglon y columna
	int ren,col;
	int salud;

	// Para los contagiados
	int contagiados=0;;

	// Mensaje
	printf("Procesando Ciclo ...\n");

	// Ciclo para renglones
	for (ren=0; ren < maxRenglones; ren++)
	{
		// Ciclo para columnas
	    for (col=0; col < maxColumnas; col++)
		{
			// Verifica si está contagiado
			if (ciudad[ren][col].estado=='C')
			{
			   // busca contagiar
			   contagiados = contagiados + buscaContagiar(ren,col,ciudad[ren][col].contagio);

			   // Calcula su salud //JAOR
			   //ciudad[ren][col].salud = ciudad[ren][col].salud - (ciudad[ren][col].edad/2*ciudad[ren][col].deterioro);
               ciudad[ren][col].salud = ciudad[ren][col].salud - (ciudad[ren][col].edad/10*ciudad[ren][col].deterioro);

			   // Verifica si ha fallecido
			   if (ciudad[ren][col].salud <= 0)
			   {
			       // Falleció
				   ciudad[ren][col].estado = 'F';
				   ciudad[ren][col].salud  =  0;
			   }
			}
		}
	}
	// Mensaje
	printf("Se contagiaron en el ciclo: %d \n",contagiados);

}

// Verifica que la ciudad esté toda contagiada
int ciudadContagiada()
{
	// resultado
	int resultado = -1; // Verdad inicialmente

	// Variables para renglon y columna
	int ren,col;

	// Ciclo para renglones
	for (ren=0; ren < maxRenglones; ren++)
		// Ciclo para columnas
	    for (col=0; col < maxColumnas; col++)
		{
			// Verifica que no esté contagiada
			if (ciudad[ren][col].estado!='C' && ciudad[ren][col].estado!='F')
			{
				// Colocamos falso
				resultado = 0;

				// Salimos
				break;
			}
		}
	
	// Devuelve el resultado
	return resultado;
}

// Verifica que la ciudad esté controlada
int ciudadControlada()
{
	// resultado
	int resultado = -1; // Verdad inicialmente

	// Variables para renglon y columna
	int ren,col;

	// Ciclo para renglones
	for (ren=0; ren < maxRenglones; ren++)
		// Ciclo para columnas
	    for (col=0; col < maxColumnas; col++)
		{
			// Verifica que todavía sea posible contagiar
			if (ciudad[ren][col].estado!='C' && 
			    ciudad[ren][col].estado!='I' &&
				ciudad[ren][col].estado!='F')
			{
				// Colocamos falso
				resultado = 0;

				// Salimos
				break;
			}
		}
	
	// Devuelve el resultado
	return resultado;
}


// Analiza la Pandemia
void analizaPandemia()
{	
	// Variables para renglon y columna
	int ren,col;

	// Incializando
	sanos      = 0;
	contagios  = 0;
	inmunes    = 0;
	fallecidos = 0;

	// Ciclo para renglones
	for (ren=0; ren < maxRenglones; ren++)
		// Ciclo para columnas
	    for (col=0; col < maxColumnas; col++)
		{
			// Cuenta sanos
			if (ciudad[ren][col].estado=='S')
			   sanos++;

			// Cuenta Contagios
			if (ciudad[ren][col].estado=='C')
			   contagios++;   

			// Cuenta Inmunes
			if (ciudad[ren][col].estado=='I')
			   inmunes++;      

			// Cuenta Fallecidos
			if (ciudad[ren][col].estado=='F')
			   fallecidos++;      
			    
		}
	
	// Despliega el Resultado
	printf("Estadisticas de la Pandemia\n");
	printf("Sanos      :%d \n",sanos);
	printf("Contagios  :%d \n",contagios);
	printf("Inmunes    :%d \n",inmunes);
	printf("Fallecidos :%d \n",fallecidos);	
}

// Función Principal
int main()
{ 
	// Pausa
	char pausa[10];

	
	// Variable para renglones y columnas
	int ren, col;

	// Variable para los datos
	int salud, edad, contagio, deterioro;
 
    // Iniciando el Random
	srand(time(NULL));

	// Mensaje
	printf("Generando la Ciudad ...\n");

	// Ciclo para generar aleatoriamente 25 ciudadanos
	for (ren=0; ren < maxRenglones;ren++)
	    for (col=0; col < maxColumnas; col++)
		{
			// Genera un numero aleatorio para la salud
			salud = aleatorio(80,99);

			// Genera un numero aleatorio para la edad
			//edad = aleatorio(1,99);
			edad = aleatorio(1,65);

			// Genera un numero aleatorio para el contagio
			contagio = aleatorio(1,3);

			// Genera un numero aleatorio para el deterioro
			deterioro = aleatorio(1,3);


			// Agregar el Ciudadano a la Ciudad
			ciudad[ren][col].estado    = 'S';
			ciudad[ren][col].edad      = edad;
			ciudad[ren][col].salud     = salud;
			ciudad[ren][col].contagio  = contagio;
			ciudad[ren][col].deterioro = deterioro;						
		};
    
	// Contagio Inicial
    ren = aleatorio(0,maxRenglones);
    col = aleatorio(0,maxColumnas);
    printf("Contagio inicial: ren:%d col:%d \n",ren,col);

	// Contagia el Ciudadano
    contagiar(ren,col);

	// Despliga la Ciudad con el primer contagio
	printf("Ciudad con el Primer Contagio \n");
	desplegarCiudad();	
	gets(pausa);


	// Ciclo para procesar contagios
	while (-1)
	{		
		// procesa el Ciclo
		procesarCiclo();

		// procesar preContagios
		procesarPreContagios();

		// Desplegar la ciudad
		desplegarCiudad();

        // Analiza la Pandemia
		analizaPandemia();

        // Verifica que esté contagiada
		if (ciudadContagiada())
		{
			// Mensaje
			printf("La ciudad esta totalmente contagiada ... \n");

			// Salida
			break;
		}

		// Verifica que esté sin posibilidad de Contagio
		if (ciudadControlada())
		{
			// Mensaje
			printf("La ciudad esta sin posibilidad de Contagio ... \n");
		}

		// Verifica que esté Inmunizada
		if (inmunes + fallecidos == maxRenglones*maxColumnas)
		{
			// Mensaje
			printf("La ciudad esta inmunizada ... \n");
			break;
		}

        // Ciclo para Inmunizar
		printf("Inmunizando ...\n");
		while (-1)
		{			
		    // Generando Inmunidad
            ren = aleatorio(0,maxRenglones);
            col = aleatorio(0,maxColumnas);

			// Verifica si logra inmunizar
			if (inmunizar(ren,col))
			{
				// Mensaje de Ciudadano Inmune
                printf("Inmunidad para: ren:%d col:%d \n",ren,col);

				// Despliega la Ciudad
				desplegarCiudad();

				// Analiza la Pandemia
				analizaPandemia();

				// Sale del Ciclo
				break;
			}
		}

		// Pausa
		gets(pausa);
		printf("\n");

	}

    // desplegar la Ciudad
	desplegarCiudad();

    // Mensaje
	printf("Programa Terminado ...\n");

	// Finaliza
	return 0;
}