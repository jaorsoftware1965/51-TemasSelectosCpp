// ---------------------------------------------------------------
// Objetivo: Contar cada vocal en un texto
// Ejemplo : 
// Texto   : En un canal de youtube del cual no puedo olvidarme
// Vocal a : 4
// Vocal e : 6
// Vocal i : 1
// Vocal o : 4
// Vocal u : 5

#include "stdio.h"
#include "string.h"

// Funci�n principal
int main()
{
    // Variable para la Cadena
	char cadena[80];	
		
	// Indice
	int indice;
	
	// Contador de Palabras
	int contadorAa=0;
	int contadorEe=0;
	int contadorIi=0;
	int contadorOo=0;
	int contadorUu=0;
		
	// Solicita la captura del entero
	printf("Capture un Texto:");
	
	// Lee la cadena
	gets(cadena);
		
	// Ciclo para eliminar espacios incorrectos
	for (indice=0; indice < strlen(cadena); indice++)
	{
		switch(cadena[indice])
		{
			case 'A':
			case 'a':
			         contadorAa++;
					 break;
			case 'E':
			case 'e':
			         contadorEe++;
					 break;		 
			case 'I':
			case 'i':
			         contadorIi++;
					 break;
			case 'O':
			case 'o':
			         contadorOo++;
					 break;
			case 'U':
			case 'u':
			         contadorUu++;
					 break;
		}
		
	}
		
	// Mensaje
	printf("Las Vocales encontradas son:\n");
	printf("Vocales Aa:%i\n",contadorAa);
	printf("Vocales Ee:%i\n",contadorEe);
	printf("Vocales Ii:%i\n",contadorIi);
	printf("Vocales Oo:%i\n",contadorOo);
	printf("Vocales Uu:%i\n",contadorUu);
			
	// Finaliza la Aplicaci�n
	return 0;
}