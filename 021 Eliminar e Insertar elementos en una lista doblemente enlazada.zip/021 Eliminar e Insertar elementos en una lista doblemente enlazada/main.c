// Tareas en C C++
// Eliminar e insertar elementos en una lista doblemente enlazada

// Incluimos la librería
#include "stdio.h"

// Estructura del Nodo
struct node
{
    int valor;
    struct node* next;
    struct node* prev;
};

// Función para imprimir la lista hacia adelante
void printDoubleLinkedListForwards(struct node *head)
{
    printf("Los valores de la lista hacia adelante son:\n");
    while (head!=NULL)
    {  
        printf("%d\t",head->valor);
        head = head->next;        
    }
    printf("\n\n");

}

void printDoubleLinkedListBackwards(struct node *head)
{
    printf("Los valores de la lista hacia atras son: \n");
    while (head!=NULL)
    {
        printf("%d\t",head->valor);
        head = head->prev;
    }
    printf("\n\n");
}

void insertNode(struct node* existente, struct node* nuevo)
{
    printf("Insertamos el nuevo con valor %d \n",nuevo->valor);
    printf("despues del existente con valor %d\n\n",existente->valor);

    // Enlazamos el next del existente al nuevo
    existente->next = nuevo;    

    // Enlazamos el nuevo su prev a existente;
    nuevo->prev = existente;
    nuevo->next = NULL;
}

void deleteNode(struct node* anterior)
{
    // Mensaje
    printf("Se ha eliminado el nodo con valor:%d\n\n",anterior->next->valor);
    anterior->next=NULL;
}

// Función Principal
int main()
{ 
    // Define los nodos
    struct node n1, n2, n3, n4, n5, n6, n7;
    
    // Les asigna valores
    n1.valor = 2;
    n2.valor = 4;
    n3.valor = 6;
    n4.valor = 8;
    n5.valor = 10;
    n6.valor = 12;
    n7.valor = 14;

    // Los enlaza hacia adelante
    n1.next = &n2;
    n2.next = &n3;
    n3.next = &n4;
    n4.next = &n5;
    n5.next = &n6;
    n6.next = &n7;
    n7.next = NULL;

    // Los enlaza hacia atrás
    n1.prev = NULL;
    n2.prev = &n1;
    n3.prev = &n2;
    n4.prev = &n3;
    n5.prev = &n4;
    n6.prev = &n5;
    n7.prev = &n6;

    // El Nodo cabeza
    struct node* head;

    // Lo enlaza al primero
    head = &n1;

    // Despliega la lista hacia adelante
    printDoubleLinkedListForwards(head);

    // Lo enlaza al ultimo
    head = &n7;

    // Despliega la lista hacia atras
    printDoubleLinkedListBackwards(head);

    // Crea otro nodo
    struct node n8;

    // Le colocamos el valor 16
    n8.valor = 16;

    // Inserta el Nodo
    insertNode(&n7, &n8);

    // Lo enlaza al primero
    head = &n1;

    // Despliega la lista hacia adelante
    printDoubleLinkedListForwards(head);

    // Lo enlaza al ultimo
    head = &n8;

    // Despliega la lista hacia atras
    printDoubleLinkedListBackwards(head);    

    // elimina el n8
    deleteNode(&n7);

    // Lo enlaza al primero
    head = &n1;

    // Despliega la lista hacia adelante
    printDoubleLinkedListForwards(head);

    // Lo enlaza al ultimo
    head = &n7;

    // Despliega la lista hacia atras
    printDoubleLinkedListBackwards(head);
 }


