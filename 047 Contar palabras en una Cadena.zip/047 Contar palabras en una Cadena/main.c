// ---------------------------------------------------------------
// Objetivo: Capturar una cadena e indicar cuantas palabras tiene
// Ejemplo: 
// Cadena  : En un canal de youtube del cual no puedo olvidarme
// Palabras: 10
// ---------------------------------------------------------------

// Se incluyen las librer�as necesarias
#include "stdio.h"
#include "string.h"

// Funci�n principal
int main()
{
    // Variable para el entero
	char cadena[80];
		
	// Indice
	int indice;
	
	// Contar
	int contador=0;
	
	// Bandera
	int leyoLetras=0;
		
	// Solicita la captura del Texto
	printf("Capture un Texto:");
	
	// Lee la Cadena
	gets(cadena);	
	
	// Ciclo para verificar cuantas palabras tiene
	for (indice=0; indice < strlen(cadena); indice++)
	{
		// Verifica si es espacio
		if (cadena[indice]==' ')
		{
			// Verifica  que no sean espacios iniciales
			if (leyoLetras==1)
				// Verifica que el siguiente no sea espacio
				if(cadena[indice+1]!=' ')
					// Incrementa el Contador
				    contador++;
		}
		else
			// Activa bandera
			leyoLetras=1;
	}
	
	// Verifica si debo agregar uno mas al final 
	if (cadena[indice-1]!=' ')
		contador++;
	
	
	// Despliega el Mensaje
	printf("Palabras:%i",contador);
	
	// Finaliza la Aplicaci�n
	return 0;
}
