/* 
   ------------------------------------------------------
   Ejercicio en C 
   Enviar 2 valores numéricos en un solo valor
   Ejemplo: Deseo enviar los valores 24 y 23, pero solo
            debo usar un parámetro
   ------------------------------------------------------
*/

// librerias
#include <stdio.h>      

// Función con 1 paramero long
void fnDosParametros(long xParametro);

// Función principal
int main ()
{
    // Variable para enviar el valor
    long valorEnviar;

    // Variable para leer un valor
    int valor;

    // Mensaje y Solicitud
    printf("Capture el primer valor a enviar:");
    scanf("%d",&valor);

    // El primer valor a pasar lo desplazamos 16 bits
    valorEnviar = valor << 16;

    printf("Capture el segundo valor a enviar:");
    scanf("%d",&valor);

    // El Segundo valor 
    valorEnviar = valorEnviar + valor;

    // Despliega los valores
    printf("Valor a Enviar:%ld \n",valorEnviar);

	//Llama a la función
    fnDosParametros(valorEnviar);
    	
	// Finaliza
    return 0;
}

// Función con N parametros
void fnDosParametros(long xParametro)
{
	// Variables
    unsigned short int valor2;
    valor2 = xParametro;
    
    int valor1;
    valor1 = xParametro >>16;

    // Desplegando
    printf("Valor1:%d \n",valor1);
    printf("Valor2:%d \n",valor2);    
    printf("Valor2:%hd\n",xParametro);
}
