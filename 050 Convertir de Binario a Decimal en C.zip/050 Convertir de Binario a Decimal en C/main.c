// ------------------------------------------------------------------------------
// Objetivo : Convertir un N�mero Binario a Base 10
//
// Para convertir un numero de Binario a Decimal, se multiplica el numero en cuesti�n;
// que en este caso solo son 0 y 1; por el valor de la posici�n que ocupa de derecha
// a Izquierda; considerando que las posiciones a partir de la 0; tiene los valores de
// 2 elevado a la 1; 2 elevado a la 1; 2 elevado a la 3; y as� sucesivamente.
// La suma de estas multiplicaciones es el valor en decimal
// 100  10  1         4 2 1
//   1   2  3         1 0 1      10011
//
// Ejemplo: See al numero en binario 10011
// Su valor en decimal es:
// 1 x 2e0 = 1 x  1 =  1
// 1 x 2e1 = 1 x  2 =  2
// 0 x 2e2 = 0 x  4 =  0
// 0 x 2e3 = 1 x  8 =  0
// 1 x 2e4 = 1 x 16 = 16
//                    --
//                    19
// ------------------------------------------------------------------------------

// Se incluyen las librer�as necesarias
#include "stdio.h"
#include "math.h"
#include "string.h"

// Funci�n principal
int main()
{
	// Vector para n�mero en cadena en binario
	char binario[9]; // 8 Bits m�ximo \x0
	
	// Indice
	int indice;
	
	// Resultado
	int resultado=0;
	    
	// Solicita la captura del entero
	printf("Capture un N�mero en binario (Max 8 bits):");
	
	// Lee el entero
	scanf("%s",binario);
	
	// Ciclo para validar que solo haya valores binarios
	for (indice =0; indice < strlen(binario); indice++)
		if (binario[indice]!='0' && binario[indice]!='1')
		{
			// Mensaje de Error
			printf("El N�mero capturado no es un binario");
			
			// Finaliza
			return 0;
		}
		
	// Ciclo para obtener el Valor en Decimal
	// 101
	// indice = 2/1/0
	// 10001111
	
	for (indice = strlen(binario)-1; indice >= 0; indice--)
		// Verifica que haya un 1
		if (binario[indice]=='1')
			// Realiza el C�lculo
		    resultado = resultado + 1 * pow(2,strlen(binario)-1-indice);
		   
	// Despliega el Resultado
	printf("El valor en Decimal es:%d",resultado);
	
	return 0;
}
