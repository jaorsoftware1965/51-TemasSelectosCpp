// ---------------------------------------------
// Tareas y Temas Selectos de C, C++
// Como colocar el Icono de la Aplicaci�n
// g++ -c main.cpp -o main.o
// windres resource.rc -o resource.o
// g++ main.o resource.o -o main.exe -mwindows
// g++ main.o resource.o -o main.exe -lgdi32
// ---------------------------------------------

#include "windows.h"

// Definimos la forma de cargar el Icono
#define IDI_ICON MAKEINTRESOURCE(7)

// Prototipo Funci�n que procesa los mensajes
LRESULT CALLBACK WndProc (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

// Variable para el Nombre de la Clase
TCHAR szAppName[] = TEXT ("IconoApp") ;


// Funci�n Principal
int WINAPI WinMain (HINSTANCE hInstance,      // instancia de la aplicaci�n
                    HINSTANCE hPrevInstance,  // Instancia previa
                    PSTR      szCmdLine,      // Argumentos de la aplicaci�n
					int       iCmdShow)       //
{

	// Variable para el Manejador de la Ventana
	HWND hwnd;

	// Variable para el Manejo de Mensajes
	MSG msg;

	// Variable para la estructura de la Ventana
	WNDCLASS wndclass;

    // Variable para el Manejador del Icon	
	HICON manejadorIcono;

	// Cuando es de la libreria
	//manejadorIcono = LoadIcon (NULL, IDI_ICON);
	
	// Cuando es de Usuario
	manejadorIcono = LoadIcon (hInstance, IDI_ICON);
	
	
	
	// Define la Ventana
	wndclass.style = CS_HREDRAW | CS_VREDRAW ;  // Estilo
	wndclass.lpfnWndProc = WndProc ;            // Funci�n que procesa los mensajes
	wndclass.cbClsExtra = 0 ;                   // Cuantos bytes se reservan extra en la estructura de la Clase
	wndclass.cbWndExtra = 0 ;                   // Cuantos bytes se reservan extra a continuaci�n de la instancia
	wndclass.hInstance = hInstance ;			// Instancia a la que pertenece la ventana
	//wndclass.hIcon = LoadIcon (NULL, IDI_APPLICATION) ; // Icono de la Ventana
	wndclass.hIcon = manejadorIcono ; // Icono de la Ventana
	wndclass.hCursor = LoadCursor (NULL, IDC_ARROW) ;   // Cursor que se usar� en la ventana
	wndclass.hbrBackground = (HBRUSH) GetStockObject (WHITE_BRUSH) ;  // Pincel que utilizar� la ventana
	wndclass.lpszMenuName = NULL ;        // Puntero a un recurso de Menu
	wndclass.lpszClassName = szAppName ;  // Nombre de la Clase

	// Intenga registrar la clase
	if (!RegisterClass (&wndclass))
	{
		// Si no se puede registrar manda un mensaje
		MessageBox (NULL, TEXT ("Este programa requiere Windows NT!"),
		            szAppName, MB_ICONERROR) ;
		return 0 ;
	}

	// Crea la Ventana
	hwnd = CreateWindow (szAppName,    // nombre de la clase
						 TEXT ("Colocando el Icono en la Aplicaci�n"), // titulo de la ventana
						 WS_OVERLAPPEDWINDOW, // Estilo de la Ventana
						 CW_USEDEFAULT, // x posici�n
						 CW_USEDEFAULT, // y posici�n
						 CW_USEDEFAULT, // ancho
						 CW_USEDEFAULT, // alto
						 NULL, // Manejador de la VEntana Padre
						 NULL, // Manejador del Menu o Ventana hija
						 hInstance, // Instancia de la Aplicaci�n
						 NULL) ; // Puntero a par�metros de creaci�n

	// Muestra la Ventana
	ShowWindow (hwnd,       // Manejador de la Ventana
	            iCmdShow) ; // Modo de Visualizaci�n

	// Actualiza la Ventana
	UpdateWindow (hwnd) ;

	// Ciclo que procesa los mensajes mientras haya en la cola
	while (GetMessage (&msg, NULL, 0, 0))
	{
		// Mientras haya mensajes los traslada y despacha
		TranslateMessage (&msg) ;
		DispatchMessage (&msg) ;
	}
	// Retorna el wParam del mensaje
	return msg.wParam ;
}

// Funci�n que procesa los mensajes
LRESULT CALLBACK WndProc (HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	// Procesamiento de Mensajes
	switch (message)
	{
		// Verifica que el evento sea destruir
		case WM_DESTROY:
			 PostQuitMessage (0) ;
			 return 0 ;
	}

	// Retorna el Control a la Funci�n
	return DefWindowProc (hwnd, message, wParam, lParam) ;
}
