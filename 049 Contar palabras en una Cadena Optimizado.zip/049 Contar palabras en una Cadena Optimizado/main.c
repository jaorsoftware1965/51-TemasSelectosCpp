// ----------------------------------------------------------------------------------------------------
// Objetivo: Cuenta Palabras en un texto separadas " ",",", ";",".","?"
// Ejemplo : En una ocasi�n, me dijo:  De que se trata ?. Me perdi !; no supe que decir. La vida sigue.
// Palabras: 10
// Para este programa primero depuraremos la cadena y luego buscaremos las palabras
// ----------------------------------------------------------------------------------------------------

// Librerias
#include "stdio.h"
#include "string.h"
#include "ctype.h"

// Funci�n principal
int main()
{
    // Variable para la Cadena
	char cadena[250];
			
	// Indice
	int indice;
	
	// Contador de Palabras
	int contador=0;
		
	// Solicita la captura del Texto
	printf("Capture un Texto:");
	
	// Lee la cadena
	gets(cadena);
		
	// bandera de palabra
	int hayLetrasCapturadas=0;
	
	// Ciclo para eliminar espacios incorrectos
	for (indice=0; indice < strlen(cadena); indice++)
	{
		// Verifica si es un signo de puntuaci�n o un espacio en blanco
		if (ispunct(cadena[indice]) || isblank(cadena[indice]))
		{
			// Verificamos 
			if (hayLetrasCapturadas)
			{
				// incrementamos el contador
				contador++;
				
			    // cambia la bandera
                hayLetrasCapturadas=0;							
			}
		}
		else
		{			
	        // Activamos bandera
			hayLetrasCapturadas=1;
		}		
	}
	
	// Si hay letras capturadas
	if (hayLetrasCapturadas)
		contador++;
	
	printf("[%d]",ispunct('?'));
	printf("[%d]",ispunct('�'));
	printf("[%d]",ispunct('!'));
	printf("[%d]",ispunct('�'));
	
	// Mensaje
	printf("Palabras:%i\n",contador);
			
	// Finaliza la Aplicaci�n
	return 0;
}