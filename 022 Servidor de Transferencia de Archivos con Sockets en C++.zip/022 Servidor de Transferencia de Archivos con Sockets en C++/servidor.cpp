// Temas Selectos de C++
// Servidor de Transferencia de archivos con Sockets en C++
// servidor.cpp
// g++ servidor.cpp -l ws2_32 -o servidor

// Librerías
#include <iostream>
#include <string>
#include <windows.h>

// Nombre de Espacio
using namespace std;

// Variables globales para los Sockets
WSADATA wsaData;
SOCKET conn_socket,comm_socket;
SOCKET comunicacion;
struct sockaddr_in server;
struct sockaddr_in client;
struct hostent *hp;
int resp,stsize;

// Enumerado para las etapas de transmisión
enum fasesTransmision
{
    FASE_COMANDO_FILE,
    FASE_NOMBRE_ARCHIVO,
    FASE_LONGITUD_ARCHIVO,
    FASE_RECIBIENDO_DATOS
};

// Variable para la fase de transmisión
int faseActual = 0;
bool transmisionFinalizada = false;


// Función para iniciar el Servidor
bool fnIniciandoServidor();

// Función Hilo para leer Mensajes
void* fnServidorLeyendo(void* arg);

// Función para enviar respuestas de los comando
void fnEnviarRespuestaComando(string mensaje);

// Función para agregar datos al nombre de una archivo
string fnAgregarAlNombre(string nombreArchivo, string agregado);


// Programa Principal
int main(int argc, char *argv[])
{
    // Variable de Resultado
    int resultado = EXIT_SUCCESS;

    // Variable para envío de mensajes:
    char SendBuff[512];

    // Declaro un objeto hilo 
    pthread_t hilo;
  
    // Lanza el Hilo para Recibir los Mensajes
    if (fnIniciandoServidor())
    {
       // Creo el hilo y valido error
       if (pthread_create(&hilo, NULL, fnServidorLeyendo, NULL))    
       {   
            // Mensaje y valor de Retorno
            cout << "Error al Crear el Hilo" << endl;
            resultado = EXIT_FAILURE;
       }
       else
       {
            // Ejecuta el Hilo permanentemente
            pthread_join(hilo,NULL);

            // Mensaje de finalización
            cout << endl << "Ha Finalizado la Transmision ..." << endl;       

       }   
       
       // Cerramos el socket de la comunicacion
       closesocket(comm_socket);
  
       // Cerramos libreria winsock
       WSACleanup();              
    }
    else
       resultado = EXIT_FAILURE;

    // Finaliza
    return resultado;          
} 

// Función para iniciar el Servidor
bool fnIniciandoServidor()
{
   // Variable de Resultado
   bool resultado=true;

   // Inicializamos la DLL de sockets
   resp = WSAStartup(MAKEWORD(1,0),&wsaData);

   // Mensaje
   cout << "Iniciando libreria ..." << endl;

   // Validación
   if (resp)
   {
      cout << "Error al inicializar socket\n" << endl;
      resultado = false;
   }
   else
   {
      // Mensaje
      cout << "Accediendo a localhost ..." << endl;
  
      // Obtenemos la IP que usará nuestro servidor
      hp = (struct hostent *)gethostbyname("localhost");

      // Verificamos
      if (!hp)
      {
         cout << "No se ha encontrado servidor...\n" << endl;
         WSACleanup();
         resultado = false;
      }
      else
      {
          // Mensaje
          cout << "Creando el Socket ..." << endl;

          // Creamos el socket...
          conn_socket = socket(AF_INET,SOCK_STREAM, 0);

          // Validamos el Socket
          if (conn_socket == INVALID_SOCKET) 
          {
              cout << "Error al crear socket\n" << endl;
              WSACleanup();
              resultado = false;
          }
          else
          {
              // Mensaje
              cout << "Abriendo el Puerto ..." << endl;

              // Configurando
              memset(&server, 0, sizeof(server)) ;
              memcpy(&server.sin_addr, hp->h_addr, hp->h_length);
              server.sin_family = hp->h_addrtype;
              server.sin_port = htons(6000);

              // Asociamos ip y puerto al socket
              resp = bind(conn_socket, (struct sockaddr *)&server, sizeof(server));

              // Validación
              if (resp == SOCKET_ERROR)
              {
                  cout << "Error al asociar puerto e ip al socket\n" << endl;
                  closesocket(conn_socket);
                  WSACleanup();
                  resultado = false;
              }
              else
              {
                  // Mensaje
                  cout << "Validando Conexiones entrantes ..." << endl;

                  if (listen(conn_socket, 1) == SOCKET_ERROR)
                  {
                      cout << "Error al habilitar conexiones entrantes" << endl;
                      closesocket(conn_socket);
                      WSACleanup();
                      resultado = false;
                  }
                  else
                  {
                      // Aceptamos conexiones entrantes
                      cout << "Esperando conexiones entrantes... " << endl;

                      stsize=sizeof(struct sockaddr);
                      comm_socket = accept(conn_socket,(struct sockaddr *)&client,&stsize);

                      // Verifica que si no es válida la conexión
                      if (comm_socket == INVALID_SOCKET)
                      {
                          cout << "Error al aceptar conexión entrante\n" << endl;
                          closesocket(conn_socket);
                          WSACleanup();
                          resultado = false;
                      }
                      else
                      {
                          // Mensaje de Conexión
                          cout << "Conexion entrante desde:" << inet_ntoa(client.sin_addr) << endl;
                                  
                          // Como no vamos a aceptar más conexiones cerramos el socket escucha
                          closesocket(conn_socket);
                      }                      
                  }                                                
              }              
          }        
      }      
   }   

   // Retorna
   return resultado;
}  

// Función Hilo para leer Mensajes
void* fnServidorLeyendo(void* arg)
{    
    // Apuntador a FILE
    FILE *pFile;

    // Variable para recibir los Mensajes
    char bufferDatos[1048575];
    
    // nombre de archivo
    string nombreArchivo;
    string longitudArchivo;

    // para Info
    string info;

    // Bytes recibidos
    int bytesRecibidos;

    // Ciclo para recepción de Mensajes
    while (!transmisionFinalizada)
    {                   
        // Recibe los datos   
        bytesRecibidos = recv (comm_socket, bufferDatos, 1048575, 0);
        
        // Verifica por fases
        switch (faseActual)
        {
          case FASE_COMANDO_FILE:

               // Valida fin de transmisión
               if (strcmp(bufferDatos,"EOT")==0)  
               {             
                  // Transmisión Finalizada
                  transmisionFinalizada = true;
               }
               else 
                   // Verifica si es el comando FILE              
                   if (strcmp(bufferDatos,"FILE")==0)
                   {
                       // Incrementa la Fase
                       faseActual++;

                       // Mensaje
                       cout << "Esperando Nombre de Archivo ..." << endl;                     
                       
                       // Manda Mensaje de que está en espera del Archivo                       
                       fnEnviarRespuestaComando("Servidor> Esperando Nombre de Archivo ...");                     
                   }                              
                   else
                   {
                       // Despliega el Mensaje
                       cout << "Comando desconocido recibido:" << bufferDatos << endl;

                       // Manda Mensaje de que está en espera del Archivo
                       fnEnviarRespuestaComando("Servidor> Comando desconocido ...");
                   }
               break;
          
          case FASE_NOMBRE_ARCHIVO:
               
               // Valida fin de transmisión
               if (strcmp(bufferDatos,"EOT")==0)  
               {             
                  // Transmisión Finalizada
                  transmisionFinalizada = true;
               }
               else 
                   {
                       // Incrementa la Fase
                       faseActual++;

                       // Construimos el nombre del archivo a recibir
                       nombreArchivo = bufferDatos;
                       nombreArchivo = fnAgregarAlNombre(nombreArchivo,"_recibido");

                       // Abrimos el archivo en modo binario de Escritura
                       pFile = fopen ( nombreArchivo.c_str() , "wb" );

                       // Despliega el nombre del Archivo
                       cout << "Archivo a recibir:" << nombreArchivo << endl;
                       
                       // Mensajes locales
                       cout << "Esperando Longitud de Archivo ..." << endl;
                       
                       // Manda Mensaje de que está en espera del Archivo
                       fnEnviarRespuestaComando("Servidor> Esperando Longitud de Archivo ...");

                   }
               break;   

          case FASE_LONGITUD_ARCHIVO:
               // Valida fin de transmisión
               if (strcmp(bufferDatos,"EOT")==0)  
               {             
                  // Transmisión Finalizada
                  transmisionFinalizada = true;
               }
               else 
                   {
                       // Incrementa la Fase
                       faseActual++;

                       // Obtenemos la longitud desde el buffer
                       longitudArchivo = bufferDatos;

                       // Despliega el nombre del Archivo
                       cout << "Bytes a Recibir:" << longitudArchivo << endl;
                       
                       // Mensajes locales
                       cout << "Recibiendo Datos ..." << endl;
                       
                       // Manda Mensaje de que está en espera del Archivo
                       fnEnviarRespuestaComando("Servidor> Recibiendo Datos ...");

                   }
               break;                  
               
          case FASE_RECIBIENDO_DATOS:       
                                  
               // Valida fin de archivo
               if (strcmp(bufferDatos,"EOT")==0)  
               {            
                   // Cierra el Archivo
                   fclose (pFile);

                   // Mensaje del Cliente
                   cout << "Salida inesperada ..." << endl << endl;                    
                   
                   // Transmisión Finalizada
                  transmisionFinalizada = true;                   
               }
               else               
                    // Valida fin de archivo
                    if (strcmp(bufferDatos,"EOF")==0)  
                    {            
                        // Cierra el Archivo
                        fclose (pFile);

                        // Mensaje del Cliente
                        cout << "Bytes Recibidos:" << longitudArchivo << endl;
                        cout << "Se ha finalizado de recibir el archivo ..." << endl << endl;                    

                        // Se regresa a fase inicial
                        faseActual = 0;

                        // Manda Mensaje de que está en espera del Archivo
                        fnEnviarRespuestaComando("Servidor> Archivo Recibido ..."); 

                    }
                    else 
                    {                        
                        // Graba los datos en el archivo
                        fwrite (bufferDatos,bytesRecibidos,1,pFile);
                    }
               // Salida del Switch     
               break;                    
        }
    }   
    
    // Retorna Null
    return NULL; 
}

// Función para enviar respuestas de los comando
void fnEnviarRespuestaComando(string mensaje)
{
    // Variable para el Comando
    char SendBuff[512];

    // Copia el dato
    strcpy(SendBuff,mensaje.c_str());    

    // Enviando Respuesta
    send (comm_socket, SendBuff, sizeof(SendBuff), 0);
}

// Función para agregar datos al nombre de una archivo
string fnAgregarAlNombre(string nombreArchivo, string agregado)
{
   // Variable de Resultado
   string resultado;

   // Posición del Punto
   int posPunto;

   // Obtiene la posición del Punto
   posPunto = nombreArchivo.find(".");

   // Coloca  la parte izquierda mas el agregado
   resultado = nombreArchivo.substr(0,posPunto);

   // agrega 
   resultado = resultado + agregado + nombreArchivo.substr(posPunto);

   // retorna
   return resultado;

}