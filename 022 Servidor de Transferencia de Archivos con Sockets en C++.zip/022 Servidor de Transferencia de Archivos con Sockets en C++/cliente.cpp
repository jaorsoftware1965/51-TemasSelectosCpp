// Temas Selectos de C++
// Servidor de Archivos en C++
// cliente.cpp
// g++ cliente.cpp -l ws2_32 -o cliente

// Librerías
#include <iostream>
#include <string>
#include <windows.h>

// Espacio de Nombres
using namespace std;

// Variables del Servidor  
WSADATA wsaData;
SOCKET  conn_socket;
struct  sockaddr_in server;
struct  hostent *hp;
int     resp;
bool    transmisionActiva = true;
bool    enviandoArchivo   = false;

// nombre del Archivo
string archivoEnviar;

// Función para iniciar el Cliente
bool fnIniciandoCliente();

// Función Hilo para leer Mensajes
void* fnClienteLeyendo(void* arg);

// Función para enviar la longitud del Archivo
void fnEnviarLongitudArchivo();

// Función para enviar el archivo
void fnEnviarArchivo();

// Función para agregar datos al nombre de una archivo
string fnAgregarAlNombre(string nombreArchivo, string agregado);

// función principal
int main(int argc, char *argv[])
{
    // Variable para enviar mensajes
    char bufferDatos[512];
    
    // Declaro un objeto hilo 
    pthread_t hilo;

    // Variable de Resultado
    int resultado = EXIT_SUCCESS;

    // Respuesta del envío
    int respuesta;
 
    // Función que inicia el Cliente
    if (fnIniciandoCliente())
    {
       if (pthread_create(&hilo, NULL, fnClienteLeyendo, NULL))    
       {   
           // Mensaje y valor de Retorno
           cout << "Error al Crear el Hilo" << endl;
           resultado =  EXIT_FAILURE;
       }
       else
       {
          // Ciclo para enviar mensaje
          while (true)
          {
              // Mensaje
              gets(bufferDatos);

              // Copiamos a archivo enviar
              archivoEnviar = bufferDatos;
            
              // Se envía lo capturado
              respuesta = send (conn_socket,bufferDatos,sizeof(bufferDatos),0);             

              // Verifica si hubo error
              if (respuesta == SOCKET_ERROR)
              {
                 cout << "Error en el envio 1" << endl;
                 break;
              }
              else
                 if (respuesta != sizeof(bufferDatos))
                    cout << "No se enviaron todos los datos" << endl;
			  
			     // Verificamos fin de transmisión
              if (strcmp(bufferDatos,"EOT")==0)
                 break;
          }

          // Mensaje de Finalización
          transmisionActiva=false;
          cout << "Haz finalizado la Transmision ..." << endl;
                  
          // Cerramos el socket y liberamos la DLL de sockets
          closesocket(conn_socket);

          // Se cierra la librería
          WSACleanup();
           
       }          
    }
    else
       resultado = EXIT_FAILURE;
  
  // Se Finaliza
  return EXIT_SUCCESS;
} 


// Función para iniciar el Cliente
bool fnIniciandoCliente()
{
    // Variable de Resultado
    bool resultado = true;

    // Inicializamos la DLL de sockets
    resp = WSAStartup(MAKEWORD(1,0),&wsaData);

    // Validamos
    if (resp)
    {
       cout << "Error al inicializar socket" << endl;
       resultado = false;
    }
    else
    {
      // Obtenemos la IP del servidor en este caso localhost
      hp = (struct hostent *)gethostbyname("localhost");

      // Verifica si puedo obtener el servidor
      if (!hp)
      {
         cout << "No se ha encontrado servidor" << endl;
         WSACleanup();
         resultado = false;
      }
      else
      {
         // Creamos el socket...
         conn_socket = socket(AF_INET,SOCK_STREAM, 0);

         // Validación
         if (conn_socket == INVALID_SOCKET) 
         {
            cout << "Error al crear socket" << endl;
            WSACleanup();
            resultado = false;
         }
         else
         {
            // Configura los datos de conexión 
            memset(&server, 0, sizeof(server)) ;
            memcpy(&server.sin_addr, hp->h_addr, hp->h_length);
            server.sin_family = hp->h_addrtype;
            server.sin_port = htons(6000);

            // Nos conectamos con el servidor...
            if (connect(conn_socket,(struct sockaddr *)&server,sizeof(server))==SOCKET_ERROR)
            {
              cout << "Fallo al conectarse con el servidor" << endl;
              closesocket(conn_socket);
              WSACleanup();
              resultado = false;
            }
            else 
              // Mensaje de conexión
              cout << "Conexion establecida con :" << inet_ntoa(server.sin_addr) << endl;
        }              
      }
    }

    // Devuelve el Resultado
    return resultado;
}

// Función Hilo para leer Mensajes
void* fnClienteLeyendo(void* arg)
{
    // Variable para recibir los Mensajes
    char RecvBuff[512];

    // Ciclo para recepción de Mensajes
    while(true && transmisionActiva)
    {
       
       // Lanza recepción de Mensajes
       recv (conn_socket, RecvBuff, sizeof(RecvBuff), 0);

       // Verificando que la transmisión esté activa
       if (transmisionActiva)
       {
          // Despliega en la pantalla   
          cout << RecvBuff << endl; 

          if (strcmp(RecvBuff,"Servidor> Esperando Longitud de Archivo ...")==0)       
          {
             // Verifica que no se esté enviando el archivo
             if (!enviandoArchivo)
             {         
                // Mensaje
                cout << "Enviando longitud del Archivo ..." << endl;
                
                // Enviar la Longitud del Archivo
                fnEnviarLongitudArchivo();
             }                
          }
          else
            // Desplegando lo recibido
            if (strcmp(RecvBuff,"Servidor> Recibiendo Datos ...")==0)       
            {               
               // Verifica que no se esté enviando el archivo
               if (!enviandoArchivo)
               {         
                  // Mensaje
                  cout << "Enviando el Archivo ..." << endl;

                  // Cambia el Status
                  enviandoArchivo=true;                       

                  // Enviando el Archivo
                  fnEnviarArchivo();              
               }             
            }                                          
       }      
    }    
  
    // Finaliza 
    exit(0);
}

// Función para enviar el archivo
void fnEnviarLongitudArchivo()
{   
   // Apuntador a FILE
   FILE *pFile;
  
   // Variable para la Longitud en Bytes del Elemento a Grabar
   long longitudArchivo;

   // Variable para la longitud del archivo en cadena
   char strLongitudArchivo[128];
    
   // Abrimos el archivo en modo binario de Lectura
   pFile = fopen (archivoEnviar.c_str(), "rb" );
  
  
   // Verifica pertura correcta
   if (pFile==NULL) 
   {
	   // Mensaje de Error
	   printf ("Error en Apertura de Archivo para enviar Longitud ... \n"); 
	   return;	  
   }
  
   // Nos posicionamos al fin del Archivo
   fseek (pFile, 0 , SEEK_END);
  
   // Obtenemos su longitud
   longitudArchivo = ftell (pFile);
    
   // La obtiene
   strcpy(strLongitudArchivo,to_string(longitudArchivo).c_str());
   
   // Envía la Longitud
   send (conn_socket,strLongitudArchivo,strlen(strLongitudArchivo)+1,0); 
}

// Función para enviar el archivo
void fnEnviarArchivo()
{   
   // Nombres de Archivo
   char strArchivoOrigen[256];
   char strArchivoDestino[256];

   // Respuesta del Envio
   long respuesta;

   // Apuntadores a FILE
   FILE *pFileLectura;
   FILE *pFileEscritura;
  
   // Variable para la Longitud en Bytes del Archivo
   long  longitudArchivo;
  
   // Buffer donde se almacena la información a grabar
   char   *bufferDatos;

   // Resultado
   size_t resultado;

  
   // Archivos
   //cout << "Archivo Enviar:" << archivoEnviar << endl;
   strcpy(strArchivoOrigen,archivoEnviar.c_str());
   cout << "Archivo Origen:" << strArchivoOrigen << endl;
   strcpy(strArchivoDestino,(fnAgregarAlNombre(archivoEnviar,"_copia").c_str()));  
   cout << "Archivo Destino:" << strArchivoDestino << endl;

   // Abre los 2 Archivos en modo binario
   pFileLectura=fopen(archivoEnviar.c_str(),"rb");
   pFileEscritura=fopen(strArchivoDestino,"wb");
 
   // Verifica pertura correcta
   if (pFileLectura==NULL || pFileEscritura ==NULL) 
   {
	   // Mensaje de Error
	   printf ("Error en Apertura de Archivos"); 
	   return;	  
   }

   
   // Nos posicionamos al fin del Archivo
   fseek (pFileLectura , 0 , SEEK_END);
  
   // Obtenemos su longitud
   longitudArchivo = ftell (pFileLectura);
     
   // Colocamos el apuntador al principio
   rewind (pFileLectura);

   // Reservamos memoria dinámicamente de acuerdo a la longitud del archivo
   bufferDatos = (char*) malloc (sizeof(char)*longitudArchivo);
  
   // Verificamos que haya sido correcta
   if (bufferDatos == NULL) 
   {
	    // Mensaje de Error
	    printf("Error al Reservar Memoria"); 
	    return;
   }

   // Leemos el elemento desde el Archivo
   resultado = fread (bufferDatos,longitudArchivo,1,pFileLectura);
    
   // Verifica si hubo algún error
   if (resultado != 1) 
   {
	   // Mensaje de Error
	   printf("Error al Leer Archivo"); 
	   return;	  
   }
  
   // Grabamos el Archivo
   resultado = fwrite (bufferDatos,longitudArchivo,1,pFileEscritura);

   // Despliega los elementos grabados
   printf("Elementos grabados:%ld \n",resultado);
  
   // Verifica si hubo algún error
   if (resultado != 1) 
   {
	   // Mensaje de Error
	   printf("Error al Grabar Archivo"); 
	   return;
   }
  
   // Se envía lo leido
   respuesta = send (conn_socket,bufferDatos,longitudArchivo,0); 
   
   // Cierra el Archivo
   fclose (pFileLectura);
   fclose (pFileEscritura);
     
       
   // Verifica si hubo error
   if (respuesta == SOCKET_ERROR)
      cout << "Error en el envio 2" << endl;
   else
      if (respuesta != longitudArchivo)
         cout << "No se enviaron todos los datos" << endl;

   // MANDA EL FIN DE ARCHIVO
   strcpy(bufferDatos,"EOF");
   send (conn_socket,bufferDatos,sizeof(bufferDatos),0); 

   // Mensaje de Finalización
   cout << "Fin de Envio del Archivo " << endl;
   cout << "Caracteres Grabados y Enviados:" << longitudArchivo << endl;
  
   // Libera la Memoria
   free (bufferDatos);
  
   // Cambia la bandera de envío de archivo   
   enviandoArchivo=false;
}

// Función para agregar datos al nombre de una archivo
string fnAgregarAlNombre(string nombreArchivo, string agregado)
{
   // Variable de Resultado
   string resultado;

   // Posición del Punto
   int posPunto;

   // Obtiene la posición del Punto
   posPunto = nombreArchivo.find(".");

   // Coloca  la parte izquierda mas el agregado
   resultado = nombreArchivo.substr(0,posPunto);

   // agrega 
   resultado = resultado + agregado + nombreArchivo.substr(posPunto);

   // retorna
   return resultado;
}