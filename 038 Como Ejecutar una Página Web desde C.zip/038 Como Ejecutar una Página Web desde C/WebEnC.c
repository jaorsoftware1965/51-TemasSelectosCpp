// ---------------------------------------------------------------------------------------
// Temas Selectos en C 
// WebEnC.c
// Ejecutando una página Web desde C
// ---------------------------------------------------------------------------------------
#include <stdio.h>

int main()
{
    printf ("Content-Type: text/html\n\n");
    printf ("<html>");
    printf ("<head>");
	printf ("<title>WebEnC</title>");
	printf ("<META HTTP-EQUIV='REFRESH' CONTENT='5;URL=https://www.youtube.com/user/jaorsoftware'>");
	printf ("</head>");
    printf ("<body>");
    printf ("Esta pagina este creada en C y ejecutandose por CGI.<br/>");
	printf ("Redireccionando a JaorSoftware en Youtube  ...<br/>");
    printf ("</body>");
    printf ("</html>");
	
	// Finaliza la Aplicación
    return 0;
}