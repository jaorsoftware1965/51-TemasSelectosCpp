// ---------------------------------------------------------
// Práctica de Arreglos en C
// Una compañía distribuye N productos a distintos comercios 
// de la ciudad. Para ello almacena en un arreglo toda la 
// información relacionada a su mercancía:
// Clave: entero.
// Descripción: cadena de caracteres.
// Existencia: entero.
// Mínimo a mantener de existencia: entero.
// Precio unitario: real.

// Desarrollar un programa en C que pueda llevar a cabo los 
// siguientes incisos:

// a) Venta de un producto: se debe actualizar los campos que 
// correspondan, y verificar que la nueva existencia no esté 
// por debajo del mínimo. (Datos: clave, cantidad vendida).

// b) Reabastecimiento de un producto: se deben actualizar los
// campos que correspondan. (Datos: clave, cantidad comprada).

// c) Actualizar el precio de un producto. (Datos: clave, 
// porcentaje de aumento).

// Informar sobre un producto: se deben proporcionar todos los
// datos relacionados a un producto. (Datos: clave).

// Número máximo de Productos
#define INT_MAX_PRODUCTOS 10
#define INT_MAX_LON_DESCRIPCION 50


// Vectores para los datos
int  vecClaves[INT_MAX_PRODUCTOS];
char vecDescripciones[INT_MAX_PRODUCTOS][INT_MAX_LON_DESCRIPCION];
int  vecExistencias[INT_MAX_PRODUCTOS];
int  vecMinimos[INT_MAX_PRODUCTOS];
int  vecPrecios[INT_MAX_PRODUCTOS];

// Se incluyen las librerias
#include "stdio.h"

// Programa Principal
int main(void)
{    
   int   opcion=-1;  // Variable para el control del Menu
   int   clave;      // Variable para la Clave del Producto
   int   cantidad;   // Variable para la Cantidad a vender
   float porcentaje; // Variable para porcentaje Aumento

   // Variable para saber si encontré el producto
   char existe;

   // Variable para el Número de Productos
   int numeroProductos;
   int indiceProductos=0;

   // Solicita el Numero de Productos
   printf("Capture el Numero de Productos (MAX-10)\n");
   // Lee
   scanf("%d",&numeroProductos);
   if (numeroProductos>10)
   {
      printf("Error. El numero de productos no debe ser mayor de 10\n");      
   }
   else
   {
      // Mensaje
      printf("Capturando el Inventario de Productos ...\n");

      // Ciclo para leer los productos
      for (indiceProductos = 0; indiceProductos < numeroProductos; indiceProductos++)      
      {
         // Captura los datos
         printf("Capturando el Producto:[%d]\n",indiceProductos+1);
         printf("Clave:");
         scanf("%d",&vecClaves[indiceProductos]);         

         printf("Descripcion (Sin espacio en blanco):");         
         scanf("%s",&vecDescripciones[indiceProductos]);
                  
         printf("Existencia:");
         scanf("%d",&vecExistencias[indiceProductos]);

         printf("Minimo:");
         scanf("%d",&vecMinimos[indiceProductos]);

         printf("Precio:");
         scanf("%d",&vecPrecios[indiceProductos]);
         printf("\n");

      }
   }   

   // Ciclo de Control del Programa
   while (opcion!=0)
   {
       // Despliega el Menu Principal
       printf("--------------------------- \n");
       printf("Menu Principal              \n");
       printf("1.- Venta de un Producto    \n");
       printf("2.- Reabastecimiento        \n");
       printf("3.- Cambio de Precio        \n");
       printf("4.- Informacion             \n");
       printf("0.- Salida                  \n");

       // Lee la opción
       scanf("%d",&opcion);

       // Verifica la opción
       switch(opcion)
       {
          case 1:// Solicita la clave del producto a vender
                 printf("Clave del Producto:\n");
                 scanf("%d",&clave);
                 
                 // Inicializa la variable existencia
                 existe = 'N';

                 // Ciclo para buscar el Producto
                 for (indiceProductos=0; indiceProductos<numeroProductos; indiceProductos++)
                 {
                     // Compara
                     if (vecClaves[indiceProductos]==clave)
                     {  
                        // Despliega el Producto
                        printf("Informacion del Producto:\n");
                        printf("Clave       :%d\n",vecClaves[indiceProductos]);
                        printf("Descripcion :%s\n",vecDescripciones[indiceProductos]);
                        printf("Existencia  :%d\n",vecExistencias[indiceProductos]);
                        printf("Minimo      :%d\n",vecMinimos[indiceProductos]);
                        printf("Precio      :%d\n",vecPrecios[indiceProductos]);

                        // Cambia variable de existencia
                        existe ='S';

                        // Sale del Ciclo
                        break;
                     }
                 }

                 // Verifica si no lo encontró
                 if (existe=='N')
                 {
                    // Despliega mensaje de que no se encontró
                    printf("No existe un producto con la clave indicada\n");
                 }
                 else
                 {
                    // Solicita la Cantidad a Vender
                    printf("Capture la Cantidad a Vender:\n");
                    scanf("%d",&cantidad);

                    // Verifica que la cantidad no sea mayor que la existencia
                    if (cantidad >vecExistencias[indiceProductos])
                    {
                       printf("La Cantidad a vender excede la existencias.\n");
                       printf("La venta no se ha realizado\n");
                    }
                    else
                    {
                       // Actualiza la existencia del Producto
                       vecExistencias[indiceProductos]= vecExistencias[indiceProductos]-cantidad;

                       // Verifica si la existencia es menor que el mínimo
                       if (vecExistencias[indiceProductos]<vecMinimos[indiceProductos])
                       {
                          printf("La existencia del Producto esta debajo del minimo,\n");
                       }

                       // Mensaje
                       printf("Se ha realiza la venta del producto.\n");
                    }                    
                 }                 
                 break;
          case 2:// Solicita la clave del producto a vender
                 printf("Clave del Producto a reabastecer:\n");
                 scanf("%d",&clave);
                 
                 // Inicializa la variable existencia
                 existe = 'N';

                 // Ciclo para buscar el Producto
                 for (indiceProductos=0; indiceProductos<numeroProductos; indiceProductos++)
                 {
                     // Compara
                     if (vecClaves[indiceProductos]==clave)
                     {  
                        // Despliega el Producto
                        printf("Informacion del Producto:\n");
                        printf("Clave       :%d\n",vecClaves[indiceProductos]);
                        printf("Descripcion :%s\n",vecDescripciones[indiceProductos]);
                        printf("Existencia  :%d\n",vecExistencias[indiceProductos]);
                        printf("Minimo      :%d\n",vecMinimos[indiceProductos]);
                        printf("Precio      :%d\n",vecPrecios[indiceProductos]);

                        // Cambia variable de existencia
                        existe ='S';

                        // Sale del Ciclo
                        break;
                     }
                 }

                 // Verifica si no lo encontró
                 if (existe=='N')
                 {
                    // Despliega mensaje de que no se encontró
                    printf("No existe un producto con la clave indicada\n");
                 }
                 else
                 {
                    // Solicita la Cantidad a Vender
                    printf("Capture la Cantidad a Reabastecer:\n");
                    scanf("%d",&cantidad);

                    // Actualiza la existencia del Producto
                    vecExistencias[indiceProductos]= vecExistencias[indiceProductos]+cantidad;
                    
                    // Mensaje
                    printf("Se ha actualizado la existencia del producto.\n");
                 }                 
                 break;
          case 3:// Solicita la clave del producto a vender
                 printf("Clave del Producto a Cambiar Precio:\n");
                 scanf("%d",&clave);
                 
                 // Inicializa la variable existencia
                 existe = 'N';

                 // Ciclo para buscar el Producto
                 for (indiceProductos=0; indiceProductos<numeroProductos; indiceProductos++)
                 {
                     // Compara
                     if (vecClaves[indiceProductos]==clave)
                     {  
                        // Despliega el Producto
                        printf("Informacion del Producto:\n");
                        printf("Clave       :%d\n",vecClaves[indiceProductos]);
                        printf("Descripcion :%s\n",vecDescripciones[indiceProductos]);
                        printf("Existencia  :%d\n",vecExistencias[indiceProductos]);
                        printf("Minimo      :%d\n",vecMinimos[indiceProductos]);
                        printf("Precio      :%d\n",vecPrecios[indiceProductos]);

                        // Cambia variable de existencia
                        existe ='S';

                        // Sale del Ciclo
                        break;
                     }
                 }

                 // Verifica si no lo encontró
                 if (existe=='N')
                 {
                    // Despliega mensaje de que no se encontró
                    printf("No existe un producto con la clave indicada\n");
                 }
                 else
                 {
                    // Solicita la Cantidad a Vender
                    printf("Capture el Porcentaje a aumentar el Precio:\n");
                    scanf("%f",&porcentaje);

                    // Actualiza el Precio del Producto
                    vecPrecios[indiceProductos] = vecPrecios[indiceProductos] + (vecPrecios[indiceProductos]*(porcentaje/100));
                    printf("Se ha actualizado el precio del producto.\n");
                 }                 
                 break;
          case 4:// Solicita la Clave
                 printf("Capture la Clave del Producto:\n");
                 scanf("%d",&clave);
                 
                 // Inicializa la variable existencia
                 existe = 'N';

                 // Ciclo para buscar el Producto
                 for (indiceProductos=0; indiceProductos<numeroProductos;indiceProductos++)
                 {
                     // Compara
                     if (vecClaves[indiceProductos]==clave)
                     {
                        // Despliega el Producto
                        printf("Informacion del Producto:\n");
                        printf("Clave       :%d\n",vecClaves[indiceProductos]);
                        printf("Descripcion :%s\n",vecDescripciones[indiceProductos]);
                        printf("Existencia  :%d\n",vecExistencias[indiceProductos]);
                        printf("Minimo      :%d\n",vecMinimos[indiceProductos]);
                        printf("Precio      :%d\n",vecPrecios[indiceProductos]);

                        // Cambia variable de existencia
                        existe ='S';

                        // Sale del Ciclo
                        break;
                     }
                 }

                 // Verifica si no lo encontró
                 if (existe=='N')
                 {
                    // Despliega mensaje de que no se encontró
                    printf("No existe un producto con la clave indicada\n");
                 }     
                 break;
          
          case 0:// Mensaje de Finalización
                 printf("La Aplicacion finalizara ...\n");
                 break;                                                           
          default:
             // Mensaje
             printf("Opcion Seleccionada incorrecta \n");

       }       

       // Pausa el programa    
       fflush(stdin);   
       printf("Pulse enter para continuar ...\n");
       getchar();
   }
   
   // Fin del Programa
   return 0;
}

