// -----------------------------------------------------------
// Práctica de Arreglos en C
// -----------------------------------------------------------

// De los n alumnos de programación estructurada, se desea 
// almacenar la siguiente información, para cada uno de ellos,
// en tres vectores que corresponden a la siguiente 
// información:

// Código
// Edad
// Zona [1. Urbano 2. Rural]

// La Zona permite definir el valor de matrícula así:
// Urbano $1500
// Rural $700

// El valor de matrícula tendrá un descuento, del 30% solo 
// para los estudiantes menores de edad. 
// Un menor de edad es el estudiante que tiene menos de 18 
// años. 

// Desarrollar un programa en C que:
// a) Leer la información de los estudiantes en los vectores 
// (código, edad, zona).
// b) Calcular e imprimir el valor de la matrícula de cada 
// estudiante.
// c) Contar los estudiantes menores de edad, que residen 
// en la zona Urbana y Rural.

// Se incluyen las librerias
#include "stdio.h"

// Constantes
#define INT_ZONA_URBANA 1
#define INT_ZONA_RURAL  2

#define INT_VALOR_MATRICULA_URBANA 1500
#define INT_VALOR_MATRICULA_RURAL  700

#define INT_MAYOR_EDAD 18

#define INT_MAX_ALUMNOS 10

// Definimos los vectores
int vecCodigo[INT_MAX_ALUMNOS];
int vecEdad[INT_MAX_ALUMNOS];
int vecZona[INT_MAX_ALUMNOS];

// Programa Principal
int main(void)
{   
   // Caracter para hacer una pausa
   char tecla;

   // Variable para la opción del Meun
   int indice;
   int alumnosCapturar;

   // Variable para contar los Alumnos Urbanos
   int iAlumnosUrbanosMenoresEdad = 0;
   int iAlumnosRuralesMenoresEdad = 0;

   // Ciclo para controlar el Menu
   
   // Menu Principal
   printf("Indique cuantos Alumnos va a Capturar (Max-10) \n");
   scanf("%d",&alumnosCapturar);

   // Verifica que sean <= 10
   if (alumnosCapturar<=10)
   {
      // Mensaje
      printf("Capturando los datos de los Alumnos ...\n");

      // Ciclo para solicitar los datos
      for (indice=0; indice < alumnosCapturar; indice++)
      {
         // Solicitando los datos de los Alumnos
         printf("Alumno :[%d]\n",indice+1);

         printf("Codigo :");
         scanf("%d",&vecCodigo[indice]);

         printf("Edad :");
         scanf("%d",&vecEdad[indice]);

         printf("Zona (1-Urbana 2-Rural) :");
         scanf("%d",&vecZona[indice]);          
      }

      // Mensaje de Captura Finalizado
      printf("\n");

      // Ciclo para desplegar los datos con su matricula
      printf("Los Datos de los Alumnos con Matricula son:\n");
      printf("Codigo \tEdad \tZona \tMatricula \n");
      
      for (indice=0; indice < alumnosCapturar; indice++)
      {
         // Solicitando los datos de los Alumnos
         printf("%d \t",vecCodigo[indice]);
         printf("%d \t",vecEdad[indice]);
         printf("%d \t",vecZona[indice]);

         // verifica zona para matricula
         if (vecZona[indice]==INT_ZONA_URBANA)
         {            
            // Verifica si es menor de Edad
            if (vecEdad[indice]<18)    
            {  
               // Despliega el Valor de la Matricula
               printf("%f \n",INT_VALOR_MATRICULA_URBANA *.30);
      
               // Incrementa el Contador
               iAlumnosUrbanosMenoresEdad++;
            }
            else
            {
               // Despliega el Valor de la Matricula
               printf("%d \n",INT_VALOR_MATRICULA_URBANA);
            }
            
         }
         else
         {
            // Verifica si es menor de Edad
            if (vecEdad[indice]<18)            
            {
               // Despliega el Valor de la Matricula
               printf("%f \n",INT_VALOR_MATRICULA_RURAL*.30);
               
               // Incrementa el Contador
               iAlumnosRuralesMenoresEdad++;
            }
            else
            {
               // Despliega el Valor de la Matricula
               printf("%f \n",INT_VALOR_MATRICULA_RURAL);
            }                        
         }         
      }

      // Despliega los datos de los Menores de Edad
      printf("\n");

      // Despliega los datos de los Menores de Edad
      printf("El Numero de Alumnos Urbanos menores de edad es:%d\n",iAlumnosUrbanosMenoresEdad);
      printf("El Numero de Alumnos Rurales menores de edad es:%d\n",iAlumnosRuralesMenoresEdad);
   }
   else
   {
      printf("Error: Solo puedes capturar hasta 10 alumnos\n");      
   }

   // Mensaje final
   printf("\nEl Programa finalizara ...\n");
   
   // Fin del Programa
   return 0;
}

